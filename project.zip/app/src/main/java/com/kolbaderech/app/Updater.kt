package com.kolbaderech.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * עדכון מתוך האפליקציה: בודק את הגרסה האחרונה ב-GitHub Releases, מוריד ומתקין.
 * מאגר פרטי צריך מפתח GitHub לקריאה בלבד (Contents: Read).
 */
object Updater {
    data class Info(val build: Int, val apiUrl: String, val browserUrl: String, val size: Long = 0)

    /** ממתין לאישור להורדה בגלישה סלולרית. */
    val needsConfirm = MutableStateFlow(false)

    private fun metered(c: Context): Boolean = try {
        c.getSystemService(android.net.ConnectivityManager::class.java).isActiveNetworkMetered
    } catch (e: Throwable) {
        false
    }

    fun sizeText(i: Info?): String = if (i == null || i.size <= 0) "" else " (%.0f MB)".format(i.size / 1_048_576.0)

    val status = MutableStateFlow("")
    val available = MutableStateFlow<Info?>(null)

    /** התקדמות הורדה: כמה ירד, מתוך כמה, ומתי התחיל. */
    data class Progress(val done: Long, val total: Long, val startedAt: Long)
    val progress = MutableStateFlow<Progress?>(null)

    private fun repo(): String = Prefs.updRepo.trim().ifBlank { BuildConfig.UPDATE_REPO }
        .removePrefix("https://github.com/").trim('/')

    private fun token(): String = Prefs.updToken.trim().ifBlank { BuildConfig.UPDATE_TOKEN }

    /** האם העדכונים מוגדרים (מובנים באפליקציה או ידנית). */
    fun configured() = repo().contains("/")

    fun currentBuild(c: Context): Int = try {
        @Suppress("DEPRECATION")
        val v = c.packageManager.getPackageInfo(c.packageName, 0).versionCode
        v
    } catch (e: Throwable) {
        0
    }

    private fun open(url: String, accept: String, auth: Boolean): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 30000
        c.instanceFollowRedirects = false
        c.setRequestProperty("Accept", accept)
        c.setRequestProperty("User-Agent", "Noga-Updater")
        val token = token()
        if (auth && token.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer $token")
        return c
    }

    /** בודק אם יש גרסה חדשה. רץ ברקע. */
    fun check(c: Context, manual: Boolean, done: (String) -> Unit = {}) {
        val repo = repo()
        if (repo.isEmpty() || !repo.contains("/")) {
            if (manual) done("צריך למלא את שם המאגר, למשל: username/kol-baderech")
            return
        }
        status.value = "בודקת…"
        Net.async({
            var conn: HttpURLConnection? = null
            try {
                conn = open("https://api.github.com/repos/$repo/releases/latest", "application/vnd.github+json", true)
                val code = conn.responseCode
                if (code == 401) return@async "המפתח של GitHub לא תקין (אולי הועתק חלקית, או שפג תוקפו)"
                if (code == 404) {
                    // לבדוק אם המאגר עצמו נגיש, כדי לדעת מה הבעיה
                    val r2 = open("https://api.github.com/repos/$repo", "application/vnd.github+json", true)
                    val c2 = r2.responseCode
                    r2.disconnect()
                    return@async when {
                        c2 == 200 -> "המאגר נמצא, אבל אין בו גרסה (Release). בדוק שה-Actions הצליח"
                        token().isBlank() -> "המאגר „$repo“ פרטי – צריך מפתח GitHub"
                        else -> "לא מוצאת את „$repo“. בדוק שהשם מדויק, ושבמפתח בחרת את המאגר הזה (Only select repositories)"
                    }
                }
                if (code != 200) return@async "שגיאה $code"
                val o = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val build = Regex("(\\d+)").findAll(o.optString("tag_name")).lastOrNull()?.value?.toIntOrNull() ?: 0
                val assets = o.optJSONArray("assets")
                var info: Info? = null
                if (assets != null) for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) {
                        info = Info(build, a.optString("url"), a.optString("browser_download_url"), a.optLong("size")); break
                    }
                }
                Prefs.lastUpdCheck = System.currentTimeMillis().toString()
                when {
                    info == null -> "לא נמצא קובץ APK בגרסה האחרונה"
                    build <= currentBuild(c) -> {
                        available.value = null
                        "יש לך כבר את הגרסה האחרונה ($build)"
                    }
                    else -> {
                        available.value = info
                        "יש גרסה חדשה: $build" + sizeText(info)
                    }
                }
            } catch (e: Throwable) {
                "אין חיבור: ${e.message}"
            } finally {
                conn?.disconnect()
            }
        }) { r ->
            val msg = r ?: "שגיאה"
            status.value = msg
            DLog.i("⬆️ עדכון: $msg")
            done(msg)
        }
    }

    /** בדיקה אוטומטית פעם ביום. */
    fun autoCheck(c: Context) {
        val last = Prefs.lastUpdCheck.toLongOrNull() ?: 0L
        if (System.currentTimeMillis() - last > 20 * 60 * 60_000L) check(c, manual = false)
    }

    fun canInstall(c: Context): Boolean =
        Build.VERSION.SDK_INT < 26 || c.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(c: Context) {
        try {
            c.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Throwable) {
        }
    }

    /** בודק את הקובץ שירד לפני ההתקנה, כדי לדעת למה "האפליקציה לא הותקנה". */
    @Suppress("DEPRECATION")
    private fun verify(c: Context, f: File): String? {
        DLog.i("⬆️ ירד קובץ: ${f.length() / 1024} KB")
        if (f.length() < 500_000) {
            val head = try { f.readText().take(120) } catch (e: Throwable) { "" }
            return "הקובץ שירד לא תקין (${f.length()} בייטים): $head"
        }
        val pm = c.packageManager
        val flags = if (Build.VERSION.SDK_INT >= 28) android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES
        else android.content.pm.PackageManager.GET_SIGNATURES
        val info = pm.getPackageArchiveInfo(f.absolutePath, flags) ?: return "הקובץ שירד פגום (אנדרואיד לא מצליח לקרוא אותו). נסה שוב"
        if (info.packageName != c.packageName) return "הקובץ שייך לאפליקציה אחרת: ${info.packageName}"
        val newCode = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode.toInt() else info.versionCode
        val cur = currentBuild(c)
        DLog.i("⬆️ גרסה בקובץ: $newCode, מותקנת: $cur")
        if (newCode <= cur) return "הקובץ הוא גרסה $newCode, לא חדשה מ-$cur שמותקנת"
        fun sigs(pi: android.content.pm.PackageInfo?): Set<String> {
            if (pi == null) return emptySet()
            val arr = if (Build.VERSION.SDK_INT >= 28) pi.signingInfo?.apkContentsSigners else pi.signatures
            return arr?.map { java.security.MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) }.take(16) }?.toSet() ?: emptySet()
        }
        val installed = try { pm.getPackageInfo(c.packageName, flags) } catch (e: Throwable) { null }
        val a = sigs(installed)
        val b = sigs(info)
        DLog.i("⬆️ חתימה מותקנת: $a, חתימה בקובץ: $b")
        if (a.isNotEmpty() && b.isNotEmpty() && a != b) {
            return "הגרסה החדשה חתומה במפתח אחר מזו שמותקנת, ולכן אנדרואיד מסרב. צריך להסיר את נוגה פעם אחת ולהתקין מחדש"
        }
        return null
    }

    /** מוריד ופותח את מסך ההתקנה. */
    fun downloadAndInstall(c: Context, force: Boolean = false) {
        val info = available.value ?: return
        val cached = File(File(c.cacheDir, "updates"), "noga-${info.build}.ok").exists()
        if (!force && !cached && Prefs.updWifiOnly && metered(c)) {
            needsConfirm.value = true
            status.value = "אתה בגלישה סלולרית. העדכון שוקל${sizeText(info).ifEmpty { " כמה עשרות MB" }} – עדיף לחכות ל-Wi-Fi"
            return
        }
        needsConfirm.value = false
        if (!canInstall(c)) {
            status.value = "צריך לאשר לנוגה להתקין אפליקציות (נפתח עכשיו), ואז ללחוץ שוב"
            openInstallPermission(c)
            return
        }
        status.value = "מורידה…"
        progress.value = Progress(0, -1, System.currentTimeMillis())
        val app = c.applicationContext
        Net.async({
            try {
                val dir = File(app.cacheDir, "updates").apply { mkdirs() }
                val out = File(dir, "noga-${info.build}.apk")
                // כבר ירד בעבר? לא מורידים שוב (חוסך גלישה)
                if (out.exists() && out.length() > 500_000 && File(dir, "noga-${info.build}.ok").exists()) {
                    DLog.i("⬆️ משתמשת בקובץ שכבר ירד (בלי הורדה נוספת)")
                    return@async out.absolutePath
                }
                dir.listFiles()?.filter { !it.name.contains("-${info.build}.") }?.forEach { it.delete() }
                val useApi = token().isNotBlank() && info.apiUrl.isNotBlank()
                var url = if (useApi) info.apiUrl else info.browserUrl
                var auth = useApi
                var conn: HttpURLConnection
                var hops = 0
                while (true) {
                    conn = open(url, "application/octet-stream", auth)
                    val code = conn.responseCode
                    if (code in 300..399) {
                        url = conn.getHeaderField("Location") ?: return@async "שגיאת הורדה"
                        auth = false // הקישור המופנה כבר חתום
                        conn.disconnect()
                        if (++hops > 5) return@async "יותר מדי הפניות"
                        continue
                    }
                    if (code != 200) return@async "שגיאת הורדה $code"
                    break
                }
                val total = conn.contentLengthLong
                val started = System.currentTimeMillis()
                var done = 0L
                var lastUi = 0L
                Net.main.post { progress.value = Progress(0, total, started) }
                conn.inputStream.use { input ->
                    FileOutputStream(out).use { output ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - lastUi > 250) {
                                lastUi = now
                                val d = done
                                Net.main.post { progress.value = Progress(d, total, started) }
                            }
                        }
                    }
                }
                conn.disconnect()
                File(dir, "noga-${info.build}.ok").writeText("ok")
                val d = done
                Net.main.post { progress.value = Progress(d, if (total > 0) total else d, started) }
                out.absolutePath
            } catch (e: Throwable) {
                "שגיאת הורדה: ${e.message}"
            }
        }) { r ->
            progress.value = null
            if (r != null && r.endsWith(".apk")) {
                val problem = verify(app, File(r))
                if (problem != null) {
                    status.value = problem
                    DLog.i("⬆️ $problem")
                    return@async
                }
                status.value = "ההורדה הסתיימה – פותחת התקנה…"
                Wake.beforeUpdate(app)
                try {
                    val uri = FileProvider.getUriForFile(app, app.packageName + ".files", File(r))
                    app.startActivity(
                        Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Throwable) {
                    status.value = "לא הצלחתי לפתוח את ההתקנה: ${e.message}"
                }
            } else {
                status.value = r ?: "שגיאה"
            }
        }
    }
}
