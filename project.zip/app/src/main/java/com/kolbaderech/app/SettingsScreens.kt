package com.kolbaderech.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kolbaderech.app.ui.BigButton
import com.kolbaderech.app.ui.C
import com.kolbaderech.app.ui.CardBox
import com.kolbaderech.app.ui.PrefChoice
import com.kolbaderech.app.ui.PrefSlider
import com.kolbaderech.app.ui.PrefText
import com.kolbaderech.app.ui.PrefToggle
import com.kolbaderech.app.ui.SectionTitle
import com.kolbaderech.app.ui.ToggleRow

@Composable
fun BackHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(48.dp).clip(CircleShape).background(C.Surface)
                .border(1.dp, C.Border, CircleShape).clickable { onBack() },
            contentAlignment = Alignment.Center
        ) {
            Icon(painterResource(R.drawable.ic_back), contentDescription = "חזרה", tint = C.Text, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun PermRow(title: String, sub: String, ok: Boolean, onFix: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = !ok) { onFix() }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = C.Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.width(10.dp))
        if (ok) {
            Icon(painterResource(R.drawable.ic_check), contentDescription = "מאושר", tint = C.Teal, modifier = Modifier.size(24.dp))
        } else {
            Text(
                "אשר", color = C.OnAmber, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(C.Amber)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
private fun PermissionsCard(key: Int, onRequest: (Array<String>) -> Unit, showAccessibility: Boolean) {
    val ctx = LocalContext.current
    val runtimeOk = remember(key) { Perms.runtimeOk(ctx) }
    val listenerOk = remember(key) { Perms.listenerOk(ctx) }
    val overlayOk = remember(key) { Perms.overlayOk(ctx) }
    val batteryOk = remember(key) { Perms.batteryOk(ctx) }
    val bgLocOk = remember(key) { Perms.backgroundLocOk(ctx) }
    val a11yOk = remember(key) { GateService.isEnabled(ctx) }
    CardBox(padding = 16.dp) {
        PermRow("גישה להתראות", "כדי לקרוא הודעות ולשלוט במוזיקה", listenerOk) {
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        PermRow("מיקרופון, מיקום, אנשי קשר, טלפון, SMS ויומן", "לפקודות קוליות ולכל הפיצ׳רים", runtimeOk) {
            onRequest(Perms.runtimeList())
        }
        PermRow("מיקום גם ברקע", "בחר „לאפשר כל הזמן“ – בשביל השער, החניה והתראות מהירות", bgLocOk) {
            onRequest(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
        }
        PermRow("הצגה מעל אפליקציות אחרות", "כדי שמסך ההקראה יקפוץ בזמן נהיגה", overlayOk) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
        }
        PermRow("ללא הגבלת סוללה", "כדי שאנדרואיד לא ירדים את האפליקציה", batteryOk) {
            @SuppressLint("BatteryLife")
            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
            try { ctx.startActivity(i) } catch (e: Exception) { }
        }
        if (showAccessibility) {
            PermRow("נגישות (לפתיחת השער)", "Settings → נגישות → קול בדרך → הפעל", a11yOk) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }
}

// ------------------------------------------------------------------
// הגדרות בטלפון (כאן מגדירים הכל, ומסך הרכב מקבל אוטומטית)
// ------------------------------------------------------------------
@Composable
fun SettingsScreen(onBack: () -> Unit, onRole: () -> Unit) {
    val ctx = LocalContext.current
    val tick by UiBus.tick.collectAsState()
    val linked by Link.connected.collectAsState()
    var localTick by remember { mutableStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { localTick++ }
    val key = tick + localTick
    val devices = remember(key) { Perms.bondedDevices(ctx) }
    var cars by remember { mutableStateOf(Prefs.cars) }
    var pickGate by remember { mutableStateOf(false) }
    var gatePkg by remember { mutableStateOf(Prefs.gatePkg) }
    var gateLoc by remember { mutableStateOf(Prefs.gateLat.isNotBlank()) }
    val seen = remember(key) { Store.seenPackages }
    var extra by remember { mutableStateOf(Prefs.extraApps) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        BackHeader("הגדרות", onBack)

        SectionTitle("הרשאות")
        PermissionsCard(key, { launcher.launch(it) }, showAccessibility = true)

        SectionTitle("מסך הרכב")
        CardBox(padding = 16.dp) {
            Text(if (linked) "מחובר למסך הרכב ✓" else "מסך הרכב לא מחובר כרגע", fontSize = 17.sp, fontWeight = FontWeight.Bold,
                color = if (linked) C.Teal else C.Text)
            Text(
                "1. חבר את מסך הרכב לנקודה החמה של הטלפון.\n2. התקן גם עליו את אותו קובץ ובחר „זה מסך הרכב“.\n3. ההגדרות כאן עוברות אליו אוטומטית.",
                color = C.Muted, fontSize = 14.sp, lineHeight = 21.sp
            )
            PrefChoice(
                "מאיפה מתנגנת המוזיקה?", listOf("phone" to "מהטלפון (בלוטוס)", "car" to "ממסך הרכב"),
                { Prefs.musicSource }, { Prefs.musicSource = it }
            )
        }

        SectionTitle("רכבים בבלוטוס (גיבוי, כשאין מסך מחובר)")
        CardBox(padding = 16.dp) {
            if (devices.isEmpty()) Text("אשר קודם את הרשאות הבלוטוס.", color = C.Muted, fontSize = 15.sp)
            devices.forEach { (name, addr) ->
                ToggleRow(name, null, addr in cars) { on ->
                    cars = if (on) cars + addr else cars - addr
                    Prefs.cars = cars
                    if (on) Prefs.carName = name
                }
            }
        }

        SectionTitle("אפליקציות להקראה")
        CardBox(padding = 16.dp) {
            SupportedApps.all.forEach { def ->
                PrefToggle(def.label, def.sub, { Prefs.appEnabled(def) }) { Prefs.setAppEnabled(def, it) }
            }
            val others = (seen + extra).filter { SupportedApps.find(it) == null }.distinct()
            if (others.isNotEmpty()) Text("אפליקציות נוספות שזוהו", color = C.Muted, fontSize = 13.sp)
            others.forEach { pkg ->
                ToggleRow(Perms.appLabel(ctx, pkg), pkg, pkg in extra) { on ->
                    extra = if (on) extra + pkg else extra - pkg
                    Prefs.extraApps = extra
                }
            }
        }

        SectionTitle("אנשים חשובים וקבוצות")
        CardBox(padding = 16.dp) {
            PrefText("אנשים חשובים", "למשל: אמא, אשתי, הבוס", { Prefs.vipNames }, { Prefs.vipNames = it })
            PrefToggle("רק אנשים חשובים", "השאר יגיעו בסיכום כל 10 דקות", { Prefs.vipOnly }) { Prefs.vipOnly = it }
            PrefChoice(
                "קבוצות בוואטסאפ",
                listOf("all" to "הכל", "summary" to "רק סיכום", "mentions" to "רק כשמתייגים אותי", "none" to "בלי"),
                { Prefs.groupMode }, { Prefs.groupMode = it }
            )
            PrefText("השם שלי (לזיהוי תיוג)", "למשל: יוסי", { Prefs.myName }, { Prefs.myName = it })
        }

        SectionTitle("הקראה חכמה")
        CardBox(padding = 16.dp) {
            PrefToggle("איחוד הודעות", "„3 הודעות מדני“ במקום שלוש הקראות", { Prefs.groupMessages }) { Prefs.groupMessages = it }
            PrefToggle("מיילים מקוצרים", "רק שולח ונושא", { Prefs.shortEmails }) { Prefs.shortEmails = it }
            PrefToggle("שקט בזמן שיחה", "ההודעות יחכו לסוף השיחה ויסוכמו", { Prefs.silentInCalls }) { Prefs.silentInCalls = it }
            PrefToggle("הנמכה במקום עצירה", "המוזיקה ממשיכה בשקט ברקע", { Prefs.duck }) { Prefs.duck = it }
            PrefToggle("צליל לכל אפליקציה", "לדעת ממה ההודעה עוד לפני ההקראה", { Prefs.appSounds }) { Prefs.appSounds = it }
            PrefToggle("תרגום לעברית", "הודעות באנגלית, רוסית, ערבית ועוד", { Prefs.translate }) { Prefs.translate = it }
            PrefToggle("סיכום הודעות ארוכות", "דרך Gemini, אם הוגדר מפתח", { Prefs.summarizeLong }) { Prefs.summarizeLong = it }
            PrefToggle("קודי אימות ספרה-ספרה", "קודים מוקראים לאט", { Prefs.otp }) { Prefs.otp = it }
            PrefToggle("סינון ספאם", "פרסומות לא יוקראו", { Prefs.spamFilter }) { Prefs.spamFilter = it }
            PrefText("מילים של ספאם", "מבצע, הנחה…", { Prefs.spamWords }, { Prefs.spamWords = it })
            PrefToggle("סיכום בכניסה לרכב", "„מחכות לך 3 הודעות בוואטסאפ“", { Prefs.startSummary }) { Prefs.startSummary = it }
            PrefToggle("הכרזה בכניסה לרכב", "„מצב נהיגה פעיל“", { Prefs.announceStart }) { Prefs.announceStart = it }
        }

        SectionTitle("תגובות")
        CardBox(padding = 16.dp) {
            PrefToggle("תגובה קולית", "אחרי הקראה אפשר לומר „תעני לו…“", { Prefs.voiceReply }) { Prefs.voiceReply = it }
            PrefToggle("שליחה אוטומטית", "נשלחת אלא אם אמרת „בטל“", { Prefs.autoSend }) { Prefs.autoSend = it }
            PrefToggle("הקראת התגובה לפני שליחה", "כדי לוודא שהיא שמעה נכון", { Prefs.readBack }) { Prefs.readBack = it }
            PrefText("תגובות מהירות (כפתורים במסך)", "מופרדות בפסיק", { Prefs.quickReplies }, { Prefs.quickReplies = it })
            PrefToggle("מענה אוטומטי „אני נוהג“", "פעם אחת לכל אדם בנסיעה", { Prefs.autoReplyDriving }) { Prefs.autoReplyDriving = it }
            PrefToggle("SMS אוטומטי לשיחה שלא נענתה", "שולח את אותו נוסח", { Prefs.missedCallSms }) { Prefs.missedCallSms = it }
            PrefText("נוסח המענה האוטומטי", "", { Prefs.autoReplyText }, { Prefs.autoReplyText = it })
        }

        SectionTitle("שער ובית")
        CardBox(padding = 16.dp) {
            PrefToggle("פתיחת שער אוטומטית", "כשמתקרבים הביתה", { Prefs.gateEnabled }) { Prefs.gateEnabled = it }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("אפליקציית השער", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text(if (gatePkg.isBlank()) "לא נבחרה" else Perms.appLabel(ctx, gatePkg), color = C.Muted, fontSize = 13.sp)
                }
                Text("בחר", color = C.Amber, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { pickGate = true }.padding(8.dp))
            }
            PrefText("הטקסט על כפתור הפתיחה", "פתח, Open…", { Prefs.gateButtonText }, { Prefs.gateButtonText = it })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("מיקום השער (וגם הבית)", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text(if (gateLoc) "נשמר ✓" else "עמוד ליד השער ולחץ „שמור“", color = C.Muted, fontSize = 13.sp)
                }
                Text("שמור", color = C.Amber, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                    val l = Perms.currentLocation(ctx)
                    if (l != null) {
                        Prefs.gateLat = l.latitude.toString(); Prefs.gateLng = l.longitude.toString(); gateLoc = true
                    }
                }.padding(8.dp))
            }
            PrefSlider("מרחק פתיחה", 50f..400f, { Prefs.gateRadius }, { Prefs.gateRadius = it }) { "${it.toInt()} מ׳" }
            BigButton("בדיקה: פתח עכשיו", null, C.Surface, C.Text, Modifier.fillMaxWidth(), outlined = true) {
                Announcer.notice(Gate.open(ctx))
            }
            PrefToggle("הודעת הגעה", "„אני מגיע בעוד כמה דקות“ כשמתקרבים הביתה", { Prefs.arrivalEnabled }) { Prefs.arrivalEnabled = it }
            PrefText("למי לשלוח הודעת הגעה", "למשל: אשתי", { Prefs.arrivalContact }, { Prefs.arrivalContact = it })
        }

        SectionTitle("נהיגה ובטיחות")
        CardBox(padding = 16.dp) {
            PrefToggle("תזכורת הפסקה", "אחרי שעתיים נהיגה רצופה", { Prefs.breakReminder }) { Prefs.breakReminder = it }
            PrefToggle("בדיקת מושב אחורי", "כשמכבים את הרכב", { Prefs.backSeat }) { Prefs.backSeat = it }
            PrefToggle("התראת מהירות", null, { Prefs.speedAlert }) { Prefs.speedAlert = it }
            PrefSlider("מהירות להתראה", 50f..140f, { Prefs.speedLimit }, { Prefs.speedLimit = it }) { "${it.toInt()} קמ״ש" }
            PrefToggle("ווליום לפי מהירות", "המוזיקה מתחזקת בכביש מהיר", { Prefs.volumeBySpeed }) { Prefs.volumeBySpeed = it }
            PrefToggle("בוקר טוב", "מזג אוויר ופגישה ראשונה בנסיעה הראשונה ביום", { Prefs.morningBrief }) { Prefs.morningBrief = it }
            PrefToggle("אזהרת גשם", "בכניסה לרכב", { Prefs.rainAlert }) { Prefs.rainAlert = it }
            PrefToggle("המשך מוזיקה אוטומטי", "בכניסה לרכב", { Prefs.autoResumeMusic }) { Prefs.autoResumeMusic = it }
            PrefText("אנשי קשר לחירום", "למשל: אשתי, אבא", { Prefs.emergencyContacts }, { Prefs.emergencyContacts = it })
            PrefText("תאריך טסט", "dd/MM/yyyy", { Prefs.testDate }, { Prefs.testDate = it })
            PrefText("תאריך חידוש ביטוח", "dd/MM/yyyy", { Prefs.insuranceDate }, { Prefs.insuranceDate = it })
            PrefText("תאריך טיפול הבא", "dd/MM/yyyy", { Prefs.serviceDate }, { Prefs.serviceDate = it })
        }

        SectionTitle("בלי ידיים")
        CardBox(padding = 16.dp) {
            PrefToggle("מילת הפעלה", "מאזינה כל הזמן במסך הרכב, בלי לעצור מוזיקה ובלי אינטרנט", { Prefs.wakeEnabled }) { Prefs.wakeEnabled = it }
            PrefText("המילה (באותיות לועזיות)", "hey danny", { Prefs.wakePhrase }, { Prefs.wakePhrase = it })
            Text(
                "„hey danny“ נשמע בדיוק כמו „היי דני“. בפעם הראשונה מסך הרכב מוריד מודל זיהוי של כ-40MB דרך הנקודה החמה.",
                color = C.Muted, fontSize = 13.sp, lineHeight = 19.sp
            )
            PrefToggle("שיחה רציפה", "אחרי תשובה ממשיכה להקשיב לפקודה הבאה", { Prefs.followUp }) { Prefs.followUp = it }
            PrefToggle("מענה לשיחות בקול", "„דני מתקשר“ → „תעני“ / „תדחי“", { Prefs.voiceCalls }) { Prefs.voiceCalls = it }
            PrefToggle("טלפון שקט בנסיעה", "בלי צלילי התראות – הרכב מקריא ממילא", { Prefs.muteNotifications }) { Prefs.muteNotifications = it }
            PrefToggle("וייז נפתח לבד", "בבוקר לעבודה, אחר הצהריים הביתה", { Prefs.autoWaze }) { Prefs.autoWaze = it }
        }

        SectionTitle("קול ועוזר")
        CardBox(padding = 16.dp) {
            PrefSlider("מהירות הקראה", 0.6f..1.6f, { Prefs.speechRate }, { Prefs.speechRate = it }) {
                when {
                    it < 0.85f -> "איטית"
                    it > 1.2f -> "מהירה"
                    else -> "רגילה"
                }
            }
            PrefText("שם העוזרת (גם מילת ההפעלה)", "קול", { Prefs.assistantName }, { Prefs.assistantName = it })
            PrefText("כינויים", "אהובה=רונית כהן (שורה לכל כינוי)", { Prefs.nicknames }, { Prefs.nicknames = it }, multiline = true)
            PrefText("תיקון הגייה", "Gmail=ג׳ימייל (שורה לכל מילה)", { Prefs.pronunciation }, { Prefs.pronunciation = it }, multiline = true)
            PrefText("תחנות רדיו", "שם=כתובת (שורה לכל תחנה)", { Prefs.radioStations }, { Prefs.radioStations = it }, multiline = true)
        }

        SectionTitle("Gemini – הבנה חופשית ושאלות (חינמי)")
        CardBox(padding = 16.dp) {
            Text("מפתח חינמי מקבלים ב-aistudio.google.com. בלי מפתח, כל הפקודות הרגילות עובדות.", color = C.Muted, fontSize = 13.sp)
            PrefText("מפתח API", "הדבק כאן", { Prefs.geminiKey }, { Prefs.geminiKey = it }, secret = true)
            PrefText("מודל", "gemini-2.5-flash", { Prefs.geminiModel }, { Prefs.geminiModel = it })
        }

        SectionTitle("בדיקות")
        CardBox(padding = 16.dp) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton("בדיקת קול", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { Announcer.testVoice() }
                BigButton("הודעת בדיקה", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { Announcer.testMessage() }
            }
            Text("החלף תפקיד מכשיר", color = C.Amber, fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { onRole() }.padding(vertical = 8.dp))
        }

        Text("קול בדרך · גרסה ${BuildInfo.version(ctx)}", color = C.Muted, fontSize = 13.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
    }

    if (pickGate) {
        val apps = remember { Perms.launcherApps(ctx) }
        AlertDialog(
            onDismissRequest = { pickGate = false },
            containerColor = C.Surface,
            title = { Text("בחר את אפליקציית השער") },
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(apps) { (label, pkg) ->
                        Text(label, fontSize = 17.sp, modifier = Modifier.fillMaxWidth().clickable {
                            Prefs.gatePkg = pkg; Prefs.gateLabel = label; gatePkg = pkg; pickGate = false
                        }.padding(vertical = 12.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickGate = false }) { Text("סגור", color = C.Amber) } }
        )
    }
}

// ------------------------------------------------------------------
// הגדרות במסך הרכב
// ------------------------------------------------------------------
@Composable
fun CarSettingsScreen(onBack: () -> Unit, onRole: () -> Unit) {
    val ctx = LocalContext.current
    val tick by UiBus.tick.collectAsState()
    val status by Link.status.collectAsState()
    val linked by Link.connected.collectAsState()
    var localTick by remember { mutableStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { localTick++ }
    val key = tick + localTick

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        BackHeader("הגדרות מסך הרכב", onBack)
        CardBox(padding = 16.dp) {
            Text(if (linked) "מחובר לטלפון ✓" else status, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                color = if (linked) C.Teal else C.Amber)
            Text(
                "חבר את המסך לנקודה החמה של הטלפון, ופתח את „קול בדרך“ בטלפון. כל ההגדרות נעשות בטלפון ועוברות לכאן אוטומטית.",
                color = C.Muted, fontSize = 14.sp, lineHeight = 21.sp
            )
            PrefText("כתובת הטלפון (רק אם החיבור לא מצליח)", "ריק = אוטומטי", { Prefs.linkIp }, { Prefs.linkIp = it })
            val wakeStatus by Wake.status.collectAsState()
            Text("מילת הפעלה: $wakeStatus", color = C.Muted, fontSize = 14.sp)
        }
        SectionTitle("הרשאות")
        PermissionsCard(key, { launcher.launch(it) }, showAccessibility = false)
        SectionTitle("בדיקות")
        CardBox(padding = 16.dp) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton("בדיקת קול", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { Announcer.testVoice() }
                BigButton("הודעת בדיקה", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { Announcer.testMessage() }
            }
            Text("החלף תפקיד מכשיר", color = C.Amber, fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { onRole() }.padding(vertical = 8.dp))
        }
        Text("גרסה ${BuildInfo.version(ctx)}", color = C.Muted, fontSize = 13.sp)
    }
}

object BuildInfo {
    fun version(c: android.content.Context): String = try {
        c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }
}

@Suppress("unused")
private val unusedColor = Color.Transparent
