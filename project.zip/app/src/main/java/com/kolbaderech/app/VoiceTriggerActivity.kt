package com.kolbaderech.app

import android.app.Activity
import android.os.Bundle

/** מופעל מכפתור הקול שבהגה או מלחיצה ארוכה (כעוזר ברירת מחדל). */
class VoiceTriggerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Announcer.listenCommand()
        finish()
    }
}
