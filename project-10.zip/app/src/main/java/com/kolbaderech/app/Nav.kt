package com.kolbaderech.app

import android.content.Context
import android.content.Intent
import android.net.Uri

object Nav {
    private fun open(ctx: Context, uri: String): Boolean = try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    fun to(ctx: Context, q: String) {
        val enc = Uri.encode(q)
        if (!open(ctx, "waze://?q=$enc&navigate=yes")) open(ctx, "google.navigation:q=$enc")
    }

    fun home(ctx: Context) {
        if (!open(ctx, "waze://?favorite=home&navigate=yes")) to(ctx, "בית")
    }

    fun work(ctx: Context) {
        if (!open(ctx, "waze://?favorite=work&navigate=yes")) to(ctx, "עבודה")
    }

    fun openWaze(ctx: Context) {
        val i = ctx.packageManager.getLaunchIntentForPackage("com.waze") ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
        }
    }
}
