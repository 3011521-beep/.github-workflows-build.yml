package com.kolbaderech.app

import android.app.SearchManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.KeyEvent
import org.json.JSONObject

object Media {
    const val YT_MUSIC = "com.google.android.apps.youtube.music"
    const val SPOTIFY = "com.spotify.music"

    private fun controllers(ctx: Context): List<MediaController> = try {
        ctx.getSystemService(MediaSessionManager::class.java)
            .getActiveSessions(ComponentName(ctx, NotifListener::class.java))
    } catch (e: Exception) {
        emptyList()
    }

    private fun primary(ctx: Context): MediaController? {
        val list = controllers(ctx)
        return list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
    }

    private fun key(ctx: Context, code: Int) {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun pause(ctx: Context) {
        val c = primary(ctx)
        if (c != null) c.transportControls.pause() else key(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE)
    }

    fun play(ctx: Context) {
        val c = primary(ctx)
        if (c != null) c.transportControls.play() else key(ctx, KeyEvent.KEYCODE_MEDIA_PLAY)
    }

    fun next(ctx: Context) {
        val c = primary(ctx)
        if (c != null) c.transportControls.skipToNext() else key(ctx, KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun prev(ctx: Context) {
        val c = primary(ctx)
        if (c != null) c.transportControls.skipToPrevious() else key(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    fun volume(ctx: Context, up: Boolean) {
        val am = ctx.getSystemService(AudioManager::class.java)
        repeat(2) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0
            )
        }
    }

    fun nowPlaying(ctx: Context): String? {
        val md = primary(ctx)?.metadata ?: return null
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
        return if (artist.isNullOrBlank()) "מתנגן עכשיו: $title" else "מתנגן עכשיו: $title, של $artist"
    }

    fun openApp(ctx: Context, pkg: String) {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
        }
    }

    private val handler = Handler(Looper.getMainLooper())

    private fun title(c: MediaController?): String =
        c?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""

    private fun controllerFor(ctx: Context, pkg: String): MediaController? =
        controllers(ctx).firstOrNull { it.packageName == pkg }

    /**
     * השמעת שיר מסוים: 1) דרך הנגן שכבר פתוח, 2) פתיחה + בקשה חוזרת,
     * 3) גיבוי: חיפוש באפליקציה ולחיצה על "נגן" (דרך שירות הנגישות).
     */
    fun playSearch(ctx: Context, query: String, pkg: String?) {
        val app = ctx.applicationContext
        val target = pkg ?: listOf(YT_MUSIC, SPOTIFY).firstOrNull { p ->
            app.packageManager.getLaunchIntentForPackage(p) != null
        }
        if (target == null) {
            sendSearchIntent(app, query, null)
            return
        }
        if (target == YT_MUSIC) {
            // הדרך הכי אמינה: מוצאים את השיר ופותחים אותו ישירות – יוטיוב מיוזיק מנגן מיד
            Net.async({ findVideoId(query) }) { id ->
                if (id != null && openYtWatch(app, id)) {
                    handler.postDelayed({
                        val c = controllerFor(app, target)
                        if (c?.playbackState?.state != PlaybackState.STATE_PLAYING) playViaSession(app, query, target)
                    }, 7000)
                } else {
                    playViaSession(app, query, target)
                }
            }
            return
        }
        playViaSession(app, query, target)
    }

    private fun findVideoId(query: String): String? {
        val html = Net.getAsBrowser("https://www.youtube.com/results?search_query=" + Net.enc(query)) ?: return null
        return Regex("\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(html)?.groupValues?.get(1)
    }

    private fun openYtWatch(app: Context, id: String): Boolean = try {
        app.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/watch?v=$id"))
                .setPackage(YT_MUSIC).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        true
    } catch (e: Exception) {
        false
    }

    private fun playViaSession(app: Context, query: String, target: String) {
        val before = title(controllerFor(app, target))
        val existing = controllerFor(app, target)
        if (existing != null) {
            try {
                existing.transportControls.playFromSearch(query, Bundle())
            } catch (e: Exception) {
            }
        } else {
            sendSearchIntent(app, query, target)
            handler.postDelayed({
                try {
                    controllerFor(app, target)?.transportControls?.playFromSearch(query, Bundle())
                } catch (e: Exception) {
                }
            }, 3500)
        }
        // בדיקה: האם באמת התחיל שיר חדש?
        handler.postDelayed({
            val c = controllerFor(app, target)
            val playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
            val changed = title(c).isNotBlank() && title(c) != before
            if (!(playing && changed)) fallbackTap(app, query, target)
        }, if (existing != null) 3500L else 8000L)
    }

    private fun sendSearchIntent(app: Context, query: String, pkg: String?) {
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(MediaStore.EXTRA_MEDIA_TITLE, query)
            if (pkg != null) setPackage(pkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            app.startActivity(i)
        } catch (e: Exception) {
            try {
                i.setPackage(null)
                app.startActivity(i)
            } catch (e2: Exception) {
            }
        }
    }

    private fun fallbackTap(app: Context, query: String, pkg: String) {
        if (!GateService.isEnabled(app)) return
        val url = if (pkg == YT_MUSIC) "https://music.youtube.com/search?q=" + Uri.encode(query)
        else "spotify:search:" + Uri.encode(query)
        GateService.armTap(
            pkg, listOf("Play", "הפעלה", "הפעל", "נגן", "השמעה", "Shuffle", "ערבוב"), 15, goHome = false
        )
        try {
            app.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
    }

    fun state(ctx: Context): JSONObject? {
        val c = primary(ctx) ?: return null
        val md = c.metadata
        return JSONObject()
            .put("playing", c.playbackState?.state == PlaybackState.STATE_PLAYING)
            .put("title", md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "")
            .put("artist", md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "")
            .put("pkg", c.packageName)
    }

    fun op(ctx: Context, op: String) {
        when (op) {
            "pause" -> pause(ctx)
            "play" -> play(ctx)
            "next" -> next(ctx)
            "prev" -> prev(ctx)
            "up" -> volume(ctx, true)
            "down" -> volume(ctx, false)
        }
    }
}
