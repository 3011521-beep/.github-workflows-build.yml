package com.kolbaderech.app

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kolbaderech.app.ui.BigButton
import com.kolbaderech.app.ui.C
import com.kolbaderech.app.ui.CardBox
import com.kolbaderech.app.ui.SectionTitle
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun DataScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var v by remember { mutableIntStateOf(0) }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }

    @Suppress("UNUSED_VARIABLE") val refresh = v
    val parking = Store.parking
    val shop = Store.list(Store.SHOP)
    val notes = Store.list(Store.NOTES)
    val later = Store.list(Store.LATER)
    val monthStart = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val fuel = Store.list(Store.FUEL).filter { it.optLong("time") >= monthStart }.sumOf { it.optInt("amount") }

    fun share(text: String) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        try {
            ctx.startActivity(Intent.createChooser(i, "שיתוף").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        BackHeader("הנתונים שלי", onBack)

        BigButton("ייצוא לאקסל: נסיעות, סיכום חודשי, ספר רכב ודלק", null, C.Teal, C.OnTeal, Modifier.fillMaxWidth()) {
            try { Report.share(ctx) } catch (e: Exception) { }
        }

        SectionTitle("ספר רכב")
        CardBox(padding = 16.dp) {
            Text(CarBook.status(), fontSize = 16.sp)
            val services = Store.list(Store.SERVICE)
            services.takeLast(5).reversed().forEach { o ->
                val k = o.optDouble("odo", -1.0)
                Text(
                    "טיפול · ${fmt.format(Date(o.optLong("time")))}" + if (k > 0) " · ${k.toLong()} ק״מ" else "",
                    color = C.Muted, fontSize = 14.sp
                )
            }
            BigButton("עשיתי טיפול עכשיו", null, C.Surface, C.Text, Modifier.fillMaxWidth(), outlined = true) {
                CarBook.serviceDone("נרשם מהאפליקציה"); v++
            }
        }

        SectionTitle("נסיעות אחרונות")
        CardBox(padding = 16.dp) {
            val trips = Store.list(Store.TRIPS).takeLast(15).reversed()
            if (trips.isEmpty()) Text("עוד אין נסיעות. הן נרשמות לבד בכל נסיעה.", color = C.Muted, fontSize = 15.sp)
            trips.forEach { o ->
                val id = o.optString("id")
                val business = o.optString("type") == "business"
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${fmt.format(Date(o.optLong("start")))} · ${"%.1f".format(o.optDouble("km"))} ק״מ", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        val route = listOf(o.optString("from"), o.optString("to")).filter { it.isNotBlank() }.joinToString(" ← ")
                        if (route.isNotBlank()) Text(route, color = C.Muted, fontSize = 13.sp)
                    }
                    Text(
                        if (business) "עסקי" else "פרטי",
                        color = if (business) C.Teal else C.Amber, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            if (id.isNotBlank()) {
                                Store.update(Store.TRIPS, id) { it.put("type", if (business) "private" else "business") }
                                v++
                            }
                        }.padding(8.dp)
                    )
                }
            }
            if (trips.isNotEmpty()) Text("לחץ על „עסקי/פרטי“ כדי לשנות", color = C.Muted, fontSize = 12.sp)
        }

        SectionTitle("החניה האחרונה")
        CardBox(padding = 16.dp) {
            if (parking == null) {
                Text("עוד לא נשמרה חניה. היא נשמרת לבד בסוף כל נסיעה.", color = C.Muted, fontSize = 15.sp)
            } else {
                Text("חנית ב-${fmt.format(Date(parking.optLong("time")))}", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                val note = parking.optString("note")
                if (note.isNotBlank()) Text(note, color = C.Soft, fontSize = 15.sp)
                BigButton("מחק את מיקום החניה", null, C.Surface, C.Text, Modifier.fillMaxWidth(), outlined = true) {
                    Store.parking = null; v++
                }
                BigButton("פתח במפה", null, C.Teal, C.OnTeal, Modifier.fillMaxWidth()) {
                    val lat = parking.optDouble("lat")
                    val lng = parking.optDouble("lng")
                    try {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lng?q=" + Uri.encode("$lat,$lng(החניה שלי)")))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: Exception) {
                    }
                }
            }
        }

        SectionTitle("רשימת קניות")
        CardBox(padding = 16.dp) {
            if (shop.isEmpty()) Text("ריקה. אמור בנסיעה: „תוסיפי חלב לרשימת הקניות“", color = C.Muted, fontSize = 15.sp)
            shop.forEachIndexed { i, o ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("• " + o.optString("text"), fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Text("✕", color = C.Muted, modifier = Modifier.clickable { Store.removeAt(Store.SHOP, i); v++ }.padding(8.dp))
                }
            }
            if (shop.isNotEmpty()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BigButton("שתף", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) {
                        share("רשימת קניות:\n" + shop.joinToString("\n") { "• " + it.optString("text") })
                    }
                    BigButton("נקה", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) {
                        Store.clear(Store.SHOP); v++
                    }
                }
            }
        }

        SectionTitle("פתקים")
        CardBox(padding = 16.dp) {
            if (notes.isEmpty()) Text("אין פתקים. אמור בנסיעה: „תרשמי: לקנות מתנה לנועה“", color = C.Muted, fontSize = 15.sp)
            notes.reversed().forEachIndexed { ri, o ->
                val i = notes.size - 1 - ri
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(o.optString("text"), fontSize = 16.sp)
                        Text(fmt.format(Date(o.optLong("time"))), color = C.Muted, fontSize = 12.sp)
                    }
                    Text("✕", color = C.Muted, modifier = Modifier.clickable { Store.removeAt(Store.NOTES, i); v++ }.padding(8.dp))
                }
            }
        }

        SectionTitle("נשמר לאחר כך")
        CardBox(padding = 16.dp) {
            if (later.isEmpty()) Text("ריק. בזמן הקראה אפשר לומר „אחר כך“.", color = C.Muted, fontSize = 15.sp)
            later.forEach { Text(it.optString("text"), fontSize = 15.sp) }
            if (later.isNotEmpty()) {
                BigButton("נקה", null, C.Surface, C.Text, Modifier.fillMaxWidth(), outlined = true) { Store.clear(Store.LATER); v++ }
            }
        }

        SectionTitle("החודש שלך")
        CardBox(padding = 16.dp) {
            Text(Stats.monthSummary(), fontSize = 16.sp)
            Text("דלק: $fuel ₪", fontSize = 16.sp)
            Text("הוקראו ${Store.count("messages")} הודעות · נשלחו ${Store.count("replies")} תגובות", color = C.Muted, fontSize = 14.sp)
        }
    }
}
