package com.kolbaderech.app

import android.content.Context
import android.net.TrafficStats
import android.os.Process

/** כמה אינטרנט נוגה עצמה צרכה (מאז ההפעלה האחרונה של המכשיר, ומצטבר). */
object DataUsage {
    private fun now(): Long {
        val uid = Process.myUid()
        val rx = TrafficStats.getUidRxBytes(uid)
        val tx = TrafficStats.getUidTxBytes(uid)
        return if (rx < 0 || tx < 0) 0 else rx + tx
    }

    /** נשמר מדי פעם, כדי לצבור גם אחרי אתחול. */
    fun tick(c: Context) {
        val sp = c.getSharedPreferences("data", Context.MODE_PRIVATE)
        val cur = now()
        val last = sp.getLong("last", 0)
        val delta = if (cur >= last) cur - last else cur
        sp.edit().putLong("last", cur).putLong("total", sp.getLong("total", 0) + delta).apply()
    }

    fun totalMb(c: Context): Double {
        tick(c)
        return c.getSharedPreferences("data", Context.MODE_PRIVATE).getLong("total", 0) / 1_048_576.0
    }

    fun reset(c: Context) {
        c.getSharedPreferences("data", Context.MODE_PRIVATE).edit().putLong("total", 0).putLong("last", now()).apply()
    }
}
