package com.kolbaderech.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import androidx.core.content.ContextCompat

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Store.init(this)
        Announcer.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("drive", "מצב נהיגה", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alerts", "תזכורות והתראות", NotificationManager.IMPORTANCE_HIGH))
        if (Prefs.isCar) startCarLink(this) else Link.startServer(this)
    }

    companion object {
        fun startCarLink(app: android.content.Context) {
            try {
                ContextCompat.startForegroundService(app, Intent(app, LinkService::class.java))
            } catch (e: Exception) {
                Link.startClient(app)
            }
        }
    }
}
