package com.kolbaderech.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // App.onCreate כבר מפעיל את החיבור לפי התפקיד
        if (Prefs.isCar) App.startCarLink(context.applicationContext)
    }
}
