package com.kolbaderech.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import kotlin.reflect.KProperty

class BoolPref(private val key: String, private val def: Boolean) {
    operator fun getValue(t: Any?, p: KProperty<*>): Boolean = Prefs.sp.getBoolean(key, def)
    operator fun setValue(t: Any?, p: KProperty<*>, v: Boolean) = Prefs.sp.edit().putBoolean(key, v).apply()
}

class StrPref(private val key: String, private val def: String) {
    operator fun getValue(t: Any?, p: KProperty<*>): String = Prefs.sp.getString(key, def) ?: def
    operator fun setValue(t: Any?, p: KProperty<*>, v: String) = Prefs.sp.edit().putString(key, v).apply()
}

class FloatPref(private val key: String, private val def: Float) {
    operator fun getValue(t: Any?, p: KProperty<*>): Float = Prefs.sp.getFloat(key, def)
    operator fun setValue(t: Any?, p: KProperty<*>, v: Float) = Prefs.sp.edit().putFloat(key, v).apply()
}

object Prefs {
    lateinit var sp: SharedPreferences
    private val localKeys = setOf("role", "linkIp", "odoBase", "odoBaseGps", "lastServiceOdo", "pendingTripType")

    fun init(c: Context) {
        sp = c.getSharedPreferences("kol", Context.MODE_PRIVATE)
        // מעבר מגרסה 1: רכב יחיד → רשימת רכבים
        // מעבר לשם החדש: נוגה
        if (!sp.getBoolean("renamedNoga", false)) {
            val ed = sp.edit().putBoolean("renamedNoga", true)
            if ((sp.getString("assistantName", "קול") ?: "קול") in setOf("קול", "דני", "")) ed.putString("assistantName", "נוגה")
            if ((sp.getString("wakePhrase", "hey danny") ?: "") in setOf("hey danny", "")) ed.putString("wakePhrase", "hey noga, noga, no go, hey no go")
            ed.apply()
        }
        val old = sp.getString("carAddress", null)
        if (old != null && sp.getStringSet("cars", null) == null) {
            sp.edit().putStringSet("cars", setOf(old)).apply()
        }
    }

    // ---- תפקיד המכשיר ----
    var role: String?
        get() = sp.getString("role", null)
        set(v) = sp.edit().putString("role", v).apply()
    val isCar: Boolean get() = role == "car"
    var linkIp by StrPref("linkIp", "")

    // ---- רכבים (בלוטוס) ----
    var cars: Set<String>
        get() = sp.getStringSet("cars", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet("cars", v).apply()
    var carName by StrPref("carName", "")

    // ---- הקראה ----
    var autoRead by BoolPref("autoRead", true)
    var groupMessages by BoolPref("group", true)
    var shortEmails by BoolPref("shortEmails", true)
    var silentInCalls by BoolPref("silentCalls", true)
    var duck by BoolPref("duck", true)
    var announceStart by BoolPref("announceStart", true)
    var spamFilter by BoolPref("spamFilter", true)
    var spamWords by StrPref("spamWords", "מבצע, הנחה, קופון, להסרה, unsubscribe, sale")
    var otp by BoolPref("otp", true)
    var translate by BoolPref("translate", true)
    var summarizeLong by BoolPref("summarizeLong", true)
    var appSounds by BoolPref("appSounds", true)
    var startSummary by BoolPref("startSummary", true)
    var vipNames by StrPref("vip", "")
    var vipOnly by BoolPref("vipOnly", false)
    var groupMode by StrPref("groupMode", "all") // all / summary / mentions / none
    var myName by StrPref("myName", "")

    // ---- תגובות ----
    var voiceReply by BoolPref("voiceReply", true)
    var autoSend by BoolPref("autoSend", true)
    var readBack by BoolPref("readBack", true)
    var quickReplies by StrPref("quickReplies", "אני בדרך, אחזור אליך, נדבר אחר כך, 👍")
    var autoReplyDriving by BoolPref("autoReplyDriving", false)
    var autoReplyText by StrPref("autoReplyText", "אני נוהג כרגע, אחזור אליך כשאגיע")
    var missedCallSms by BoolPref("missedCallSms", false)

    // ---- נהיגה ובטיחות ----
    var speedAlert by BoolPref("speedAlert", false)
    var speedLimit by FloatPref("speedLimit", 110f)
    var volumeBySpeed by BoolPref("volumeBySpeed", false)
    var breakReminder by BoolPref("breakReminder", true)
    var backSeat by BoolPref("backSeat", true)
    var morningBrief by BoolPref("morningBrief", true)
    var rainAlert by BoolPref("rainAlert", true)
    var autoResumeMusic by BoolPref("autoResumeMusic", false)
    var testDate by StrPref("testDate", "")
    var insuranceDate by StrPref("insuranceDate", "")
    var serviceDate by StrPref("serviceDate", "")
    var musicSource by StrPref("musicSource", "phone") // phone / car
    var emergencyContacts by StrPref("emergency", "")
    var arrivalEnabled by BoolPref("arrivalEnabled", false)
    var arrivalContact by StrPref("arrivalContact", "")
    var lastBriefDay by StrPref("lastBriefDay", "")

    // ---- שער ובית ----
    var gateEnabled by BoolPref("gateEnabled", false)
    var gatePkg by StrPref("gatePkg", "")
    var gateLabel by StrPref("gateLabel", "")
    var gateButtonText by StrPref("gateButton", "פתח, פתיחה, Open")
    var gateLat by StrPref("gateLat", "")
    var gateLng by StrPref("gateLng", "")
    var gateRadius by FloatPref("gateRadius", 150f)

    // ---- קול ועוזר ----
    var speechRate by FloatPref("rate", 1.0f)
    var assistantName by StrPref("assistantName", "נוגה")
    var wakeWord by BoolPref("wakeWord", false)
    var pronunciation by StrPref("pron", "")
    var nicknames by StrPref("nicknames", "")
    var radioStations by StrPref(
        "radio",
        "גלגלצ=https://glzwizzlv.bynetcdn.com/glz_mp3?awCollectionId=misc&awEpisodeId=glglz\n" +
            "גלי צהל=https://glzwizzlv.bynetcdn.com/glz_mp3?awCollectionId=misc&awEpisodeId=glz"
    )

    // ---- בלי ידיים ----
    var learned by StrPref("learned", "{}")
    var radioLoaded by BoolPref("radioLoaded", false)
    var wakeEnabled by BoolPref("wakeEnabled", true)
    var wakePhrase by StrPref("wakePhrase", "hey noga, noga, no go, hey no go")
    var sttLang by StrPref("sttLang", "he-IL")
    var followUp by BoolPref("followUp", true)
    var askAtStart by BoolPref("askAtStart", true)
    var voiceNotes by BoolPref("voiceNotes", true)
    var msgChannel by StrPref("msgChannel", "whatsapp")
    var waChoice by StrPref("waChoice", "ask") // ask / com.whatsapp / com.whatsapp.w4b
    var waBoth by BoolPref("waBoth", false)
    var autoHotspot by BoolPref("autoHotspot", false)
    var updRepo by StrPref("updRepo", "")
    var updToken by StrPref("updToken", "")
    var lastUpdCheck by StrPref("lastUpdCheck", "0")
    var nikud by BoolPref("nikud", true)
    var nikudUrl by StrPref("nikudUrl", "https://nakdan-2-0.loadbalancer.dicta.org.il/api")
    var gates by StrPref("gates", "[]")
    var homeLabel by StrPref("homeLabel", "")
    var voiceCalls by BoolPref("voiceCalls", true)
    var muteNotifications by BoolPref("muteNotif", true)
    var autoWaze by BoolPref("autoWaze", true)

    // ---- ספר רכב ונסיעות ----
    var workLat by StrPref("workLat", "")
    var workLng by StrPref("workLng", "")
    var odoBase by StrPref("odoBase", "")
    var odoBaseGpsKm by StrPref("odoBaseGps", "0")
    var serviceInterval by StrPref("serviceInterval", "15000")
    var lastServiceOdo by StrPref("lastServiceOdo", "")
    var pendingTripType by StrPref("pendingTripType", "")

    // ---- Gemini ----
    var geminiKey by StrPref("geminiKey", "")
    var geminiModel by StrPref("geminiModel", "gemini-2.5-flash-lite")

    // ---- אפליקציות ----
    fun appEnabled(def: AppDef) = sp.getBoolean("app_" + def.pkg, def.defaultOn)
    fun setAppEnabled(def: AppDef, v: Boolean) = sp.edit().putBoolean("app_" + def.pkg, v).apply()
    var extraApps: Set<String>
        get() = sp.getStringSet("extraApps", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet("extraApps", v).apply()

    // ---- עזרים ----
    fun list(s: String): List<String> = s.split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }

    fun pairs(s: String): List<Pair<String, String>> = s.split("\n").mapNotNull { line ->
        val i = line.indexOf('=')
        if (i <= 0) null else line.substring(0, i).trim() to line.substring(i + 1).trim()
    }.filter { it.first.isNotEmpty() && it.second.isNotEmpty() }

    // ---- סנכרון הגדרות מהטלפון למסך הרכב ----
    fun exportShared(): JSONObject {
        val o = JSONObject()
        for ((k, v) in sp.all) {
            if (k in localKeys) continue
            val e = JSONObject()
            when (v) {
                is Boolean -> e.put("t", "b").put("v", v)
                is String -> e.put("t", "s").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Set<*> -> e.put("t", "set").put("v", JSONArray(v.map { it.toString() }))
                else -> continue
            }
            o.put(k, e)
        }
        return o
    }

    fun importShared(o: JSONObject) {
        val ed = sp.edit()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k in localKeys) continue
            val e = o.optJSONObject(k) ?: continue
            when (e.optString("t")) {
                "b" -> ed.putBoolean(k, e.optBoolean("v"))
                "s" -> ed.putString(k, e.optString("v"))
                "f" -> ed.putFloat(k, e.optDouble("v").toFloat())
                "i" -> ed.putInt(k, e.optInt("v"))
                "l" -> ed.putLong(k, e.optLong("v"))
                "set" -> {
                    val a = e.optJSONArray("v") ?: JSONArray()
                    ed.putStringSet(k, (0 until a.length()).map { a.optString(it) }.toSet())
                }
            }
        }
        ed.apply()
    }
}
