package com.kolbaderech.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.Locale

/**
 * חיבור בין הטלפון למסך הרכב דרך הנקודה החמה.
 * הטלפון מאזין (שרת), מסך הרכב מתחבר לכתובת ה-Gateway שלו.
 */
object Link {
    const val PORT = 47321
    val connected = MutableStateFlow(false)
    val status = MutableStateFlow("לא מחובר")

    @Volatile var phoneInCall = false
    @Volatile var phoneMedia: JSONObject? = null

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var writer: PrintWriter? = null
    @Volatile private var socket: Socket? = null
    // תור שליחה יחיד: שומר על סדר ההודעות ולא פותח Thread לכל הודעה
    private val sender = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "link-send").apply { isDaemon = true }
    }
    @Volatile private var serverThread: Thread? = null
    @Volatile private var clientThread: Thread? = null
    // לאבחון: למה נסגר כל חיבור (נרשם ביומן עם משך החיבור)
    private val closeReasons = java.util.Collections.synchronizedMap(java.util.WeakHashMap<Socket, String>())

    fun obj(t: String, vararg kv: Pair<String, Any?>): JSONObject {
        val o = JSONObject().put("t", t)
        kv.forEach { o.put(it.first, it.second) }
        return o
    }

    fun send(o: JSONObject) {
        val w = writer ?: return
        val s = socket
        val line = try {
            o.toString()
        } catch (e: Throwable) {
            return
        }
        try {
            sender.execute {
                try {
                    if (writer !== w) return@execute // החיבור הוחלף בינתיים
                    w.println(line)
                    w.flush()
                    // PrintWriter בולע שגיאות כתיבה: חיבור מת → סוגרים כדי שיתחבר מחדש
                    if (w.checkError()) {
                        if (s != null) closeReasons.putIfAbsent(s, "כתיבה לחיבור נכשלה")
                        try { s?.close() } catch (e: Throwable) { }
                    }
                } catch (e: Throwable) {
                }
            }
        } catch (e: Throwable) {
        }
    }

    private fun parse(line: String): JSONObject? = try {
        JSONObject(line)
    } catch (e: Throwable) {
        null
    }

    // ------------------------------------------------------------------
    // טלפון: שרת
    // ------------------------------------------------------------------
    @Synchronized
    fun startServer(ctx: Context) {
        if (serverThread?.isAlive == true) return
        val app = ctx.applicationContext
        serverThread = Thread {
            while (true) {
                var ss: ServerSocket? = null
                try {
                    ss = ServerSocket()
                    ss.reuseAddress = true
                    ss.bind(InetSocketAddress(PORT))
                    main.post { status.value = "ממתין למסך הרכב" }
                    while (true) {
                        val s = ss.accept()
                        // חיבור חדש מהמסך (למשל אחרי ניתוק) מחליף את הישן, במקום לחכות שהישן יפוג
                        socket?.let { old -> closeReasons.putIfAbsent(old, "הוחלף בחיבור חדש מהמסך") }
                        try { socket?.close() } catch (e: Throwable) { }
                        Thread({ handle(app, s, isPhone = true) }, "link-conn").apply {
                            isDaemon = true
                            start()
                        }
                    }
                } catch (e: Throwable) {
                    try {
                        ss?.close()
                    } catch (x: Throwable) {
                    }
                    try {
                        Thread.sleep(3000)
                    } catch (ie: InterruptedException) {
                    }
                }
            }
        }.apply {
            isDaemon = true
            start()
        }
    }

    // ------------------------------------------------------------------
    // מסך רכב: לקוח
    // ------------------------------------------------------------------
    @Synchronized
    fun startClient(ctx: Context) {
        if (clientThread?.isAlive == true) return
        val app = ctx.applicationContext
        clientThread = Thread {
            while (true) {
                val ip = Prefs.linkIp.ifBlank { null } ?: gatewayIp(app)
                if (ip == null) {
                    main.post { status.value = "המסך לא מחובר לנקודה החמה" }
                } else {
                    main.post { status.value = "מחפש את הטלפון ב-$ip" }
                    val s = Socket()
                    try {
                        s.connect(InetSocketAddress(ip, PORT), 4000)
                        startPinger(s)
                        handle(app, s, isPhone = false)
                    } catch (e: Throwable) {
                    } finally {
                        try {
                            s.close()
                        } catch (e: Throwable) {
                        }
                    }
                }
                try {
                    Thread.sleep(3000)
                } catch (ie: InterruptedException) {
                }
            }
        }.apply {
            isDaemon = true
            start()
        }
    }

    private fun startPinger(s: Socket) {
        Thread {
            while (!s.isClosed) {
                send(obj("ping"))
                try {
                    Thread.sleep(5000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.apply {
            isDaemon = true
            start()
        }
    }

    @Suppress("DEPRECATION")
    private fun gatewayIp(c: Context): String? {
        try {
            val cm = c.getSystemService(ConnectivityManager::class.java)
            for (n in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(n) ?: continue
                if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue
                val lp = cm.getLinkProperties(n) ?: continue
                for (r in lp.routes) {
                    val gw = r.gateway?.hostAddress ?: continue
                    if (r.isDefaultRoute && !gw.contains(":") && gw != "0.0.0.0") return gw
                }
            }
        } catch (e: Throwable) {
        }
        try {
            val wm = c.getSystemService(WifiManager::class.java)
            val g = wm.dhcpInfo.gateway
            if (g != 0) {
                return "${g and 0xff}.${(g shr 8) and 0xff}.${(g shr 16) and 0xff}.${(g shr 24) and 0xff}"
            }
        } catch (e: Throwable) {
        }
        return null
    }

    // ------------------------------------------------------------------
    // משותף
    // ------------------------------------------------------------------
    private fun handle(app: Context, s: Socket, isPhone: Boolean) {
        val started = System.currentTimeMillis()
        var reason = "?"
        try {
            s.soTimeout = 20000
            s.tcpNoDelay = true
            val w = PrintWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8), true)
            synchronized(this) {
                socket = s
                writer = w
            }
            val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
            main.post {
                connected.value = true
                status.value = "מחובר"
                CrashGuard.safe(Unit) { onConnected(app, isPhone) }
            }
            while (true) {
                val line = reader.readLine()
                if (line == null) {
                    reason = "הצד השני סגר את החיבור"
                    break
                }
                val o = parse(line) ?: continue
                main.post { CrashGuard.safe(Unit) { onMessage(app, o, isPhone) } }
            }
        } catch (e: java.net.SocketTimeoutException) {
            reason = "timeout – לא התקבל כלום 20 שניות"
        } catch (e: Throwable) {
            reason = "${e.javaClass.simpleName}: ${e.message ?: ""}".trim()
        } finally {
            // סיבה שנקבעה מבחוץ (הוחלף / כתיבה נכשלה) קודמת לשגיאה שנגרמה מהסגירה עצמה
            closeReasons.remove(s)?.let { reason = it }
            try {
                s.close()
            } catch (e: Throwable) {
            }
            val mine = synchronized(this) {
                if (socket === s) {
                    writer = null
                    socket = null
                    true
                } else false
            }
            val secs = "%.1f".format(Locale.US, (System.currentTimeMillis() - started) / 1000.0)
            val why = "$reason, אחרי $secs שנ׳"
            if (mine) {
                main.post {
                    connected.value = false
                    status.value = "לא מחובר"
                    CrashGuard.safe(Unit) { onDisconnected(app, isPhone, why) }
                }
            } else {
                DLog.i("🔗 חיבור ישן נסגר ($why)")
            }
        }
    }

    @Volatile private var lastPrefsHash = 0

    /** שולח את ההגדרות למסך הרכב כשמשהו השתנה בטלפון. */
    fun syncPrefsIfChanged() {
        val p = Prefs.exportShared()
        val h = p.toString().hashCode()
        if (h != lastPrefsHash) {
            lastPrefsHash = h
            send(obj("prefs", "p" to p))
        }
    }

    private fun onConnected(app: Context, isPhone: Boolean) {
        DLog.i("🔗 מחובר " + if (isPhone) "למסך הרכב" else "לטלפון")
        if (isPhone) {
            lastPrefsHash = 0
            syncPrefsIfChanged()
            DriveState.start(app)
        } else {
            DriveState.start(app)
        }
    }

    private fun onDisconnected(app: Context, isPhone: Boolean, why: String) {
        DLog.i("🔗 החיבור נותק ($why)")
        phoneInCall = false
        phoneMedia = null
        if (isPhone) {
            if (!DriveState.btConnected) DriveState.stopSoon(app, 45_000)
        } else {
            DriveState.stopSoon(app, 20_000)
        }
    }

    private fun onMessage(app: Context, o: JSONObject, isPhone: Boolean) {
        when (o.optString("t")) {
            // ---- בטלפון ----
            "ping" -> if (isPhone) {
                syncPrefsIfChanged()
                send(
                    obj(
                        "pong", "inCall" to Announcer.localInCall(),
                        "media" to Media.state(app)
                    )
                )
            }
            "reply" -> if (isPhone) {
                val ok = Relay.sendReply(app, o.optString("id"), o.optString("text"))
                send(obj("done", "ok" to ok))
            }
            "cmd" -> if (isPhone) {
                val say = Commands.handle(app, o.optString("text"))
                when {
                    say == Commands.UNKNOWN -> send(obj("say", "text" to Commands.UNKNOWN_SAY))
                    say != null -> send(obj("say", "text" to say))
                }
            }
            "media" -> if (isPhone) Media.op(app, o.optString("op"))
            "callop" -> if (isPhone) CallMonitor.op(app, o.optString("op"))
            "send" -> if (isPhone) {
                val r = Contacts.message(app, o.optString("to"), o.optString("text"), o.optString("wa").ifBlank { null })
                send(obj("say", "text" to r))
            }
            "learn" -> if (isPhone) Learn.add(o.optString("k"), o.optString("v"))
            "setpref" -> if (isPhone && o.optString("k") in setOf("wakePhrase")) {
                Prefs.sp.edit().putString(o.optString("k"), o.optString("v")).apply()
                UiBus.tick.value++
            }
            "ring" -> if (!isPhone) Announcer.incomingCall(o.optString("name"), remote = true)
            "later" -> if (isPhone) {
                Store.add(Store.LATER, Store.text("${o.optString("sender")}: ${o.optString("text")}"))
            }

            // ---- במסך הרכב ----
            "log" -> if (!isPhone) DLog.fromPhone(o.optString("l"))
            "eta" -> if (isPhone) Features.setWazeEta(o.optInt("m", -1).takeIf { it >= 0 })
            "speak" -> if (isPhone) Announcer.speakForCar(o.optString("id"), o.optString("text"))
            "hush" -> if (isPhone) Announcer.hush()
            "spoken" -> if (!isPhone) Announcer.onPhoneSpoken(o.optString("id"))
            "addr" -> if (isPhone) {
                send(obj("addr_res", "id" to o.optString("id"), "addr" to Contacts.addressFor(app, o.optString("q"))))
            }
            "addr_res" -> if (!isPhone) Nav.onAddress(app, o.optString("id"), o.optString("addr").ifBlank { null })
            "pong" -> {
                phoneInCall = o.optBoolean("inCall")
                phoneMedia = o.optJSONObject("media")
            }
            "prefs" -> o.optJSONObject("p")?.let {
                Prefs.importShared(it)
                UiBus.tick.value++
                Wake.stop()
                Wake.start(app)
            }
            "msg" -> Announcer.enqueue(Msg.fromJsonWithAudio(app, o), force = true)
            "say" -> Announcer.notice(o.optString("text"))
            "done" -> if (!o.optBoolean("ok")) Announcer.notice("לא הצלחתי לשלוח את התגובה")
        }
    }
}

/** בטלפון: שומר הודעות שהועברו למסך, כדי לשלוח תגובות מהן. */
object Relay {
    private val pending = LinkedHashMap<String, Msg>()
    private val bySender = LinkedHashMap<String, Msg>()

    fun forward(m: Msg) {
        if (m.reply != null) synchronized(this) {
            pending[m.id] = m
            bySender[m.sender] = m
            while (pending.size > 100) pending.remove(pending.keys.first())
            while (bySender.size > 50) bySender.remove(bySender.keys.first())
        }
        Link.send(m.toJson())
    }

    fun remember(m: Msg) {
        if (m.reply != null) synchronized(this) {
            bySender[m.sender] = m
            while (bySender.size > 50) bySender.remove(bySender.keys.first())
        }
    }

    @Synchronized
    fun recentFor(name: String): Msg? =
        bySender.entries.lastOrNull { it.key.contains(name) || name.contains(it.key) }?.value

    fun sendReply(app: Context, id: String, text: String): Boolean {
        val m = synchronized(this) { pending[id] } ?: return false
        return Reply.send(app, m, text)
    }
}
