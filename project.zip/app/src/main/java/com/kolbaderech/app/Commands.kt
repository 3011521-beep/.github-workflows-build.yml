package com.kolbaderech.app

import android.content.Context

/** הבנת פקודות בעברית לפי מילות מפתח. עובד בלי אינטרנט ובחינם. */
object Commands {

    private fun clean(s: String) =
        s.replace(Regex("[\"״'׳?!.,]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }
    private fun word(t: String, vararg w: String): Boolean {
        val words = t.split(" ")
        return w.any { it in words }
    }

    private fun startsAny(t: String, prefixes: List<String>): String? =
        prefixes.sortedByDescending { it.length }.firstOrNull { t.startsWith(it) }

    // ---------------- תגובות ----------------
    private val replyPrefixes = listOf(
        "תעני לו", "תעני לה", "תעני להם", "תעני", "עני לו", "עני לה",
        "תגיבי לו", "תגיבי לה", "תגיבי", "תכתבי לו", "תכתבי לה", "תכתבי",
        "תשיבי לו", "תשיבי לה", "תגידי לו", "תגידי לה", "תשלחי לו", "תשלחי לה"
    )

    private val afterShin = listOf(
        "אני", "את", "אתה", "הוא", "היא", "אנחנו", "זה", "אין", "יש", "כן", "לא",
        "אגיע", "אחזור", "אתקשר", "נדבר", "נתראה", "אהיה", "הכל", "אבוא", "מגיע", "בדרך"
    )

    private fun stripShin(r: String): String {
        if (r.startsWith("ש") && r.length > 1) {
            val rest = r.substring(1)
            if (afterShin.any { rest.startsWith(it) }) return rest
        }
        return r
    }

    /** "תעני לו שאני בדרך" → "אני בדרך". אם אין פתיח של תגובה מחזיר null. */
    fun extractReply(heard: String): String? {
        val t = clean(heard)
        val p = startsAny(t, replyPrefixes) ?: return null
        return stripShin(t.removePrefix(p).trim()).ifBlank { null }
    }

    /** כשלחצו "הגב": כל מה שנאמר הוא התגובה. */
    fun replyFromAnything(heard: String): String? {
        val t = clean(heard)
        if (isCancel(t) || isStop(t)) return null
        return extractReply(t) ?: stripShin(t).ifBlank { null }
    }

    fun changeTo(heard: String): String? {
        val t = clean(heard)
        val p = startsAny(t, listOf("תשני ל", "תשני את זה ל", "תחליפי ל", "במקום זה", "לא תכתבי", "תכתבי במקום")) ?: return null
        return stripShin(t.removePrefix(p).trim()).ifBlank { null }
    }

    fun isCancel(heard: String): Boolean {
        val t = clean(heard)
        return t.split(" ").size <= 3 && word(t, "בטל", "בטלי", "תבטלי", "ביטול", "לא", "אל")
    }

    fun isYes(heard: String): Boolean = word(clean(heard), "כן", "שלחי", "תשלחי", "שלח", "בטח", "יאללה")

    fun isStop(heard: String): Boolean =
        word(clean(heard), "עצרי", "תעצרי", "עצור", "תפסיקי", "הפסיקי", "די", "תשתקי")

    // ---------------- פקודות כלליות ----------------
    /** מבצע את הפקודה. מחזיר משפט להקראה, או null אם אין מה להגיד. */
    fun handle(ctx: Context, heard: String): String? {
        val t = clean(heard)

        if (has(t, "מה השיר", "איזה שיר", "מה מתנגן", "מי שר"))
            return Media.nowPlaying(ctx) ?: "לא מתנגן כרגע שום שיר"

        if (has(t, "שקט עד סוף", "בלי הודעות", "תפסיקי להקריא", "אל תקריאי")) {
            Announcer.muted = true
            return "בסדר, לא אקריא הודעות עד סוף הנסיעה"
        }
        if (has(t, "תחזרי להקריא", "תקריאי הודעות", "תקריאי לי הודעות")) {
            Announcer.muted = false
            return "חזרתי להקריא הודעות"
        }
        if (has(t, "תקריאי שוב", "תקריאי עוד פעם", "שוב את ההודעה", "מה הוא כתב", "מה היא כתבה", "מה הם כתבו"))
            return if (Announcer.repeatLast()) null else "אין הודעה להקריא שוב"

        // ניווט
        if (has(t, "הביתה") && has(t, "סעי", "נווטי", "תנווטי", "קחי", "ניווט", "דרך")) {
            Nav.home(ctx); return null
        }
        if (has(t, "לעבודה") && has(t, "סעי", "נווטי", "תנווטי", "קחי", "ניווט")) {
            Nav.work(ctx); return null
        }
        startsAny(t, listOf("נווטי ל", "תנווטי ל", "סעי ל", "תסעי ל", "קחי אותי ל", "תיקחי אותי ל", "נווט ל", "ניווט ל"))?.let { p ->
            val q = t.removePrefix(p).trim()
            if (q.isNotEmpty()) {
                Nav.to(ctx, q); return null
            }
        }

        // שיחות
        startsAny(t, listOf("תתקשרי ל", "התקשרי ל", "תחייגי ל", "חייגי ל", "תתקשר ל", "תצלצלי ל"))?.let { p ->
            return Phone.call(ctx, t.removePrefix(p).trim())
        }

        // עוצמה (לפני "שקט")
        if (has(t, "יותר חזק", "תגבירי", "הגבירי", "חזק יותר")) {
            Media.volume(ctx, true); return null
        }
        if (has(t, "יותר חלש", "תנמיכי", "הנמיכי", "יותר בשקט", "חלש יותר")) {
            Media.volume(ctx, false); return null
        }

        // השמעת שיר
        val playP = startsAny(
            t, listOf(
                "תדליקי לי", "תדליקי", "תשמיעי לי", "תשמיעי", "שימי לי", "תשימי לי", "שימי", "תשימי",
                "נגני לי", "תנגני לי", "נגני", "תנגני", "תפעילי לי", "תפעילי"
            )
        )
        if (playP != null) {
            var q = " " + t.removePrefix(playP).trim() + " "
            val pkg = when {
                has(q, "יוטיוב") -> Media.YT_MUSIC
                has(q, "ספוטיפיי", "ספוטיפי") -> Media.SPOTIFY
                else -> null
            }
            listOf("ביוטיוב מיוזיק", "יוטיוב מיוזיק", "ביוטיוב", "יוטיוב", "בספוטיפיי", "בספוטיפי", "ספוטיפיי", "באפליקציה")
                .forEach { q = q.replace(it, " ") }
            val filler = setOf("את", "השיר", "שיר", "של", "בבקשה", "משהו", "לי", "מוזיקה", "המוזיקה", "שירים")
            val query = q.split(" ").filter { it.isNotBlank() && it !in filler }.joinToString(" ")
            if (query.isEmpty()) {
                if (pkg != null) Media.openApp(ctx, pkg) else Media.play(ctx)
            } else {
                Media.playSearch(ctx, query, pkg)
            }
            return null
        }

        // שליטה במוזיקה
        if (word(t, "עצרי", "תעצרי", "עצור", "הפסיקי", "תפסיקי", "שקט")) {
            Media.pause(ctx); return null
        }
        if (word(t, "הבא", "דלגי", "תדלגי", "הלאה")) {
            Media.next(ctx); return null
        }
        if (word(t, "הקודם", "אחורה")) {
            Media.prev(ctx); return null
        }
        if (has(t, "תמשיכי", "המשיכי", "תחזרי לשיר", "תחזרי למוזיקה", "נגני", "תנגני", "המשך")) {
            Media.play(ctx); return null
        }

        return "לא הבנתי. אפשר לומר למשל: השיר הבא, תדליקי עומר אדם, או נווטי הביתה"
    }
}
