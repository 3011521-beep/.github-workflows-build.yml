package com.kolbaderech.app

import android.app.Notification
import android.app.Person
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {

    companion object {
        @Volatile var instance: NotifListener? = null
        private val recent = LinkedHashSet<String>()
        private val autoReplied = HashSet<String>()
        private val groupCounts = HashMap<String, Int>()
        private val groupLast = HashMap<String, Long>()

        fun onDriveStart() {
            autoReplied.clear()
            groupCounts.clear()
            groupLast.clear()
        }

        /** סיכום הודעות שעדיין לא נקראו (עדיין מוצגות בטלפון). */
        fun unreadSummary(): String? {
            val l = instance ?: return null
            val active = try {
                l.activeNotifications
            } catch (e: Exception) {
                null
            } ?: return null
            val counts = LinkedHashMap<String, Int>()
            for (sbn in active) {
                val def = SupportedApps.find(sbn.packageName) ?: continue
                if (!Prefs.appEnabled(def)) continue
                if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) continue
                if (sbn.isOngoing) continue
                counts[def.label] = (counts[def.label] ?: 0) + 1
            }
            if (counts.isEmpty()) return null
            val parts = counts.map { (app, n) -> if (n == 1) "אחת ב$app" else "$n ב$app" }
            return "מחכות לך הודעות שלא נקראו: " + parts.joinToString(", ")
        }
    }

    private val main = Handler(Looper.getMainLooper())

    override fun onListenerConnected() {
        instance = this
        if (!Prefs.isCar) Link.startServer(applicationContext)
    }

    override fun onListenerDisconnected() {
        instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (e: Exception) {
        }
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun handle(sbn: StatusBarNotification) {
        if (Prefs.isCar) return
        val pkg = sbn.packageName
        if (pkg == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (sbn.isOngoing) return

        val def = SupportedApps.find(pkg)
        val enabled = if (def != null) Prefs.appEnabled(def) else pkg in Prefs.extraApps
        if (DriveState.active.value && def == null && n.category == Notification.CATEGORY_MESSAGE) {
            Store.seenPackages = Store.seenPackages + pkg
        }
        if (!enabled) return
        if (!DriveState.active.value) return

        val ex = n.extras
        var title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: return
        var text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: ""
        var body = ""
        var isGroup = false
        var groupName: String? = null
        val isEmail = def?.isEmail ?: false

        if (isEmail) {
            val big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim() ?: ""
            body = big.removePrefix(text).trim()
        } else {
            @Suppress("DEPRECATION")
            val msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
            val last = msgs?.lastOrNull() as? Bundle
            if (last != null) {
                last.getCharSequence("text")?.toString()?.let { text = it.trim() }
                var sender = last.getCharSequence("sender")?.toString()
                if (sender == null && Build.VERSION.SDK_INT >= 28) {
                    @Suppress("DEPRECATION")
                    sender = (last.getParcelable<android.os.Parcelable>("sender_person") as? Person)?.name?.toString()
                }
                isGroup = ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)
                groupName = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
                if (isGroup && groupName != null && sender != null) {
                    title = "$sender בקבוצת $groupName"
                } else if (!sender.isNullOrBlank()) {
                    title = sender
                }
            }
        }

        val realMsg = ex.containsKey(Notification.EXTRA_MESSAGES)
        if (text.isBlank() || isSystemText(text, realMsg) || isSystemText(title, realMsg)) return

        // התראות מערכת (גיבוי, העלאה, הורדה, "מחפש הודעות") – לא הודעות אמיתיות
        if (n.category in setOf(
                Notification.CATEGORY_PROGRESS, Notification.CATEGORY_SERVICE,
                Notification.CATEGORY_SYSTEM, Notification.CATEGORY_STATUS, Notification.CATEGORY_ERROR
            )
        ) return
        if (ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0) > 0 || ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)) return
        if (!isEmail) {
            val hasMessages = ex.containsKey(Notification.EXTRA_MESSAGES)
            if (!hasMessages && n.category != Notification.CATEGORY_MESSAGE) return
        }
        val label = def?.label ?: appLabel(pkg)
        if (title.equals(label, ignoreCase = true) || title.equals("WhatsApp", ignoreCase = true)) {
            if (!ex.containsKey(Notification.EXTRA_MESSAGES)) return
        }

        val key = "$pkg|$title|$text"
        if (recent.contains(key)) return
        recent.add(key)
        if (recent.size > 400) recent.remove(recent.first())

        if (Prefs.spamFilter) {
            val lower = (title + " " + text).lowercase()
            if (Prefs.list(Prefs.spamWords).any { lower.contains(it.lowercase()) }) return
        }

        val actions = n.actions ?: emptyArray()
        val reply = actions.firstOrNull {
            Build.VERSION.SDK_INT >= 28 && it.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY &&
                !it.remoteInputs.isNullOrEmpty()
        } ?: actions.firstOrNull { !it.remoteInputs.isNullOrEmpty() }

        val vip = Prefs.list(Prefs.vipNames).any { title.contains(it) }
        val urgent = vip || text.contains("דחוף")
        val appName = def?.label ?: appLabel(pkg)

        // מענה אוטומטי "אני נוהג" (פעם אחת לכל אדם בנסיעה)
        if (Prefs.autoReplyDriving && reply != null && !isGroup && autoReplied.add("$pkg|$title")) {
            Reply.send(applicationContext, Msg(pkg = pkg, app = appName, sender = title, text = "", reply = reply), Prefs.autoReplyText)
        }

        // קבוצות
        if (isGroup && !vip) {
            when (Prefs.groupMode) {
                "none" -> return
                "mentions" -> {
                    val me = Prefs.myName.trim()
                    if (!(text.contains("@") || (me.isNotEmpty() && text.contains(me)))) return
                }
                "summary" -> {
                    summarize(groupName ?: title, appName)
                    return
                }
            }
        }
        // רק אנשים חשובים: השאר בסיכום
        if (Prefs.vipOnly && !vip && !isEmail) {
            summarize("others", appName)
            return
        }

        val m = Msg(
            pkg = pkg, app = appName, sender = title, text = text, body = body,
            isEmail = isEmail, reply = reply, urgent = urgent, isGroup = isGroup
        )
        Pipeline.process(applicationContext, m)
    }

    private fun summarize(group: String, app: String) {
        val now = System.currentTimeMillis()
        groupCounts[group] = (groupCounts[group] ?: 0) + 1
        val last = groupLast[group] ?: 0L
        if (now - last < 10 * 60_000) return
        val count = groupCounts[group] ?: 1
        groupCounts[group] = 0
        groupLast[group] = now
        val txt = if (group == "others") {
            if (count == 1) "הודעה חדשה ב$app" else "$count הודעות חדשות"
        } else {
            if (count == 1) "הודעה חדשה בקבוצת $group" else "$count הודעות חדשות בקבוצת $group"
        }
        main.post { Out.say(txt) }
    }

    private fun isSystemText(t: String, realMsg: Boolean): Boolean {
        val l = t.lowercase()
        if (realMsg) return Regex("^\\d+ (new messages|הודעות חדשות)").containsMatchIn(t)
        val junk = listOf(
            "checking for new messages", "מחפש הודעות", "בודק הודעות", "בודק אם יש הודעות",
            "גיבוי", "מגבה", "backup", "backing up", "משחזר", "restoring",
            "מעלה", "uploading", "מוריד", "downloading", "מתחבר", "connecting",
            "whatsapp web", "וואטסאפ ווב", "is active", "פעיל במכשיר", "sending", "שולח…"
        )
        if (junk.any { l.contains(it) }) return true
        if (Regex("^\\d+ (new messages|הודעות חדשות)").containsMatchIn(t)) return true
        return false
    }
}

/** עיבוד לפני הקראה: תרגום וסיכום, ואז הקראה בטלפון או העברה למסך הרכב. */
object Pipeline {
    private val main = Handler(Looper.getMainLooper())

    fun process(app: android.content.Context, m: Msg) {
        if (Prefs.translate && !m.isEmail && Translate.needs(m.text)) {
            var done = false
            val finish = { t: String? ->
                if (!done) {
                    done = true
                    val next = if (t != null) m.copy(text = "(מתורגם) $t") else m
                    summarizeThenDeliver(next)
                }
            }
            main.postDelayed({ finish(null) }, 6000)
            Translate.run(m.text) { t -> main.post { finish(t) } }
            return
        }
        summarizeThenDeliver(m)
    }

    private fun summarizeThenDeliver(m: Msg) {
        if (Prefs.summarizeLong && Gemini.available() && !m.isEmail && m.text.length > 400) {
            var done = false
            val finish = { s: String? ->
                if (!done) {
                    done = true
                    deliver(if (s != null) m.copy(text = "סיכום: $s") else m)
                }
            }
            main.postDelayed({ finish(null) }, 8000)
            Gemini.summarize(m.text) { s -> finish(s) }
            return
        }
        deliver(m)
    }

    private fun deliver(m: Msg) {
        Relay.remember(m)
        if (!Prefs.isCar && Link.connected.value) {
            Announcer.addHistory(m.sender, m.app, m.text)
            Store.inc("messages")
            Relay.forward(m)
        } else {
            Announcer.enqueue(m)
        }
    }
}

/** אומר משפט במכשיר הנכון: במסך הרכב אם הוא מחובר, אחרת בטלפון. */
object Out {
    fun say(text: String) {
        if (!Prefs.isCar && Link.connected.value) Link.send(Link.obj("say", "text" to text))
        else Announcer.notice(text)
    }
}
