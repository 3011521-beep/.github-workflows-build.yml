package com.kolbaderech.app

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** קובץ אקסל אמיתי (xlsx) בלי ספריות חיצוניות. */
class Sheet(val name: String, val widths: List<Int> = emptyList()) {
    val rows = ArrayList<List<Any?>>()
    val boldRows = HashSet<Int>()
    fun header(vararg v: Any?) {
        boldRows.add(rows.size); rows.add(v.toList())
    }
    fun row(vararg v: Any?) = rows.add(v.toList())
}

object Xlsx {
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun col(i: Int): String {
        var n = i + 1
        val sb = StringBuilder()
        while (n > 0) {
            val r = (n - 1) % 26
            sb.insert(0, ('A' + r))
            n = (n - 1) / 26
        }
        return sb.toString()
    }

    private fun sheetXml(sh: Sheet): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
        sb.append("""<sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews>""")
        val maxCols = sh.rows.maxOfOrNull { it.size } ?: 1
        sb.append("<cols>")
        for (i in 0 until maxCols) {
            val w = sh.widths.getOrNull(i) ?: 16
            sb.append("""<col min="${i + 1}" max="${i + 1}" width="$w" customWidth="1"/>""")
        }
        sb.append("</cols><sheetData>")
        sh.rows.forEachIndexed { r, cells ->
            val style = if (r in sh.boldRows) " s=\"1\"" else ""
            sb.append("""<row r="${r + 1}">""")
            cells.forEachIndexed { c, v ->
                val ref = col(c) + (r + 1)
                when (v) {
                    null -> {}
                    is Number -> sb.append("""<c r="$ref"$style><v>${v}</v></c>""")
                    else -> sb.append("""<c r="$ref" t="inlineStr"$style><is><t xml:space="preserve">${esc(v.toString())}</t></is></c>""")
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    fun write(file: File, sheets: List<Sheet>) {
        ZipOutputStream(FileOutputStream(file)).use { z ->
            fun put(name: String, content: String) {
                z.putNextEntry(ZipEntry(name))
                z.write(content.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            val ct = StringBuilder()
            ct.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
            ct.append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
            ct.append("""<Default Extension="xml" ContentType="application/xml"/>""")
            ct.append("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
            ct.append("""<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""")
            sheets.indices.forEach {
                ct.append("""<Override PartName="/xl/worksheets/sheet${it + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
            }
            ct.append("</Types>")
            put("[Content_Types].xml", ct.toString())
            put(
                "_rels/.rels",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
            )
            val wb = StringBuilder()
            wb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>""")
            sheets.forEachIndexed { i, sh -> wb.append("""<sheet name="${esc(sh.name.take(31))}" sheetId="${i + 1}" r:id="rId${i + 1}"/>""") }
            wb.append("</sheets></workbook>")
            put("xl/workbook.xml", wb.toString())
            val rels = StringBuilder()
            rels.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
            sheets.indices.forEach {
                rels.append("""<Relationship Id="rId${it + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${it + 1}.xml"/>""")
            }
            rels.append("""<Relationship Id="rId${sheets.size + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""")
            rels.append("</Relationships>")
            put("xl/_rels/workbook.xml.rels", rels.toString())
            put(
                "xl/styles.xml",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="11"/><name val="Arial"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>"""
            )
            sheets.forEachIndexed { i, sh -> put("xl/worksheets/sheet${i + 1}.xml", sheetXml(sh)) }
        }
    }
}

/** דוח נסיעות וספר רכב לאקסל. */
object Report {
    private fun r1(d: Double) = Math.round(d * 10) / 10.0

    fun build(c: Context): File {
        val day = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val hm = SimpleDateFormat("HH:mm", Locale.getDefault())
        val mon = SimpleDateFormat("MM/yyyy", Locale.getDefault())
        val trips = Store.list(Store.TRIPS)
        fun typeName(o: JSONObject) = if (o.optString("type") == "business") "עסקי" else "פרטי"

        // נסיעות
        val t = Sheet("נסיעות", listOf(12, 9, 9, 9, 9, 28, 28, 9, 12))
        t.header("תאריך", "יציאה", "הגעה", "דקות", "ק״מ", "מוצא", "יעד", "סוג", "קילומטראז׳")
        trips.forEach { o ->
            val s = o.optLong("start")
            val e = o.optLong("end")
            val odo = o.optDouble("odo", -1.0)
            t.row(
                day.format(Date(s)), hm.format(Date(s)), hm.format(Date(e)), (e - s) / 60_000,
                r1(o.optDouble("km")), o.optString("from"), o.optString("to"), typeName(o),
                if (odo > 0) odo.toLong() else null
            )
        }

        // סיכום חודשי
        val m = Sheet("סיכום חודשי", listOf(12, 10, 12, 12, 12, 12))
        m.header("חודש", "נסיעות", "סה״כ ק״מ", "עסקי ק״מ", "פרטי ק״מ", "שעות נהיגה")
        trips.groupBy { mon.format(Date(it.optLong("start"))) }.forEach { (month, list) ->
            val total = list.sumOf { it.optDouble("km") }
            val biz = list.filter { it.optString("type") == "business" }.sumOf { it.optDouble("km") }
            val mins = list.sumOf { (it.optLong("end") - it.optLong("start")) / 60_000 }
            m.row(month, list.size, r1(total), r1(biz), r1(total - biz), r1(mins / 60.0))
        }

        // ספר רכב
        val b = Sheet("ספר רכב", listOf(26, 16, 30))
        b.header("נתון", "ערך", "")
        val odo = CarBook.odometer()
        b.row("קילומטראז׳ משוער עכשיו", odo?.toLong() ?: "לא הוגדר")
        b.row("טיפול כל (ק״מ)", CarBook.interval().toLong())
        b.row("טיפול אחרון (ק״מ)", Prefs.lastServiceOdo.toDoubleOrNull()?.toLong() ?: "לא נרשם")
        b.row("טיפול הבא (ק״מ)", CarBook.nextServiceOdo()?.toLong() ?: "")
        b.row("נשאר עד הטיפול (ק״מ)", CarBook.kmToService()?.toLong() ?: "")
        b.row("טסט", Prefs.testDate)
        b.row("ביטוח", Prefs.insuranceDate)
        b.row("טיפול לפי תאריך", Prefs.serviceDate)
        b.row()
        b.header("טיפולים", "קילומטראז׳", "הערה")
        Store.list(Store.SERVICE).forEach { o ->
            val k = o.optDouble("odo", -1.0)
            b.row(day.format(Date(o.optLong("time"))), if (k > 0) k.toLong() else null, o.optString("note"))
        }

        // דלק
        val f = Sheet("דלק", listOf(14, 12))
        f.header("תאריך", "סכום (₪)")
        Store.list(Store.FUEL).forEach { o -> f.row(day.format(Date(o.optLong("time"))), o.optInt("amount")) }

        val dir = File(c.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "kol-baderech-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".xlsx")
        Xlsx.write(file, listOf(t, m, b, f))
        return file
    }

    fun share(c: Context) {
        val file = build(c)
        val uri = FileProvider.getUriForFile(c, c.packageName + ".files", file)
        val i = Intent(Intent.ACTION_SEND)
            .setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(i, "דוח נסיעות").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
