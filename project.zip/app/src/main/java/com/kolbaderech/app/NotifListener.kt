package com.kolbaderech.app

import android.app.Notification
import android.app.Person
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {

    private val recent = LinkedHashSet<String>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (e: Exception) {
            // לעולם לא מפילים את השירות בגלל התראה אחת
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val def = SupportedApps.find(sbn.packageName) ?: return
        if (!Prefs.appEnabled(def)) return
        if (!DriveState.active.value) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (sbn.isOngoing) return

        val ex = n.extras
        var title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: return
        var text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: ""
        var body = ""

        if (def.isEmail) {
            val big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim() ?: ""
            body = big.removePrefix(text).trim()
        } else {
            @Suppress("DEPRECATION")
            val msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
            val last = msgs?.lastOrNull() as? Bundle
            if (last != null) {
                last.getCharSequence("text")?.toString()?.let { text = it.trim() }
                var sender = last.getCharSequence("sender")?.toString()
                if (sender == null && Build.VERSION.SDK_INT >= 28) {
                    @Suppress("DEPRECATION")
                    sender = (last.getParcelable<android.os.Parcelable>("sender_person") as? Person)?.name?.toString()
                }
                val isGroup = ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)
                val conv = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
                if (isGroup && conv != null && sender != null) {
                    title = "$sender בקבוצת $conv"
                } else if (sender != null && sender.isNotBlank()) {
                    title = sender
                }
            }
        }

        if (text.isBlank()) return
        if (isSystemText(text)) return

        val key = "${sbn.packageName}|$title|$text"
        if (recent.contains(key)) return
        recent.add(key)
        if (recent.size > 300) recent.remove(recent.first())

        val actions = n.actions ?: emptyArray()
        val reply = actions.firstOrNull {
            Build.VERSION.SDK_INT >= 28 && it.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY &&
                !it.remoteInputs.isNullOrEmpty()
        } ?: actions.firstOrNull { !it.remoteInputs.isNullOrEmpty() }

        Announcer.enqueue(
            Msg(
                pkg = sbn.packageName,
                app = def.label,
                sender = title,
                text = text,
                body = body,
                isEmail = def.isEmail,
                reply = reply,
                urgent = text.contains("דחוף")
            )
        )
    }

    private fun isSystemText(t: String): Boolean {
        val l = t.lowercase()
        if (l.contains("checking for new messages") || t.contains("מחפש הודעות חדשות")) return true
        if (Regex("^\\d+ (new messages|הודעות חדשות)").containsMatchIn(t)) return true
        return false
    }
}
