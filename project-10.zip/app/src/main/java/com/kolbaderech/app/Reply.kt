package com.kolbaderech.app

import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle

object Reply {
    fun send(app: Context, m: Msg, text: String): Boolean = try {
        val action = m.reply ?: throw IllegalStateException()
        val inputs = action.remoteInputs ?: throw IllegalStateException()
        val bundle = Bundle()
        inputs.forEach { bundle.putCharSequence(it.resultKey, text) }
        val intent = Intent()
        RemoteInput.addResultsToIntent(inputs, intent, bundle)
        action.actionIntent.send(app, 0, intent)
        true
    } catch (e: Exception) {
        false
    }
}
