package com.kolbaderech.app

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * תופס קריסות: שומר את השגיאה לקובץ ומציג אותה בפתיחה הבאה.
 * אחרי שתי קריסות רצופות האפליקציה עולה ב"מצב בטוח" בלי להפעיל שירותים ברקע.
 */
object CrashGuard {
    private fun prefs(c: Context) = c.getSharedPreferences("crash", Context.MODE_PRIVATE)
    private fun file(c: Context) = File(c.filesDir, "last_crash.txt")

    fun install(app: Context) {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val ver = try {
                    app.packageManager.getPackageInfo(app.packageName, 0).versionName
                } catch (x: Throwable) {
                    "?"
                }
                val txt = "גרסה $ver · ${SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date())}\n" +
                    "תפקיד: ${try { Prefs.role } catch (x: Throwable) { "?" }} · אנדרואיד ${android.os.Build.VERSION.SDK_INT}" +
                    " · ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\n" +
                    "Thread: ${t.name}\n$sw"
                file(app).writeText(txt)
                val p = prefs(app)
                val now = System.currentTimeMillis()
                val recent = now - p.getLong("at", 0) < 3 * 60_000
                p.edit().putLong("at", now).putInt("count", if (recent) p.getInt("count", 0) + 1 else 1)
                    .putBoolean("seen", false).commit()
            } catch (x: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }
    }

    fun safeMode(c: Context): Boolean {
        val p = prefs(c)
        return p.getInt("count", 0) >= 2 && System.currentTimeMillis() - p.getLong("at", 0) < 10 * 60_000
    }

    fun lastCrash(c: Context): String? {
        if (prefs(c).getBoolean("seen", true)) return null
        val f = file(c)
        return if (f.exists()) f.readText() else null
    }

    fun dismiss(c: Context) {
        prefs(c).edit().putBoolean("seen", true).putInt("count", 0).apply()
    }

    /** מריץ קוד בלי שקריסה בו תפיל את כל האפליקציה. */
    inline fun <T> safe(default: T, block: () -> T): T = try {
        block()
    } catch (e: Throwable) {
        default
    }
}
