package com.kolbaderech.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.kolbaderech.app.ui.AppTheme
import com.kolbaderech.app.ui.Avatar
import com.kolbaderech.app.ui.BigButton
import com.kolbaderech.app.ui.C
import com.kolbaderech.app.ui.CardBox
import com.kolbaderech.app.ui.ToggleRow
import com.kolbaderech.app.ui.SenderWithApp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { AppRoot() } }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        UiBus.tick.value = UiBus.tick.value + 1
        if (Prefs.role != null && !CrashGuard.safeMode(this)) {
            if (Prefs.isCar) App.startCarLink(this) else {
                Link.startServer(this)
                CallMonitor.register(this)
                Prefs.waBoth = Contacts.installed(this, "com.whatsapp") && Contacts.installed(this, "com.whatsapp.w4b")
            }
            CrashGuard.safe(Unit) { Updater.autoCheck(this) }
        }
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("listen", false) == true) {
            i.removeExtra("listen")
            Announcer.listenCommand()
        }
    }
}

// ------------------------------------------------------------------
// הרשאות ועזרים
// ------------------------------------------------------------------
object Perms {
    fun runtimeList(): Array<String> {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (!Prefs.isCar) {
            l += listOf(
                Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS, Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR,
                Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS
            )
            if (Build.VERSION.SDK_INT >= 31) l.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    fun granted(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    fun runtimeOk(c: Context) = runtimeList().all { granted(c, it) }
    fun backgroundLocOk(c: Context) =
        Build.VERSION.SDK_INT < 29 || granted(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    fun listenerOk(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
    fun overlayOk(c: Context) = Settings.canDrawOverlays(c)
    fun batteryOk(c: Context) = c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
    fun allOk(c: Context) = runtimeOk(c) && listenerOk(c) && overlayOk(c)

    @SuppressLint("MissingPermission")
    fun bondedDevices(c: Context): List<Pair<String, String>> {
        if (Build.VERSION.SDK_INT >= 31 && !granted(c, Manifest.permission.BLUETOOTH_CONNECT)) return emptyList()
        val adapter = c.getSystemService(BluetoothManager::class.java)?.adapter ?: return emptyList()
        return try {
            adapter.bondedDevices.map { (it.name ?: it.address) to it.address }.sortedBy { it.first }
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    fun currentLocation(c: Context): Location? {
        if (!granted(c, Manifest.permission.ACCESS_FINE_LOCATION)) return null
        val lm = c.getSystemService(LocationManager::class.java) ?: return null
        val a = try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (e: Exception) { null }
        val b = try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (e: Exception) { null }
        return listOfNotNull(a, b).maxByOrNull { it.time }
    }

    fun launcherApps(c: Context): List<Pair<String, String>> {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return try {
            pm.queryIntentActivities(i, 0)
                .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .distinctBy { it.second }
                .sortedBy { it.first }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun appLabel(c: Context, pkg: String): String = try {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}

@Composable
fun AppRoot() {
    val tick by UiBus.tick.collectAsState()
    var role by remember(tick) { mutableStateOf(Prefs.role) }
    var screen by remember { mutableStateOf("home") }
    val ctx = LocalContext.current
    BackHandler(enabled = screen != "home") { screen = "home" }

    var crash by remember { mutableStateOf(CrashGuard.lastCrash(ctx)) }
    crash?.let { txt ->
        CrashScreen(txt, onDone = {
            CrashGuard.dismiss(ctx)
            crash = null
        }, onReset = {
            CrashGuard.dismiss(ctx)
            Prefs.role = null
            role = null
            crash = null
        })
        return
    }

    if (role == null) {
        RoleScreen { r ->
            Prefs.role = r
            role = r
            if (r == "car") App.startCarLink(ctx) else Link.startServer(ctx)
        }
        return
    }
    when (screen) {
        "settings" -> if (Prefs.isCar) CarSettingsScreen(onBack = { screen = "home" }, onRole = {
            Prefs.role = null; role = null; screen = "home"
        }) else SettingsScreen(onBack = { screen = "home" }, onRole = {
            Prefs.role = null; role = null; screen = "home"
        })
        "data" -> DataScreen { screen = "home" }
        else -> if (Prefs.isCar) CarHomeScreen(onSettings = { screen = "settings" })
        else HomeScreen(onSettings = { screen = "settings" }, onData = { screen = "data" })
    }
}

// ------------------------------------------------------------------
// מסך שגיאה אחרי קריסה
// ------------------------------------------------------------------
@Composable
fun CrashScreen(text: String, onDone: () -> Unit, onReset: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("האפליקציה קרסה בפעם הקודמת", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = C.Amber)
        Text("צלם את המסך הזה ושלח לי, או לחץ „שתף“. כדי לא לקרוס שוב, השירותים ברקע לא הופעלו הפעם.",
            color = C.Muted, fontSize = 14.sp)
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.Surface).padding(12.dp)
        ) {
            Text(
                text.lines().take(40).joinToString("\n"), fontSize = 12.sp, color = C.Soft,
                modifier = Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState())
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton("שתף", null, C.Teal, C.OnTeal, Modifier.weight(1f)) {
                try {
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                    ctx.startActivity(Intent.createChooser(i, "שגיאה").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                }
            }
            BigButton("המשך", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { onDone() }
            BigButton("בחר תפקיד מחדש", null, C.Surface, C.Text, Modifier.weight(1.3f), outlined = true) { onReset() }
        }
    }
}

// ------------------------------------------------------------------
// בחירת תפקיד
// ------------------------------------------------------------------
@Composable
fun RoleScreen(onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("נוגה", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
        Text("על איזה מכשיר האפליקציה מותקנת עכשיו?", color = C.Muted, fontSize = 17.sp, textAlign = TextAlign.Center)
        BigButton("זה הטלפון שלי", null, C.Amber, C.OnAmber, Modifier.fillMaxWidth()) { onPick("phone") }
        BigButton("זה מסך הרכב", R.drawable.ic_car, C.Teal, C.OnTeal, Modifier.fillMaxWidth()) { onPick("car") }
        Text(
            "מתקינים את אותו קובץ גם בטלפון וגם במסך הרכב. הטלפון קולט את ההתראות, ומסך הרכב מקריא, מקשיב ופותח את וייז.",
            color = C.Muted, fontSize = 14.sp, textAlign = TextAlign.Center
        )
    }
}

// ------------------------------------------------------------------
// מסך בית בטלפון
// ------------------------------------------------------------------
@Composable
fun HomeScreen(onSettings: () -> Unit, onData: () -> Unit) {
    val ctx = LocalContext.current
    val active by DriveState.active.collectAsState()
    val linked by Link.connected.collectAsState()
    val history by Announcer.history.collectAsState()
    val tick by UiBus.tick.collectAsState()
    var autoRead by remember { mutableStateOf(Prefs.autoRead) }
    val permsOk = remember(tick) { Perms.allOk(ctx) }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Header("העוזר הקולי שלך לרכב", onSettings)

        if (!permsOk) WarningBar("חסרות הרשאות כדי שהאפליקציה תעבוד. לחץ כאן להשלמה", onSettings)
        val upd by Updater.available.collectAsState()
        upd?.let { u -> WarningBar("יש גרסה חדשה (${u.build}) – לחץ לעדכון") { Updater.downloadAndInstall(ctx) } }

        CardBox {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(64.dp).clip(CircleShape).background(if (active) C.TealBg else C.Border),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(painterResource(R.drawable.ic_car), contentDescription = null,
                        tint = if (active) C.Teal else C.Muted, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (active) "מצב נהיגה פעיל" else "ממתין לרכב", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        when {
                            linked -> "מחובר למסך הרכב – ההקראה שם"
                            active -> "מקריא כאן בטלפון"
                            else -> "יופעל לבד כשמסך הרכב יתחבר"
                        },
                        color = C.Muted, fontSize = 15.sp
                    )
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(C.Border))
            ToggleRow("הקראה אוטומטית", "בלי שאלות, המוזיקה חוזרת לבד", autoRead) {
                autoRead = it; Prefs.autoRead = it
            }
            Text(
                if (active) "סיים נהיגה ידנית" else "הפעל מצב נהיגה ידנית (לבדיקה)",
                color = C.Amber, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { if (active) DriveState.stop(ctx) else DriveState.start(ctx) }
                    .padding(vertical = 6.dp)
            )
        }

        BigButton("הנתונים שלי: חניה, קניות, פתקים ונסיעות", null, C.Surface, C.Text, Modifier.fillMaxWidth(), outlined = true) { onData() }

        Text("הוקרא לאחרונה", color = C.Muted, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        HistoryList(history, Modifier.weight(1f))

        MicButton("לחץ ודבר: „השיר הבא“, „נווטי הביתה“…")
    }
}

@Composable
private fun Header(sub: String, onSettings: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("נוגה", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text(sub, color = C.Muted, fontSize = 14.sp)
        }
        Box(
            Modifier.size(48.dp).clip(CircleShape).background(C.Surface)
                .border(1.dp, C.Border, CircleShape).clickable { onSettings() },
            contentAlignment = Alignment.Center
        ) {
            Icon(painterResource(R.drawable.ic_settings), contentDescription = "הגדרות", tint = C.Text, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
private fun WarningBar(text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFF3A2A0E))
            .clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = C.Amber, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun HistoryList(history: List<HistoryItem>, modifier: Modifier) {
    if (history.isEmpty()) {
        Text("עוד לא הוקראו הודעות. בהגדרות יש כפתור „הודעת בדיקה“.", color = C.Muted, fontSize = 15.sp, modifier = modifier)
    } else {
        LazyColumn(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(history) { h -> HistoryRow(h) }
        }
    }
}

@Composable
private fun MicButton(hint: String) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier.size(96.dp).clip(CircleShape).background(C.Amber).clickable { Announcer.listenCommand() },
            contentAlignment = Alignment.Center
        ) {
            Icon(painterResource(R.drawable.ic_mic), contentDescription = "דבר אליי", tint = C.OnAmber, modifier = Modifier.size(40.dp))
        }
        Text(hint, color = C.Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun HistoryRow(h: HistoryItem) {
    val time = remember(h.time) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(h.time)) }
    val replyable = h.canReply && h.id != null
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.Surface)
            .then(if (replyable) Modifier.clickable { Announcer.replyTo(h.id!!) } else Modifier)
            .padding(16.dp),
        verticalAlignment = Alignment.Top
    ) {
        SenderWithApp(h.sender, h.pkg, 44.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(h.sender, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f, fill = false), maxLines = 1)
                Spacer(Modifier.width(8.dp))
                Text("${h.app} · $time", color = C.Muted, fontSize = 13.sp)
            }
            Text(h.text, color = C.Soft, fontSize = 15.sp, maxLines = 2)
        }
        if (replyable) {
            Spacer(Modifier.width(8.dp))
            Row(
                Modifier.clip(RoundedCornerShape(14.dp)).background(C.TealBg).padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(painterResource(R.drawable.ic_mic), contentDescription = null, tint = C.Teal, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("הגב", color = C.Teal, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ------------------------------------------------------------------
// מסך בית במסך הרכב (רחב)
// ------------------------------------------------------------------
@Composable
fun CarHomeScreen(onSettings: () -> Unit) {
    val linked by Link.connected.collectAsState()
    val status by Link.status.collectAsState()
    val history by Announcer.history.collectAsState()
    val tiles = listOf(
        "פתח שער" to "תפתחי את השער", "הביתה" to "סעי הביתה",
        "לעבודה" to "סעי לעבודה", "תחנת דלק" to "תחנת דלק",
        "מה השיר?" to "מה השיר", "חדשות" to "מה החדשות",
        "רדיו" to "תדליקי רדיו", "שקט בנסיעה" to "שקט עד סוף הנסיעה"
    )
    Row(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Column(
            Modifier.weight(0.28f).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Header(if (linked) "מחובר לטלפון" else status, onSettings)
            val ctx = LocalContext.current
            val upd by Updater.available.collectAsState()
            upd?.let { u -> WarningBar("גרסה חדשה (${u.build}) – לחץ לעדכון") { Updater.downloadAndInstall(ctx) } }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(132.dp).clip(CircleShape).background(C.Amber).clickable { Announcer.listenCommand() },
                contentAlignment = Alignment.Center
            ) {
                Icon(painterResource(R.drawable.ic_mic), contentDescription = "דבר אליי", tint = C.OnAmber, modifier = Modifier.size(56.dp))
            }
            Text("דבר אליי", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
        }
        Column(Modifier.weight(0.4f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            tiles.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { (label, cmd) ->
                        Box(
                            Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(22.dp))
                                .background(C.Surface).border(1.dp, C.Border, RoundedCornerShape(22.dp))
                                .clickable { Announcer.runText(cmd) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(label, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
        Column(Modifier.weight(0.32f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("הודעות אחרונות", color = C.Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            HistoryList(history, Modifier.weight(1f))
        }
    }
}
