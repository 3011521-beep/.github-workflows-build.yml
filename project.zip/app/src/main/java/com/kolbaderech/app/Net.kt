package com.kolbaderech.app

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Net {
    val main = Handler(Looper.getMainLooper())

    fun get(url: String): String? = request(url, null)
    fun post(url: String, body: String): String? = request(url, body)

    private fun request(url: String, body: String?): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 15000
            c.setRequestProperty("User-Agent", "KolBaderech/1.0")
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            if (c.responseCode !in 200..299) null
            else c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }

    /** מריץ ברקע ומחזיר תוצאה ב-Main thread. */
    fun <T> async(work: () -> T?, done: (T?) -> Unit) {
        Thread {
            val r = try {
                work()
            } catch (e: Exception) {
                null
            }
            main.post { done(r) }
        }.start()
    }

    // ---------------- מזג אוויר (Open-Meteo, חינמי, בלי מפתח) ----------------
    fun weather(lat: Double, lng: Double): String? {
        if (lat == 0.0 && lng == 0.0) return null
        val res = get(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lng" +
                "&current=temperature_2m,weather_code&hourly=precipitation_probability&forecast_hours=4&timezone=auto"
        ) ?: return null
        val o = JSONObject(res)
        val cur = o.getJSONObject("current")
        val temp = Math.round(cur.getDouble("temperature_2m"))
        val code = cur.optInt("weather_code")
        val probs = o.optJSONObject("hourly")?.optJSONArray("precipitation_probability")
        var maxRain = 0
        if (probs != null) for (i in 0 until probs.length()) maxRain = maxOf(maxRain, probs.optInt(i))
        val desc = when (code) {
            0 -> "בהיר"
            1, 2, 3 -> "מעונן חלקית"
            45, 48 -> "ערפל"
            in 51..67 -> "גשום"
            in 71..77 -> "שלג"
            in 80..82 -> "ממטרים"
            in 95..99 -> "סופות רעמים"
            else -> ""
        }
        var s = "בחוץ $temp מעלות" + if (desc.isNotEmpty()) ", $desc" else ""
        if (maxRain >= 50) s += ". צפוי גשם בשעות הקרובות, סע בזהירות"
        return s
    }

    fun rainSoon(lat: Double, lng: Double): Boolean {
        val w = weather(lat, lng) ?: return false
        return w.contains("צפוי גשם")
    }

    // ---------------- חדשות (RSS של ynet) ----------------
    fun news(): String? {
        val xml = get("https://www.ynet.co.il/Integration/StoryRss2.xml") ?: return null
        val re = Regex("<title>(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?</title>", RegexOption.DOT_MATCHES_ALL)
        val titles = re.findAll(xml).map { it.groupValues[1].trim() }.filter { it.isNotEmpty() }.drop(1).take(5).toList()
        if (titles.isEmpty()) return null
        return "הכותרות עכשיו: " + titles.joinToString(". ")
    }

    // ---------------- שערי מטבע ----------------
    fun convert(amount: Double, from: String, to: String): Double? {
        val res = get("https://open.er-api.com/v6/latest/$from") ?: return null
        val rate = JSONObject(res).getJSONObject("rates").optDouble(to, Double.NaN)
        return if (rate.isNaN()) null else amount * rate
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

/** Gemini: הבנת משפטים חופשיים, תשובות לשאלות וסיכום הודעות ארוכות. */
object Gemini {
    fun available() = Prefs.geminiKey.isNotBlank()

    private fun call(prompt: String): String? {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/${Prefs.geminiModel.trim()}:generateContent?key=" +
            Net.enc(Prefs.geminiKey.trim())
        val body = JSONObject().put(
            "contents",
            JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))
        )
        val res = Net.post(url, body.toString()) ?: return null
        return JSONObject(res).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
    }

    fun ask(prompt: String, cb: (String?) -> Unit) = Net.async({ call(prompt) }, cb)

    fun summarize(text: String, cb: (String?) -> Unit) = ask(
        "סכם בעברית, בשני משפטים קצרים שמתאימים להקראה בקול בזמן נהיגה, את ההודעה הבאה. החזר רק את הסיכום.\n\n$text", cb
    )

    /** הופך בקשה חופשית לפקודה שהאפליקציה מבינה, או לתשובה. */
    fun interpret(heard: String, cb: (String?) -> Unit) = ask(
        """
        אתה עוזר קולי ברכב בשם "${Prefs.assistantName}". המשתמש אמר: "$heard"
        אם זו בקשה לפעולה, החזר שורה אחת בפורמט: CMD: <פקודה>
        כאשר <פקודה> היא אחת מהתבניות הבאות בדיוק (מלא את החלקים בסוגריים):
        תדליקי <שיר או זמר> ביוטיוב מיוזיק | תעצרי | השיר הבא | הקודם | תמשיכי | יותר חזק | יותר חלש | מה השיר |
        נווטי ל<יעד> | סעי הביתה | סעי לעבודה | תתקשרי ל<שם> | תשלחי ל<שם> ש<הודעה> | תשלחי ל<שם> איפה אני |
        תזכירי לי בעוד <מספר> דקות <מה> | כשאני מגיע הביתה תזכירי לי <מה> | תרשמי <פתק> | תוסיפי <מוצר> לרשימת הקניות |
        מה ברשימת הקניות | תקריאי את הפתקים | איפה החניתי | תפתחי את השער | מה החדשות | מה מזג האוויר | מה יש לי היום ביומן |
        קבעי פגישה <מחר/היום> ב<שעה> <נושא> | תדליקי רדיו <תחנה> | תכבי את הרדיו | שקט עד סוף הנסיעה | תקריאי שוב | מצב חירום
        אם זו שאלה כללית, החזר שורה אחת בפורמט: ANSWER: <תשובה קצרה בעברית, עד שני משפטים, מתאימה להקראה>
        אל תחזיר שום דבר אחר.
        """.trimIndent(), cb
    )
}
