package com.kolbaderech.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.CallLog
import android.provider.ContactsContract
import android.telephony.SmsManager

object Contacts {
    private fun granted(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    /** מתרגם כינוי ("אהובה") לשם באנשי הקשר. */
    fun resolveNickname(name: String): String {
        val n = name.trim()
        return Prefs.pairs(Prefs.nicknames).firstOrNull { it.first == n }?.second ?: n
    }

    /** מחזיר (שם, מספר) או null. */
    fun find(c: Context, rawName: String): Pair<String, String>? {
        val name = resolveNickname(rawName)
        if (name.isBlank() || !granted(c, Manifest.permission.READ_CONTACTS)) return null
        try {
            c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"), null
            )?.use { cur ->
                if (cur.moveToFirst()) return cur.getString(0) to cur.getString(1)
            }
        } catch (e: Exception) {
        }
        return null
    }

    fun call(c: Context, number: String): Boolean {
        val can = granted(c, Manifest.permission.CALL_PHONE)
        return try {
            c.startActivity(
                Intent(if (can) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    fun sms(c: Context, number: String, text: String): Boolean {
        if (!granted(c, Manifest.permission.SEND_SMS)) return false
        return try {
            val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
            else @Suppress("DEPRECATION") SmsManager.getDefault()
            val parts = sm.divideMessage(text)
            sm.sendMultipartTextMessage(number, null, parts, null, null)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** מספר בפורמט בינלאומי בלי סימנים: 0501234567 → 972501234567 */
    private fun intl(n: String): String? {
        var d = n.filter { it.isDigit() || it == '+' }
        if (d.startsWith("+")) d = d.substring(1)
        else if (d.startsWith("00")) d = d.substring(2)
        else if (d.startsWith("0")) d = "972" + d.substring(1)
        return d.filter { it.isDigit() }.ifEmpty { null }
    }

    /** פותח צ׳אט בוואטסאפ עם ההודעה ולוחץ "שלח" בשבילך (דרך שירות הנגישות). */
    fun installed(c: Context, pkg: String) = c.packageManager.getLaunchIntentForPackage(pkg) != null

    fun whatsapp(c: Context, number: String, text: String, preferred: String? = null): Boolean {
        val digits = intl(number) ?: return false
        val order = listOfNotNull(preferred, "com.whatsapp", "com.whatsapp.w4b").distinct()
        val pkg = order.firstOrNull { installed(c, it) } ?: return false
        if (!GateService.isEnabled(c)) return false
        GateService.armTap(
            pkg, listOf("Send", "שליחה", "שלח"), 15, goHome = true,
            ids = listOf("$pkg:id/send", "$pkg:id/send_btn")
        )
        return try {
            c.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=$digits&text=" + Uri.encode(text)))
                    .setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    /** שולח הודעה לאדם: תשובה לוואטסאפ אחרון ממנו, אחרת וואטסאפ חדש, אחרת SMS. */
    fun message(c: Context, rawName: String, text: String, waPkg: String? = null): String {
        val name = resolveNickname(rawName.trim())
        Relay.recentFor(name)?.let { m ->
            if ((waPkg == null || m.pkg == waPkg) && Reply.send(c, m, text)) return "שלחתי ל-${m.sender} ב${m.app}"
        }
        val contact = find(c, name) ?: find(c, name.removePrefix("ל")) ?: return "לא מצאתי את $rawName באנשי הקשר"
        val label = if (waPkg == "com.whatsapp.w4b") "בוואטסאפ העסקי" else "בוואטסאפ"
        DLog.i("✉️ שליחה ל-${contact.first} (${waPkg ?: "ברירת מחדל"}), נגישות: ${GateService.isEnabled(c)}")
        if (Prefs.msgChannel == "whatsapp" && whatsapp(c, contact.second, text, waPkg)) return "שולחת ל-${contact.first} $label"
        return if (sms(c, contact.second, text)) "שלחתי ל-${contact.first} ב-SMS"
        else "לא הצלחתי לשלוח. צריך לאשר נגישות לוואטסאפ, או SMS, בהגדרות"
    }

    fun locationLink(): String? {
        val lat = Store.lastLat
        val lng = Store.lastLng
        if (lat == 0.0 && lng == 0.0) return null
        return "https://maps.google.com/?q=$lat,$lng"
    }

    /** המספר האחרון שהתקשר (נכנסת או שלא נענתה). */
    fun lastCaller(c: Context): Pair<String, String>? {
        if (!granted(c, Manifest.permission.READ_CALL_LOG)) return null
        try {
            c.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE),
                "${CallLog.Calls.TYPE} IN (${CallLog.Calls.INCOMING_TYPE}, ${CallLog.Calls.MISSED_TYPE})",
                null, "${CallLog.Calls.DATE} DESC"
            )?.use { cur ->
                if (cur.moveToFirst()) {
                    val num = cur.getString(0) ?: return null
                    val name = cur.getString(1)?.ifBlank { null } ?: num
                    return name to num
                }
            }
        } catch (e: Exception) {
        }
        return null
    }

    /** שיחות שלא נענו מאז זמן מסוים. */
    fun missedSince(c: Context, since: Long): List<Pair<String, String>> {
        if (!granted(c, Manifest.permission.READ_CALL_LOG)) return emptyList()
        val out = ArrayList<Pair<String, String>>()
        try {
            c.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME),
                "${CallLog.Calls.TYPE} = ${CallLog.Calls.MISSED_TYPE} AND ${CallLog.Calls.DATE} > ?",
                arrayOf(since.toString()), "${CallLog.Calls.DATE} ASC"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val num = cur.getString(0) ?: continue
                    val name = cur.getString(1)?.ifBlank { null } ?: num
                    out.add(name to num)
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun nameForNumber(c: Context, number: String): String? {
        if (!granted(c, Manifest.permission.READ_CONTACTS)) return null
        return try {
            c.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { cur -> if (cur.moveToFirst()) cur.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    /** כתובת של איש קשר (אם שמורה אצלו), לניווט: "סעי לאמא מירי". */
    fun addressFor(c: Context, rawName: String): String? {
        val name = resolveNickname(rawName.trim().removePrefix("ל").trim())
        if (name.length < 2 || !granted(c, Manifest.permission.READ_CONTACTS)) return null
        return try {
            c.contentResolver.query(
                ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.StructuredPostal.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.StructuredPostal.FORMATTED_ADDRESS
                ),
                "${ContactsContract.CommonDataKinds.StructuredPostal.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"), null
            )?.use { cur -> if (cur.moveToFirst()) cur.getString(1)?.replace("\n", ", ") else null }
        } catch (e: Exception) {
            null
        }
    }
}
