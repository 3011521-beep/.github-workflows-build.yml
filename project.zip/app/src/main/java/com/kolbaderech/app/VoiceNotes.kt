package com.kolbaderech.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Environment
import android.util.Base64
import java.io.File

/**
 * הודעות קוליות מוואטסאפ: וואטסאפ שומר כל הודעה קולית כקובץ בטלפון.
 * אנחנו מוצאים את הקובץ החדש ומשמיעים אותו (צריך הרשאת "גישה לכל הקבצים").
 */
object VoiceNotes {
    private val played = LinkedHashSet<String>()

    fun isVoice(text: String): Boolean {
        val l = text.lowercase()
        return text.contains("🎤") || l.contains("הודעה קולית") || l.contains("voice message") ||
            l.contains("הקלטה קולית") || l.startsWith("audio") || l.contains("‏הודעה קולית")
    }

    /** "🎤 הודעה קולית (0:12)" → "12 שניות" */
    fun durationText(text: String): String {
        val m = Regex("(\\d+):(\\d{2})").find(text) ?: return ""
        val min = m.groupValues[1].toInt()
        val sec = m.groupValues[2].toInt()
        return when {
            min == 0 -> "$sec שניות"
            sec == 0 -> if (min == 1) "דקה" else "$min דקות"
            min == 1 -> "דקה ו-$sec שניות"
            else -> "$min דקות ו-$sec שניות"
        }
    }

    fun canRead(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun dirs(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        return listOf(
            File(root, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes"),
            File(root, "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Voice Notes"),
            File(root, "WhatsApp/Media/WhatsApp Voice Notes"),
            File(root, "WhatsApp Business/Media/WhatsApp Business Voice Notes")
        )
    }

    /** הקובץ הקולי הכי חדש שעוד לא הושמע. */
    @Synchronized
    fun findLatest(c: Context, since: Long): File? {
        if (!canRead(c)) return null
        val files = ArrayList<File>()
        for (d in dirs()) {
            if (!d.isDirectory) continue
            d.listFiles()?.forEach { f ->
                if (f.isDirectory) f.listFiles()?.let { files.addAll(it) } else files.add(f)
            }
        }
        val hit = files.asSequence()
            .filter { it.isFile && (it.name.endsWith(".opus") || it.name.endsWith(".ogg") || it.name.endsWith(".m4a")) }
            .filter { it.lastModified() >= since - 180_000 && it.absolutePath !in played }
            .maxByOrNull { it.lastModified() } ?: return null
        played.add(hit.absolutePath)
        while (played.size > 200) played.remove(played.first())
        return hit
    }

    fun toBase64(path: String?): String? {
        if (path == null) return null
        val f = File(path)
        if (!f.exists() || f.length() > 4_000_000) return null
        return try {
            Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    fun fromBase64(c: Context, b64: String, id: String): String? = try {
        val dir = File(c.cacheDir, "voice").apply { mkdirs() }
        dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 6 * 60 * 60_000L }?.forEach { it.delete() }
        val f = File(dir, "$id.opus")
        f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
        f.absolutePath
    } catch (e: Exception) {
        null
    }

    // ---------------- השמעה ----------------
    private var player: MediaPlayer? = null

    fun play(path: String, attrs: android.media.AudioAttributes, done: () -> Unit): Boolean {
        stop()
        var created: MediaPlayer? = null
        return try {
            val p = MediaPlayer()
            created = p
            p.setAudioAttributes(attrs)
            p.setDataSource(path)
            p.setOnCompletionListener { stop(); done() }
            p.setOnErrorListener { _, _, _ -> stop(); done(); true }
            p.prepare()
            p.start()
            player = p
            true
        } catch (e: Exception) {
            // קובץ פגום / לא נגיש: הנגן עוד לא נשמר ב-player – משחררים אותו (אחרת דליפה)
            if (created != null && created !== player) try { created.release() } catch (e2: Exception) {}
            stop()
            false
        }
    }

    fun stop() {
        player?.let {
            try {
                it.stop()
            } catch (e: Exception) {
            }
            it.release()
        }
        player = null
    }
}
