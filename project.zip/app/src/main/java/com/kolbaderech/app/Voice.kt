package com.kolbaderech.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

object Voice {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var generation = 0

    /** כל האפשרויות שהזיהוי הציע לפעם האחרונה (לבחירת הכי הגיונית). */
    var lastAlternatives: List<String> = emptyList()
        private set

    /** האם הזיהוי החזיר טקסט באנגלית במקום בעברית (שפת זיהוי שגויה במכשיר). */
    var lastWasLatin = false
        private set

    fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            handler.postDelayed({ tg.release() }, 400)
        } catch (e: Exception) {
        }
    }

    /** צליל קצר שונה לכל סוג אפליקציה, כדי לדעת ממה ההודעה עוד לפני ההקראה. */
    fun appTone(pkg: String, isEmail: Boolean) {
        val tone = when {
            isEmail -> ToneGenerator.TONE_PROP_PROMPT
            pkg.startsWith("com.whatsapp") -> ToneGenerator.TONE_PROP_ACK
            pkg.contains("messaging") -> ToneGenerator.TONE_PROP_BEEP2
            else -> ToneGenerator.TONE_PROP_BEEP
        }
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 60)
            tg.startTone(tone, 200)
            handler.postDelayed({ tg.release() }, 600)
        } catch (e: Exception) {
        }
    }

    /** מאזין פעם אחת. מחזיר טקסט או null אם לא נשמע כלום. */
    fun listen(ctx: Context, onDone: (String?) -> Unit) {
        cancel()
        lastAlternatives = emptyList()
        lastWasLatin = false
        val gen = ++generation
        val granted = ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!granted || !SpeechRecognizer.isRecognitionAvailable(ctx)) {
            handler.post { onDone(null) }
            return
        }
        var finished = false
        fun finish(text: String?) {
            if (finished) return
            finished = true
            if (gen != generation) return
            cancel()
            onDone(text?.trim()?.ifBlank { null })
        }
        val r = try {
            SpeechRecognizer.createSpeechRecognizer(ctx)
        } catch (e: Exception) {
            handler.post { finish(null) }
            return
        }
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) = finish(null)
            override fun onResults(results: Bundle?) {
                val all = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.filter { it.isNotBlank() } ?: emptyList()
                lastAlternatives = all
                val first = all.firstOrNull()
                lastWasLatin = first != null && first.none { it in '\u05D0'..'\u05EA' } && first.count { it in 'a'..'z' || it in 'A'..'Z' } >= 3
                finish(first)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val lang = Prefs.sttLang.ifBlank { "he-IL" }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            finish(null)
            return
        }
        handler.postDelayed({ finish(null) }, 10_000)
    }

    fun cancel() {
        generation++
        recognizer?.let {
            try {
                it.cancel()
                it.destroy()
            } catch (e: Exception) {
            }
        }
        recognizer = null
    }
}
