package com.kolbaderech.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow

object DriveState {
    val active = MutableStateFlow(false)
    var startedAt = 0L
    @Volatile var btConnected = false
    private val handler = Handler(Looper.getMainLooper())
    private var pendingStop: Runnable? = null

    fun start(ctx: Context) {
        pendingStop?.let { handler.removeCallbacks(it) }
        pendingStop = null
        if (active.value) return
        val app = ctx.applicationContext
        active.value = true
        startedAt = System.currentTimeMillis()
        App.startServiceSafely(app, Intent(app, DriveService::class.java))
        CrashGuard.safe(Unit) { Features.onDriveStart(app) }
        if (isSpeaker()) {
            if (Prefs.askAtStart) handler.postDelayed({ Announcer.askReadingPreference() }, 2500)
            else if (Prefs.announceStart) Announcer.notice("מצב נהיגה פעיל")
        }
        Announcer.scheduleWake(4000)
        handler.postDelayed({ CrashGuard.safe(Unit) { Wake.start(app) } }, 4000)
    }

    /** עצירה אחרי השהיה (למשל ניתוק רגעי של הנקודה החמה). */
    fun stopSoon(ctx: Context, delayMs: Long) {
        val app = ctx.applicationContext
        pendingStop?.let { handler.removeCallbacks(it) }
        val r = Runnable { stop(app) }
        pendingStop = r
        handler.postDelayed(r, delayMs)
    }

    fun stop(ctx: Context) {
        pendingStop?.let { handler.removeCallbacks(it) }
        pendingStop = null
        if (!active.value) return
        val app = ctx.applicationContext
        active.value = false
        Wake.stop()
        CrashGuard.safe(Unit) { Announcer.reset() }
        CrashGuard.safe(Unit) { Features.onDriveEnd(app) }
        try {
            app.stopService(Intent(app, DriveService::class.java))
        } catch (e: Exception) {
        }
    }

    /** המכשיר שמדבר: מסך הרכב, או הטלפון כשאין מסך מחובר. */
    fun isSpeaker() = Prefs.isCar || !Link.connected.value
}
