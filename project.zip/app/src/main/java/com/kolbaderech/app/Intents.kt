package com.kolbaderech.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * מנוע הבנת הכוונה. ההגדרות ב-assets/intents.json: לכל כוונה רשימת חלופות,
 * וכל חלופה היא קבוצת "גזעים" שכולם צריכים להופיע (בכל הטיה: תדליקי/הדליקי/תדליק…).
 * נבדק מול 1,700 משפטים לפני השחרור (לפחות 40 לכל כוונה).
 */
object Intents {
    data class Def(
        val id: String,
        val pri: Int,
        val alts: List<List<String>>,
        val none: List<String>,
        val strip: List<String>
    )

    data class Result(val id: String, val slot: String)

    private var defs: List<Def> = emptyList()
    private var groups: Map<String, List<String>> = emptyMap()
    private var fillers: Set<String> = emptySet()
    private const val PREFIX = "והבלשמכת"

    fun load(c: Context) {
        if (defs.isNotEmpty()) return
        try {
            val txt = c.assets.open("intents.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val o = JSONObject(txt)
            fillers = strings(o.getJSONArray("fillers")).map { norm(it) }.toSet()
            val g = o.getJSONObject("groups")
            val gm = HashMap<String, List<String>>()
            g.keys().forEach { k -> gm[k] = strings(g.getJSONArray(k)).map { nstem(it) } }
            groups = gm
            val arr = o.getJSONArray("intents")
            val list = ArrayList<Def>()
            for (i in 0 until arr.length()) {
                val it = arr.getJSONObject(i)
                val altsArr = it.getJSONArray("alts")
                val alts = (0 until altsArr.length()).map { a ->
                    strings(altsArr.getJSONArray(a)).map { s -> if (s.startsWith("$")) s else nstem(s) }
                }
                list.add(
                    Def(
                        it.getString("id"), it.getInt("pri"), alts,
                        strings(it.optJSONArray("none")).map { nstem(it) },
                        strings(it.optJSONArray("strip")).map { nstem(it) }
                    )
                )
            }
            defs = list
        } catch (e: Exception) {
            defs = emptyList()
        }
    }

    private fun strings(a: JSONArray?): List<String> =
        if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }

    fun norm(s: String): String {
        var t = s.lowercase()
        t = t.replace(Regex("[\\u0591-\\u05C7]"), "")
        t = t.replace(Regex("['\"\\u05F3\\u05F4`]"), "")
        t = t.replace('ם', 'מ').replace('ן', 'נ').replace('ץ', 'צ').replace('ף', 'פ').replace('ך', 'כ')
        // סובלנות לכתיב: "תנווטי" / "תנוטי", "פלייליסט" / "פליליסט"
        t = t.replace(Regex("ו{2,}"), "ו").replace(Regex("י{2,}"), "י")
        t = t.replace(Regex("[^a-z0-9\\u05D0-\\u05EA ]"), " ")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    private fun nstem(st: String) = if (st.startsWith("=")) "=" + norm(st.substring(1)) else norm(st)

    private fun s1(w: String): String? =
        if (w.length > 2 && PREFIX.indexOf(w[0]) >= 0) w.substring(1) else null

    private fun variants(w: String): List<String> {
        val v = arrayListOf(w)
        val a = s1(w)
        if (a != null) {
            v.add(a)
            s1(a)?.let { v.add(it) }
        }
        return v
    }

    private fun stemMatch(st: String, wv: List<List<String>>, padded: String): Boolean {
        if (st.startsWith("=")) {
            val t = st.substring(1)
            return wv.any { t in it }
        }
        if (st.contains(' ')) return padded.contains(" $st") || padded.startsWith(st)
        return wv.any { v -> v.any { it.startsWith(st) } }
    }

    private fun slotMatch(slot: String, wv: List<List<String>>, padded: String): String? {
        if (slot.startsWith("$")) {
            val g = groups[slot.substring(1)] ?: return null
            return g.firstOrNull { stemMatch(it, wv, padded) }
        }
        return if (stemMatch(slot, wv, padded)) slot else null
    }

    fun classify(c: Context, text: String): Result? {
        load(c)
        val t = norm(text)
        if (t.isEmpty()) return null
        val words = t.split(" ")
        val wv = words.map { variants(it) }
        val padded = " $t "
        var bestScore = -1
        var bestDef: Def? = null
        var bestAlt: List<String>? = null
        for (d in defs) {
            if (d.none.any { stemMatch(it, wv, padded) }) continue
            for (alt in d.alts) {
                var ok = true
                for (s in alt) {
                    if (slotMatch(s, wv, padded) == null) {
                        ok = false; break
                    }
                }
                if (!ok) continue
                val score = alt.size * 100 + d.pri + (if (d.pri >= 100) 10000 else 0)
                if (score > bestScore) {
                    bestScore = score; bestDef = d; bestAlt = alt
                }
            }
        }
        val d = bestDef ?: return null
        val alt = bestAlt ?: return null

        // חילוץ הפרטים (שם שיר, יעד, איש קשר, אפליקציה): מה שנשאר אחרי הסרת מילות הפעולה
        val pool = ArrayList<String>()
        alt.forEach { s -> if (s.startsWith("$")) pool.addAll(groups[s.substring(1)] ?: emptyList()) else pool.add(s) }
        pool.addAll(d.strip)
        val prefixStems = pool.filter { !it.contains(' ') && !it.startsWith("=") }
        val exact = HashSet(fillers)
        pool.filter { it.startsWith("=") }.forEach { exact.add(it.substring(1)) }
        pool.filter { it.contains(' ') }.forEach { exact.addAll(it.split(" ")) }

        val orig = text.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").split(Regex("\\s+")).filter { it.isNotBlank() }
        val keep = ArrayList<String>()
        for (ow in orig) {
            val nw = norm(ow)
            if (nw.isEmpty()) continue
            val vs = variants(nw)
            if (vs.any { it in exact }) continue
            if (vs.any { v -> prefixStems.any { v.startsWith(it) } }) continue
            keep.add(ow)
        }
        return Result(d.id, keep.joinToString(" "))
    }
}

/** למידה מטעויות: משפט שלא הובן ← הפקודה שהתכוונת אליה. */
object Learn {
    private fun map(): JSONObject = try {
        JSONObject(Prefs.learned)
    } catch (e: Exception) {
        JSONObject()
    }

    fun lookup(heard: String): String? = map().optString(Intents.norm(heard)).ifBlank { null }

    fun add(heard: String, target: String) {
        val k = Intents.norm(heard)
        if (k.isEmpty() || k == Intents.norm(target)) return
        val m = map()
        m.put(k, target)
        Prefs.learned = m.toString()
        if (Prefs.isCar && Link.connected.value) Link.send(Link.obj("learn", "k" to heard, "v" to target))
    }

    fun all(): List<Pair<String, String>> {
        val m = map()
        return m.keys().asSequence().map { it to m.optString(it) }.toList()
    }

    fun remove(key: String) {
        val m = map()
        m.remove(key)
        Prefs.learned = m.toString()
    }

    fun clear() {
        Prefs.learned = "{}"
    }
}
