package com.kolbaderech.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager

/** בטלפון: מזהה שיחה נכנסת בנסיעה ומאפשר לענות או לדחות בקול. */
object CallMonitor {
    private val handler = Handler(Looper.getMainLooper())
    private var registered = false
    private var lastNumber: String? = null
    private var pending: Runnable? = null
    private var announcedAt = 0L

    @Suppress("DEPRECATION")
    fun register(ctx: Context) {
        if (registered || Prefs.isCar) return
        val app = ctx.applicationContext
        if (app.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        val tm = app.getSystemService(TelephonyManager::class.java) ?: return
        val listener = object : PhoneStateListener() {
            @Deprecated("Deprecated in Java")
            override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                if (state == TelephonyManager.CALL_STATE_RINGING) onRing(app, phoneNumber)
                else {
                    // השיחה נענתה/הסתיימה: לא להכריז עליה באיחור, ולא להשתמש במספר שלה בשיחה הבאה
                    pending?.let { handler.removeCallbacks(it) }
                    pending = null
                    if (state == TelephonyManager.CALL_STATE_IDLE) lastNumber = null
                }
            }
        }
        try {
            tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
            registered = true
        } catch (e: Exception) {
        }
    }

    private fun onRing(app: Context, number: String?) {
        if (!DriveState.active.value || !Prefs.voiceCalls) return
        if (!number.isNullOrBlank()) lastNumber = number
        pending?.let { handler.removeCallbacks(it) }
        val r = Runnable {
            if (System.currentTimeMillis() - announcedAt < 8000) return@Runnable
            announcedAt = System.currentTimeMillis()
            val num = lastNumber
            val name = num?.let { Contacts.nameForNumber(app, it) } ?: num ?: "מספר לא מזוהה"
            if (Link.connected.value) Link.send(Link.obj("ring", "name" to name))
            else Announcer.incomingCall(name, remote = false)
        }
        pending = r
        handler.postDelayed(r, 900)
    }

    @SuppressLint("MissingPermission")
    fun op(app: Context, op: String) {
        val tm = app.getSystemService(TelecomManager::class.java) ?: return
        if (app.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) return
        try {
            when (op) {
                "answer" -> @Suppress("DEPRECATION") tm.acceptRingingCall()
                "reject" -> {
                    if (Build.VERSION.SDK_INT >= 28) @Suppress("DEPRECATION") tm.endCall()
                    val n = lastNumber
                    if (n != null && Prefs.missedCallSms) Contacts.sms(app, n, Prefs.autoReplyText)
                }
            }
        } catch (e: Exception) {
        }
    }
}
