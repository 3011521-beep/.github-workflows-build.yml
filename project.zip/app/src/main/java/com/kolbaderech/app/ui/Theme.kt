package com.kolbaderech.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class Palette(
    val bg: Color, val surface: Color, val border: Color, val text: Color, val soft: Color, val muted: Color,
    val amber: Color, val onAmber: Color, val teal: Color, val tealBg: Color, val onTeal: Color, val light: Boolean,
    /** משטח מוגבה (שורות בתוך כרטיס, כפתורים משניים). */
    val surface2: Color,
    /** רקע לפס אזהרה ולצבע הכתום הרך. */
    val amberBg: Color,
    /** קצה שני של מעבר הצבע בכפתור הראשי. */
    val amber2: Color,
    /** טקסט על בועת תגובה (רקע טורקיז רך). */
    val onTealBg: Color,
    val danger: Color,
    /** זוהר עדין בראש המסך. */
    val glow: Color,
)

object C {
    val dark = Palette(
        bg = Color(0xFF0B0E13), surface = Color(0xFF151A22), border = Color(0xFF262D38),
        text = Color(0xFFF3F5F8), soft = Color(0xFFD5DAE1), muted = Color(0xFF9AA4B2),
        amber = Color(0xFFF6A928), onAmber = Color(0xFF1A1205), teal = Color(0xFF4FD1C5), tealBg = Color(0xFF12322F),
        onTeal = Color(0xFF062320), light = false,
        surface2 = Color(0xFF1C222C), amberBg = Color(0xFF33260F), amber2 = Color(0xFFFF8A3D),
        onTealBg = Color(0xFFE3FBF7), danger = Color(0xFFFF6B6B), glow = Color(0x33F6A928)
    )
    val blue = Palette(
        bg = Color(0xFF0B1424), surface = Color(0xFF14213A), border = Color(0xFF253756),
        text = Color(0xFFF2F5FA), soft = Color(0xFFD3DBE7), muted = Color(0xFF9AA9C0),
        amber = Color(0xFFF6A928), onAmber = Color(0xFF1A1205), teal = Color(0xFF5AD7E0), tealBg = Color(0xFF113448),
        onTeal = Color(0xFF05222B), light = false,
        surface2 = Color(0xFF1A2945), amberBg = Color(0xFF33290F), amber2 = Color(0xFFFF8A3D),
        onTealBg = Color(0xFFE4F9FC), danger = Color(0xFFFF6B6B), glow = Color(0x3346A3FF)
    )
    val light = Palette(
        bg = Color(0xFFF3F4F7), surface = Color(0xFFFFFFFF), border = Color(0xFFE1E4EA),
        text = Color(0xFF12151B), soft = Color(0xFF323944), muted = Color(0xFF5E6878),
        amber = Color(0xFFB36A00), onAmber = Color(0xFFFFFFFF), teal = Color(0xFF0B7F74), tealBg = Color(0xFFDDF3F0),
        onTeal = Color(0xFFFFFFFF), light = true,
        surface2 = Color(0xFFF6F7F9), amberBg = Color(0xFFFFF1DB), amber2 = Color(0xFFD9541E),
        onTealBg = Color(0xFF07332E), danger = Color(0xFFC62828), glow = Color(0x26F6A928)
    )

    /** ערכת הצבעים הנוכחית (נקבעת לפי ההגדרות). */
    var p: Palette = dark

    /** "auto" = לפי מצב כהה/בהיר של המערכת. */
    fun apply(name: String, systemDark: Boolean = true) {
        p = when (name) {
            "light" -> light
            "blue" -> blue
            "auto" -> if (systemDark) dark else light
            else -> dark
        }
    }

    val Bg get() = p.bg
    val Surface get() = p.surface
    val Surface2 get() = p.surface2
    val Border get() = p.border
    val Text get() = p.text
    val Soft get() = p.soft
    val Muted get() = p.muted
    val Amber get() = p.amber
    val Amber2 get() = p.amber2
    val AmberBg get() = p.amberBg
    val OnAmber get() = p.onAmber
    val Teal get() = p.teal
    val TealBg get() = p.tealBg
    val OnTeal get() = p.onTeal
    val OnTealBg get() = p.onTealBg
    val Danger get() = p.danger

    /** מעבר הצבע של המותג (כתום-ענבר → כתום). */
    val brand: Brush get() = Brush.linearGradient(listOf(p.amber, p.amber2))
}

private fun Color.argb(): Int = android.graphics.Color.argb(
    (alpha * 255).toInt(), (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt()
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    C.apply(com.kolbaderech.app.Prefs.theme, isSystemInDarkTheme())
    val pal = C.p
    val scheme = if (pal.light) lightColorScheme(
        primary = pal.amber, onPrimary = pal.onAmber, secondary = pal.teal, onSecondary = pal.onTeal,
        background = pal.bg, onBackground = pal.text, surface = pal.surface, onSurface = pal.text,
        surfaceVariant = pal.surface2, onSurfaceVariant = pal.muted, outline = pal.border, error = pal.danger
    ) else darkColorScheme(
        primary = pal.amber, onPrimary = pal.onAmber, secondary = pal.teal, onSecondary = pal.onTeal,
        background = pal.bg, onBackground = pal.text, surface = pal.surface, onSurface = pal.text,
        surfaceVariant = pal.surface2, onSurfaceVariant = pal.muted, outline = pal.border, error = pal.danger
    )
    // שורת הסטטוס והניווט בצבע הרקע, עם אייקונים בצבע מתאים
    val view = androidx.compose.ui.platform.LocalView.current
    SideEffect {
        val act = view.context as? android.app.Activity ?: return@SideEffect
        try {
            val c = pal.bg.argb()
            act.window.statusBarColor = c
            act.window.navigationBarColor = c
            act.window.decorView.setBackgroundColor(c)
            val ctl = androidx.core.view.WindowCompat.getInsetsController(act.window, view)
            ctl.isAppearanceLightStatusBars = pal.light
            ctl.isAppearanceLightNavigationBars = pal.light
        } catch (e: Throwable) {
        }
    }
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(color = pal.bg, contentColor = pal.text) {
                // זוהר עדין בראש המסך – נותן עומק בלי להסיח את הדעת
                Box(
                    Modifier.fillMaxSize().drawBehind {
                        drawRect(
                            Brush.radialGradient(
                                listOf(pal.glow, Color.Transparent),
                                center = Offset(size.width * 0.85f, 0f),
                                radius = size.maxDimension * 0.75f
                            )
                        )
                    }
                ) { content() }
            }
        }
    }
}

/** לחיצה עם הקטנה קלה ורטט עדין – מרגיש "חי" ומאשר לנהג שהלחיצה נקלטה. */
@Composable
fun Modifier.pressable(
    enabled: Boolean = true,
    haptic: Boolean = true,
    role: Role = Role.Button,
    label: String? = null,
    onClick: () -> Unit
): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.96f else 1f, spring(dampingRatio = 0.6f, stiffness = 800f), label = "press")
    val hf = LocalHapticFeedback.current
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(
            interactionSource = src, indication = LocalIndication.current, enabled = enabled,
            role = role, onClickLabel = label
        ) {
            if (haptic) try { hf.performHapticFeedback(HapticFeedbackType.TextHandleMove) } catch (e: Throwable) { }
            onClick()
        }
}

@Composable
fun CardBox(modifier: Modifier = Modifier, padding: Dp = 20.dp, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(C.Surface, C.Surface2)))
            .border(1.dp, C.Border, shape)
            .padding(padding),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun SectionTitle(text: String) {
    Row(Modifier.padding(top = 14.dp, bottom = 2.dp, start = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 4.dp, height = 16.dp).clip(RoundedCornerShape(2.dp)).background(C.brand))
        Spacer(Modifier.width(8.dp))
        Text(text, color = C.Muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp)
    }
}

@Composable
fun HLine() {
    Box(Modifier.fillMaxWidth().padding(vertical = 2.dp).heightIn(min = 1.dp, max = 1.dp).background(C.Border))
}

@Composable
fun ToggleRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(role = Role.Switch) { onChange(!checked) }
            .padding(vertical = 6.dp, horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = C.Text, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = C.Muted, fontSize = 13.sp, lineHeight = 18.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = C.Amber, checkedThumbColor = C.OnAmber, checkedBorderColor = Color.Transparent,
                uncheckedTrackColor = C.Border, uncheckedThumbColor = C.Muted,
                uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

@Composable
fun BigButton(
    text: String,
    icon: Int?,
    bg: Color,
    fg: Color,
    modifier: Modifier = Modifier,
    outlined: Boolean = false,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    // הכפתור הראשי (כתום) מקבל מעבר צבע של המותג
    val fill: Brush = if (!outlined && bg == C.Amber) C.brand
    else if (outlined) Brush.verticalGradient(listOf(C.Surface2, C.Surface))
    else Brush.verticalGradient(listOf(bg, bg))
    Row(
        modifier
            .heightIn(min = 60.dp)
            .clip(shape)
            .background(fill)
            .then(if (outlined) Modifier.border(1.dp, C.Border, shape) else Modifier)
            .pressable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(painterResource(icon), contentDescription = null, tint = fg, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text, color = fg, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 21.sp
        )
    }
}

/** כפתור עגול קטן עם אייקון (הגדרות, חזרה, סגירה). */
@Composable
fun RoundIconButton(icon: Int, description: String, size: Dp = 48.dp, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape).background(C.Surface)
            .border(1.dp, C.Border, CircleShape).pressable(label = description, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(icon), contentDescription = description, tint = C.Text, modifier = Modifier.size(size * 0.44f))
    }
}

private val avatarHues = listOf(
    0xFFF6A928, 0xFF4FD1C5, 0xFF7C9CFF, 0xFFFF7A90, 0xFF9B8CFF, 0xFF5CC97B, 0xFFFF9F5A, 0xFF56B4F0
)

/** צבע קבוע לכל שם – כך מזהים שולח במבט חטוף. */
fun avatarColor(name: String): Color = Color(avatarHues[Math.floorMod(name.trim().hashCode(), avatarHues.size)])

@Composable
fun Avatar(name: String, size: Dp, ring: Boolean = false) {
    val letter = name.trim().firstOrNull { it.isLetterOrDigit() }?.toString() ?: name.trim().firstOrNull()?.toString() ?: "?"
    val col = avatarColor(name)
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(col.copy(alpha = 0.32f), col.copy(alpha = 0.16f))))
            .border(if (ring) 3.dp else 1.dp, if (ring) C.Amber else col.copy(alpha = 0.35f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(letter, color = if (C.p.light) C.Text else col, fontSize = (size.value * 0.42f).sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun Chip(text: String) {
    val shape = RoundedCornerShape(16.dp)
    Text(
        text, color = C.Muted, fontSize = 15.sp,
        modifier = Modifier.clip(shape).background(C.Surface).border(1.dp, C.Border, shape)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    )
}

@Composable
fun Dot(color: Color, pulse: Boolean = false) {
    if (pulse) {
        val t = rememberInfiniteTransition(label = "dot")
        val a by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a")
        Box(Modifier.size(10.dp).graphicsLayer { alpha = a }.clip(CircleShape).background(color))
    } else {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
    }
}

/** פס הודעה לחיץ (אזהרה / מידע) עם אייקון. */
@Composable
fun Banner(text: String, icon: String = "!", tone: Color = C.Amber, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val bg = if (tone == C.Teal) C.TealBg else C.AmberBg
    Row(
        Modifier.fillMaxWidth().clip(shape).background(bg)
            .border(1.dp, tone.copy(alpha = 0.35f), shape)
            .pressable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(tone.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Text(icon, color = tone, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.width(12.dp))
        Text(text, color = if (C.p.light) C.Text else tone, fontSize = 15.sp, fontWeight = FontWeight.Medium,
            lineHeight = 20.sp, modifier = Modifier.weight(1f))
        Text("‹", color = tone, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

/** כפתור המיקרופון הגדול: מעבר צבע, טבעות "נושמות" ורטט בלחיצה. */
@Composable
fun MicOrb(size: Dp, icon: Int, description: String, active: Boolean = false, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "orb")
    val breathe by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(if (active) 1100 else 2600, easing = LinearEasing), RepeatMode.Restart), label = "b"
    )
    val ringColor by animateColorAsState(if (active) C.Teal else C.Amber, tween(400), label = "rc")
    val hf = LocalHapticFeedback.current
    Box(Modifier.size(size * 1.45f), contentAlignment = Alignment.Center) {
        // שתי טבעות מתרחבות ונעלמות
        for (k in 0..1) {
            val ph = (breathe + k * 0.5f) % 1f
            Box(
                Modifier.size(size).scale(1f + ph * 0.42f).graphicsLayer { alpha = (1f - ph) * 0.45f }
                    .clip(CircleShape).background(ringColor.copy(alpha = 0.35f))
            )
        }
        Box(
            Modifier.size(size).clip(CircleShape).background(C.brand)
                .pressable(haptic = false, label = description) {
                    try { hf.performHapticFeedback(HapticFeedbackType.LongPress) } catch (e: Throwable) { }
                    onClick()
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(painterResource(icon), contentDescription = description, tint = C.OnAmber, modifier = Modifier.size(size * 0.42f))
        }
    }
}

/** אייקון בתוך עיגול צבעוני עם מעבר צבע חלק בין מצבים. */
@Composable
fun StatusBadge(on: Boolean, size: Dp = 64.dp, content: @Composable BoxScope.(Color) -> Unit) {
    val bg by animateColorAsState(if (on) C.TealBg else C.Surface2, tween(500, easing = FastOutSlowInEasing), label = "sb")
    val fg by animateColorAsState(if (on) C.Teal else C.Muted, tween(500), label = "sf")
    Box(
        Modifier.size(size).clip(CircleShape).background(bg).border(1.dp, fg.copy(alpha = 0.3f), CircleShape),
        contentAlignment = Alignment.Center
    ) { content(fg) }
}
