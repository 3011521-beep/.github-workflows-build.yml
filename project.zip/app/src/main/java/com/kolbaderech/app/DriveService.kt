package com.kolbaderech.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder

class DriveService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            DriveState.stop(this)
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("drive", "מצב נהיגה", NotificationManager.IMPORTANCE_LOW)
        )
        val flagsPi = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val listen = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java).putExtra("listen", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            flagsPi
        )
        val open = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), flagsPi)
        val stop = PendingIntent.getService(
            this, 2, Intent(this, DriveService::class.java).setAction("STOP"), flagsPi
        )
        val n = Notification.Builder(this, "drive")
            .setSmallIcon(R.drawable.ic_car)
            .setContentTitle("מצב נהיגה פעיל")
            .setContentText("הודעות יוקראו אוטומטית")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null as Icon?, "דבר אליי", listen).build())
            .addAction(Notification.Action.Builder(null as Icon?, "סיום נהיגה", stop).build())
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }
}
