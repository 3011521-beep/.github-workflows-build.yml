package com.kolbaderech.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** יומן פעולות לאבחון: מה נשמע, מה הובן, מה בוצע ומה נכשל. אפשר לשתף אותו מההגדרות. */
object DLog {
    private val lines = ArrayDeque<String>()
    private var file: File? = null
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun init(c: Context) {
        file = File(c.filesDir, "noga_log.txt")
        try {
            file?.takeIf { it.exists() }?.readLines()?.takeLast(300)?.forEach { lines.addLast(it) }
        } catch (e: Throwable) {
        }
    }

    /** בטלפון: שולחים כל שורה גם למסך הרכב, כדי שהיומן שם יראה את כל התמונה. */
    fun i(msg: String) {
        add(msg)
        try {
            if (!Prefs.isCar && Link.connected.value && !msg.startsWith("🔗")) Link.send(Link.obj("log", "l" to msg))
        } catch (e: Throwable) {
        }
    }

    fun fromPhone(msg: String) = add("📱 $msg")

    @Synchronized
    private fun add(msg: String) {
        val line = "${fmt.format(Date())} $msg"
        lines.addLast(line)
        while (lines.size > 400) lines.removeFirst()
        try {
            val f = file ?: return
            if (f.exists() && f.length() > 300_000) f.writeText(lines.joinToString("\n") + "\n") else f.appendText(line + "\n")
        } catch (e: Throwable) {
        }
    }

    fun e(where: String, t: Throwable) = i("❌ $where: ${t.javaClass.simpleName}: ${t.message}")

    @Synchronized
    fun text(): String = lines.joinToString("\n")

    @Synchronized
    fun clear() {
        lines.clear()
        try {
            file?.writeText("")
        } catch (e: Throwable) {
        }
    }
}
