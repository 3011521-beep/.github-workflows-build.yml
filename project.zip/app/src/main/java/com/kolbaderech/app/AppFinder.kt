package com.kolbaderech.app

import android.content.Context
import android.content.Intent

/** "תפתחי X": מזהה איזו אפליקציה מותקנת התכוונת אליה, גם בעברית וגם באנגלית. */
object AppFinder {
    private val aliases = mapOf(
        "וואטסאפ" to "whatsapp", "ווטסאפ" to "whatsapp", "וטסאפ" to "whatsapp", "ווצאפ" to "whatsapp", "וואצאפ" to "whatsapp",
        "יוטיוב מיוזיק" to "youtube music", "יוטיוב" to "youtube", "ספוטיפיי" to "spotify", "ספוטיפי" to "spotify",
        "וויז" to "waze", "ויז" to "waze", "גוגל מפות" to "maps", "מפות" to "maps", "כרום" to "chrome", "גוגל" to "google",
        "פייסבוק" to "facebook", "אינסטגרם" to "instagram", "אינסטה" to "instagram", "טלגרם" to "telegram", "נטפליקס" to "netflix",
        "מצלמה" to "camera", "הגדרות" to "settings", "גלריה" to "gallery", "תמונות" to "photos", "טלפון" to "phone",
        "אנשי קשר" to "contacts", "הודעות" to "messages", "גימייל" to "gmail", "ג׳ימייל" to "gmail", "אאוטלוק" to "outlook",
        "פלגייט" to "palgate", "פאלגייט" to "palgate", "מוביט" to "moovit", "גט" to "gett", "יאנגו" to "yango", "פנגו" to "pango",
        "סלופארק" to "cellopark", "טיקטוק" to "tiktok", "מסנג׳ר" to "messenger", "מסנג'ר" to "messenger", "זום" to "zoom",
        "טימס" to "teams", "שעון" to "clock", "מחשבון" to "calculator", "יומן" to "calendar", "ביט" to "bit", "פייבוקס" to "paybox",
        "וולט" to "wolt", "תן ביס" to "10bis", "סיגנל" to "signal", "שזאם" to "shazam", "קבצים" to "files", "הקבצים שלי" to "my files",
        "חנות" to "play store", "פליי סטור" to "play store", "רדיו" to "radio", "פודקאסטים" to "podcasts", "אמזון" to "amazon",
        "עליאקספרס" to "aliexpress", "טוויטר" to "x", "קול בדרך" to "קול בדרך"
    )

    private fun translit(s: String): String {
        val sb = StringBuilder()
        for ((i, ch) in s.withIndex()) {
            sb.append(
                when (ch) {
                    'א', 'ע', 'ה', 'י' -> ""
                    'ב' -> "b"
                    'ג' -> "g"
                    'ד' -> "d"
                    'ז' -> "z"
                    'ח' -> "h"
                    'ט' -> "t"
                    'ו' -> if (i == 0 || s.getOrNull(i + 1) == 'ו') "v" else ""
                    'כ', 'ך', 'ק' -> "k"
                    'ל' -> "l"
                    'מ', 'ם' -> "m"
                    'נ', 'ן' -> "n"
                    'ס', 'ש' -> "s"
                    'פ', 'ף' -> "p"
                    'צ', 'ץ' -> "ts"
                    'ר' -> "r"
                    'ת' -> "t"
                    else -> ch.lowercaseChar().toString()
                }
            )
        }
        return sb.toString()
    }

    /** "שלד עיצורים" להשוואה בין עברית לאנגלית: whatsapp ≈ וואטסאפ. */
    private fun skeleton(s0: String): String {
        var s = s0.lowercase()
        if (s.any { it in '\u05D0'..'\u05EA' }) s = translit(s)
        s = s.replace("ph", "p").replace("ch", "k").replace("sh", "s").replace("ck", "k")
            .replace(Regex("c(?=[eiy])"), "s").replace("c", "k").replace("q", "k").replace("x", "ks")
            .replace("w", "v").replace("f", "p").replace("z", "s")
        s = s.filter { it in 'a'..'z' || it in '0'..'9' }.replace(Regex("[aeiouyh]"), "")
        return s.replace(Regex("(.)\\1+"), "$1")
    }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    private fun sim(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        if (a.length >= 3 && (b.contains(a) || a.contains(b) && b.length >= 3)) return 0.9
        return 1.0 - lev(a, b).toDouble() / maxOf(a.length, b.length)
    }

    fun apps(c: Context): List<Pair<String, String>> = Perms.launcherApps(c)

    /** מחזיר (שם, חבילה) של האפליקציה הכי מתאימה, או null. */
    fun find(c: Context, rawQuery: String): Pair<String, String>? {
        val q0 = rawQuery.trim()
        if (q0.isEmpty()) return null
        val queries = linkedSetOf(q0, q0.removePrefix("ל"), q0.removePrefix("ה"), q0.removePrefix("ל").removePrefix("ה"), q0.removePrefix("את "))
            .map { it.trim() }.filter { it.isNotEmpty() }
        val list = apps(c)
        var best: Pair<String, String>? = null
        var bestScore = 0.0
        for ((label, pkg) in list) {
            val l = label.lowercase()
            val lSk = skeleton(label)
            val pSk = skeleton(pkg.substringAfterLast('.'))
            for (q in queries) {
                val ql = q.lowercase()
                val alias = aliases[q]
                var s = 0.0
                if (alias != null) {
                    if (l.contains(alias) || pkg.contains(alias.replace(" ", ""))) s = 1.0
                    s = maxOf(s, sim(skeleton(alias), lSk), sim(skeleton(alias), pSk))
                }
                if (l == ql) s = maxOf(s, 1.0)
                if (ql.length >= 2 && l.contains(ql)) s = maxOf(s, 0.92)
                val qSk = skeleton(q)
                s = maxOf(s, sim(qSk, lSk), sim(qSk, pSk) - 0.05)
                if (s > bestScore) {
                    bestScore = s
                    best = label to pkg
                }
            }
        }
        return if (bestScore >= 0.72) best else null
    }

    fun open(c: Context, query: String): String? {
        val hit = find(c, query) ?: return null
        val i = c.packageManager.getLaunchIntentForPackage(hit.second) ?: return null
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            c.startActivity(i)
            hit.first
        } catch (e: Exception) {
            null
        }
    }
}
