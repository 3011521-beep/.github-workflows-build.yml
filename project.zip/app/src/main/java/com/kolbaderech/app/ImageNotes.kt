package com.kolbaderech.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/** תמונה בוואטסאפ: במקום "התקבלה תמונה" – Gemini מתאר מה רואים בה. */
object ImageNotes {
    private val used = LinkedHashSet<String>()

    fun isImage(text: String): Boolean {
        val l = text.trim().lowercase()
        return text.contains("📷") || l == "תמונה" || l == "photo" || l == "image" || l.startsWith("תמונה ") || l.startsWith("photo ")
    }

    /** הכיתוב שנשלח עם התמונה (אם יש). */
    fun caption(text: String): String =
        text.replace("📷", "").replace(Regex("^(תמונה|Photo|Image)\\s*", RegexOption.IGNORE_CASE), "").trim()

    /** שומר את התמונה מההתראה (אם וואטסאפ צירף אותה) לקובץ זמני. */
    fun saveFromNotification(c: Context, picture: Bitmap?, uri: Uri?, id: String): String? {
        val bmp = picture ?: uri?.let {
            try {
                c.contentResolver.openInputStream(it)?.use { s -> BitmapFactory.decodeStream(s) }
            } catch (e: Throwable) {
                DLog.i("🖼️ אין גישה לתמונה מההתראה (${e.javaClass.simpleName})")
                null
            }
        } ?: return null
        return try {
            val dir = File(c.cacheDir, "img").apply { mkdirs() }
            dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 3 * 60 * 60_000L }?.forEach { it.delete() }
            val f = File(dir, "$id.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            f.absolutePath
        } catch (e: Throwable) {
            null
        }
    }

    /** כל תיקיות התמונות של וואטסאפ ווואטסאפ עסקים (מיקום ישן וחדש). */
    private fun dirs(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        return listOf(
            File(root, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images"),
            File(root, "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Images"),
            File(root, "WhatsApp/Media/WhatsApp Images"),
            File(root, "WhatsApp Business/Media/WhatsApp Business Images")
        )
    }

    private val imgExt = Regex("\\.(jpe?g|png|webp)$", RegexOption.IGNORE_CASE)

    /** קבצי התמונות בתיקייה, כולל תת-תיקיות (Private וכו') עד עומק 2, בלי "Sent". */
    private fun listImages(d: File, depth: Int = 0, out: ArrayList<File> = ArrayList()): ArrayList<File> {
        val items = try { d.listFiles() } catch (e: Throwable) { null } ?: return out
        for (f in items) {
            if (f.isDirectory) {
                if (depth < 2 && !f.name.equals("Sent", ignoreCase = true)) listImages(f, depth + 1, out)
            } else if (imgExt.containsMatchIn(f.name)) out.add(f)
        }
        return out
    }

    /** התמונה הכי חדשה שוואטסאפ שמר (לא מתיקיית "נשלח"). */
    @Synchronized
    fun findLatest(c: Context, since: Long): String? {
        // גם בלי "גישה לכל הקבצים" – עם הרשאת תמונות אנדרואיד מאפשר לקרוא קבצי מדיה
        val hit = try {
            dirs().filter { it.isDirectory }
                .flatMap { listImages(it) }
                .filter { it.isFile && it.lastModified() >= since - 180_000 && it.absolutePath !in used }
                .maxByOrNull { it.lastModified() }
        } catch (e: Throwable) {
            null
        } ?: return null
        used.add(hit.absolutePath)
        while (used.size > 100) used.remove(used.first())
        return hit.absolutePath
    }

    private fun mediaPermOk(c: Context): Boolean =
        android.os.Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) == android.content.pm.PackageManager.PERMISSION_GRANTED

    /** מחכה עד 30 שניות שוואטסאפ ישמור את התמונה (ההורדה לוקחת זמן), ומחפש גם במאגר התמונות של אנדרואיד. */
    fun waitForImage(c: Context, since: Long, where: String = ""): String? {
        if (where.isNotBlank()) {
            DLog.i("🖼️ ההודעה הגיעה מוואטסאפ$where – הקבצים של פרופיל אחר לא נגישים לנוגה, כנראה לא אמצא את התמונה")
        }
        if (!VoiceNotes.canRead(c) && !mediaPermOk(c)) {
            DLog.i("🖼️ אין הרשאת גישה לקבצים או לתמונות – כנראה לא אמצא את התמונה")
        }
        for (i in 0 until 15) {
            findLatest(c, since)?.let { return it }
            fromMediaStore(c, since)?.let { return it }
            try { Thread.sleep(2000) } catch (e: InterruptedException) { DLog.i("🖼️ חיפוש התמונה הופסק באמצע (סבב ${i + 1})"); return null }
        }
        DLog.i("🖼️ אבחון: " + diagnose(c, since))
        return null
    }

    /** שורה אחת שמסבירה למה לא נמצאה תמונה: הרשאות, אילו תיקיות קיימות, ומתי נשמרה התמונה האחרונה. */
    fun diagnose(c: Context, since: Long): String = try {
        val fmt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
        val allFiles = VoiceNotes.canRead(c)
        val media = if (android.os.Build.VERSION.SDK_INT >= 33) (if (mediaPermOk(c)) "יש" else "אין") else "לא נדרש"
        val sb = StringBuilder("גישה לכל הקבצים: ${if (allFiles) "יש" else "אין"}, הרשאת תמונות: $media, חיפוש מ-${fmt.format(java.util.Date(since))}. ")
        val root = Environment.getExternalStorageDirectory().absolutePath
        val parts = dirs().map { d ->
            val name = d.absolutePath.removePrefix(root).trim('/')
            if (!d.isDirectory) "$name: לא קיימת"
            else {
                val files = listImages(d)
                val newest = files.maxByOrNull { it.lastModified() }
                if (newest == null) "$name: ${if (d.list() == null) "אין גישה" else "ריקה"}"
                else "$name: ${files.size} תמונות, האחרונה ${fmt.format(java.util.Date(newest.lastModified()))}"
            }
        }
        sb.append(parts.joinToString("; ")).toString()
    } catch (e: Throwable) {
        "שגיאה באבחון: ${e.javaClass.simpleName}"
    }

    // נוגע ב-used כמו findLatest – חייב את אותה נעילה (אחרת ConcurrentModificationException)
    @Synchronized
    private fun fromMediaStore(c: Context, since: Long): String? = try {
        val ms = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val withPath = android.os.Build.VERSION.SDK_INT >= 29
        val cols = arrayListOf(android.provider.MediaStore.Images.Media._ID, android.provider.MediaStore.Images.Media.DISPLAY_NAME)
        if (withPath) cols.add(android.provider.MediaStore.MediaColumns.RELATIVE_PATH)
        val sel = "${android.provider.MediaStore.Images.Media.DATE_ADDED} >= ?"
        c.contentResolver.query(
            ms, cols.toTypedArray(),
            sel, arrayOf(((since - 180_000) / 1000).toString()), "${android.provider.MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { cur ->
            var found: String? = null
            while (cur.moveToNext() && found == null) {
                val name = cur.getString(1) ?: ""
                val rel = if (withPath) (cur.getString(2) ?: "") else ""
                val waName = name.startsWith("IMG-") && name.contains("-WA")
                val waPath = rel.contains("WhatsApp", ignoreCase = true)
                if (!waName && !waPath) continue
                if (rel.contains("/Sent", ignoreCase = true)) continue
                val itemUri = android.content.ContentUris.withAppendedId(ms, cur.getLong(0))
                if (itemUri.toString() in used) continue
                used.add(itemUri.toString())
                while (used.size > 100) used.remove(used.first())
                found = saveFromNotification(c, null, itemUri, "ms" + cur.getLong(0))
            }
            found
        }
    } catch (e: Throwable) {
        val now = System.currentTimeMillis()
        if (now - lastMsErr > 60_000) {
            lastMsErr = now
            DLog.i("🖼️ שגיאה בחיפוש במאגר המדיה: ${e.javaClass.simpleName}")
        }
        null
    }
    private var lastMsErr = 0L

    /** מקטין ומכין לשליחה (חוסך גלישה). */
    private fun toJpegBase64(path: String): String? = try {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, opts)
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > 1600) sample *= 2
        val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: null
        if (bmp == null) null else {
            val scale = 1024f / maxOf(bmp.width, bmp.height)
            val small = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
            val out = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 75, out)
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        }
    } catch (e: Throwable) {
        null
    }

    /** מבקש מ-Gemini תיאור קצר בעברית. רץ ברקע. */
    fun describe(path: String, caption: String): String? {
        val b64 = toJpegBase64(path) ?: return null
        val prompt = "תאר בעברית, בקצרה (משפט או שניים), מה רואים בתמונה הזאת, כך שיתאים להקראה בקול לנהג. " +
            "אם יש בה טקסט חשוב – הקרא אותו. אל תתחיל ב'בתמונה רואים'." +
            if (caption.isNotBlank()) " הכיתוב שנשלח עם התמונה: \"$caption\"" else ""
        val body = JSONObject().put(
            "contents", JSONArray().put(
                JSONObject().put(
                    "parts", JSONArray()
                        .put(JSONObject().put("text", prompt))
                        .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
                )
            )
        )
        val (code, res) = Gemini.post(body.toString())
        if (code !in 200..299) return null
        return try {
            val parts = JSONObject(res).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            (0 until parts.length()).map { parts.getJSONObject(it) }.filter { !it.optBoolean("thought") }
                .joinToString("") { it.optString("text") }.trim().ifBlank { null }
        } catch (e: Throwable) {
            null
        }
    }
}
