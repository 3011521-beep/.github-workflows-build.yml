package com.kolbaderech.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import androidx.core.content.ContextCompat

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashGuard.install(this)
        DLog.init(this)
        Prefs.init(this)
        Store.init(this)
        Announcer.init(this)
        CrashGuard.safe(Unit) { Wake.checkCrashGuard(this) }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("drive", "מצב נהיגה", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alerts", "תזכורות והתראות", NotificationManager.IMPORTANCE_HIGH))
        if (CrashGuard.safeMode(this)) return
        if (!Prefs.radioLoaded) CrashGuard.safe(Unit) { Radio.loadAllIsraeli { n -> if (n > 0) Prefs.radioLoaded = true } }
        CrashGuard.safe(Unit) { if (Prefs.isCar) startCarLink(this) else Link.startServer(this) }
    }

    companion object {
        fun startCarLink(app: android.content.Context) {
            if (CrashGuard.safeMode(app)) return
            startServiceSafely(app, Intent(app, LinkService::class.java))
            CrashGuard.safe(Unit) { Link.startClient(app) }
        }

        /** קודם שירות רגיל (לא מחייב התראה), ורק אם אסור – שירות קדמי. */
        fun startServiceSafely(app: android.content.Context, i: Intent) {
            try {
                app.startService(i)
            } catch (e: Throwable) {
                try {
                    ContextCompat.startForegroundService(app, i)
                } catch (e2: Throwable) {
                }
            }
        }
    }
}
