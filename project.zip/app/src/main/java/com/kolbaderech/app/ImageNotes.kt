package com.kolbaderech.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/** תמונה בוואטסאפ: במקום "התקבלה תמונה" – Gemini מתאר מה רואים בה. */
object ImageNotes {
    private val used = LinkedHashSet<String>()

    fun isImage(text: String): Boolean {
        val l = text.trim().lowercase()
        return text.contains("📷") || l == "תמונה" || l == "photo" || l == "image" || l.startsWith("תמונה ") || l.startsWith("photo ")
    }

    /** הכיתוב שנשלח עם התמונה (אם יש). */
    fun caption(text: String): String =
        text.replace("📷", "").replace(Regex("^(תמונה|Photo|Image)\\s*", RegexOption.IGNORE_CASE), "").trim()

    /** שומר את התמונה מההתראה (אם וואטסאפ צירף אותה) לקובץ זמני. */
    fun saveFromNotification(c: Context, picture: Bitmap?, uri: Uri?, id: String): String? {
        val bmp = picture ?: uri?.let {
            try {
                c.contentResolver.openInputStream(it)?.use { s -> BitmapFactory.decodeStream(s) }
            } catch (e: Throwable) {
                DLog.i("🖼️ אין גישה לתמונה מההתראה (${e.javaClass.simpleName})")
                null
            }
        } ?: return null
        return try {
            val dir = File(c.cacheDir, "img").apply { mkdirs() }
            dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 3 * 60 * 60_000L }?.forEach { it.delete() }
            val f = File(dir, "$id.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            f.absolutePath
        } catch (e: Throwable) {
            null
        }
    }

    private fun dirs(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        return listOf(
            File(root, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images"),
            File(root, "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Images"),
            File(root, "WhatsApp/Media/WhatsApp Images"),
            File(root, "WhatsApp Business/Media/WhatsApp Business Images")
        )
    }

    /** התמונה הכי חדשה שוואטסאפ שמר (לא מתיקיית "נשלח"). */
    @Synchronized
    fun findLatest(c: Context, since: Long): String? {
        if (!VoiceNotes.canRead(c)) return null
        val hit = dirs().filter { it.isDirectory }
            .flatMap { d -> d.listFiles()?.toList() ?: emptyList() }
            .filter { it.isFile && Regex("\\.(jpe?g|png|webp)$", RegexOption.IGNORE_CASE).containsMatchIn(it.name) }
            .filter { it.lastModified() >= since - 180_000 && it.absolutePath !in used }
            .maxByOrNull { it.lastModified() } ?: return null
        used.add(hit.absolutePath)
        while (used.size > 100) used.remove(used.first())
        return hit.absolutePath
    }

    /** מקטין ומכין לשליחה (חוסך גלישה). */
    private fun toJpegBase64(path: String): String? = try {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, opts)
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > 1600) sample *= 2
        val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: null
        if (bmp == null) null else {
            val scale = 1024f / maxOf(bmp.width, bmp.height)
            val small = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
            val out = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 75, out)
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        }
    } catch (e: Throwable) {
        null
    }

    /** מבקש מ-Gemini תיאור קצר בעברית. רץ ברקע. */
    fun describe(path: String, caption: String): String? {
        val b64 = toJpegBase64(path) ?: return null
        val prompt = "תאר בעברית, בקצרה (משפט או שניים), מה רואים בתמונה הזאת, כך שיתאים להקראה בקול לנהג. " +
            "אם יש בה טקסט חשוב – הקרא אותו. אל תתחיל ב'בתמונה רואים'." +
            if (caption.isNotBlank()) " הכיתוב שנשלח עם התמונה: \"$caption\"" else ""
        val body = JSONObject().put(
            "contents", JSONArray().put(
                JSONObject().put(
                    "parts", JSONArray()
                        .put(JSONObject().put("text", prompt))
                        .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
                )
            )
        )
        val (code, res) = Gemini.post(body.toString())
        if (code !in 200..299) return null
        return try {
            val parts = JSONObject(res).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            (0 until parts.length()).map { parts.getJSONObject(it) }.filter { !it.optBoolean("thought") }
                .joinToString("") { it.optString("text") }.trim().ifBlank { null }
        } catch (e: Throwable) {
            null
        }
    }
}
