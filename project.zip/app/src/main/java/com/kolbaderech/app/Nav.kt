package com.kolbaderech.app

import android.content.Context
import android.content.Intent
import android.net.Uri

object Nav {
    private fun open(ctx: Context, uri: String): Boolean = try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    fun to(ctx: Context, q: String) {
        val enc = Uri.encode(q)
        if (!open(ctx, "waze://?q=$enc&navigate=yes")) open(ctx, "google.navigation:q=$enc")
    }

    fun home(ctx: Context) {
        if (!open(ctx, "waze://?favorite=home&navigate=yes")) to(ctx, "בית")
    }

    fun work(ctx: Context) {
        if (!open(ctx, "waze://?favorite=work&navigate=yes")) to(ctx, "עבודה")
    }

    fun openWaze(ctx: Context) {
        val i = ctx.packageManager.getLaunchIntentForPackage("com.waze") ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
        }
    }

    // נגיש גם מה-Thread של החיבור לטלפון (onAddress) וגם מה-Main
    private val pending = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    /** ניווט חכם: אם זה שם של איש קשר עם כתובת שמורה – נוסעים לכתובת שלו. */
    fun toSmart(ctx: Context, q: String) {
        val app = ctx.applicationContext
        if (Prefs.isCar && Link.connected.value) {
            val id = System.currentTimeMillis().toString()
            pending[id] = q
            Link.send(Link.obj("addr", "id" to id, "q" to q))
            handler.postDelayed({ pending.remove(id)?.let { to(app, it) } }, 1500)
            return
        }
        val a = Contacts.addressFor(app, q)
        if (a != null) DLog.i("🗺️ $q → כתובת מאנשי הקשר: $a")
        to(app, a ?: q)
    }

    fun onAddress(ctx: Context, id: String, addr: String?) {
        val q = pending.remove(id) ?: return
        if (addr != null) DLog.i("🗺️ $q → כתובת מאנשי הקשר: $addr")
        to(ctx.applicationContext, addr ?: q)
    }
}
