package com.kolbaderech.app

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

/**
 * הלב של האפליקציה: תור הודעות, הקראה, הנמכת מוזיקה, תגובות ופקודות.
 * רץ במכשיר שמדבר: מסך הרכב, או הטלפון כשאין מסך מחובר.
 */
object Announcer {
    private lateinit var app: Context
    private val handler = Handler(Looper.getMainLooper())

    val state = MutableStateFlow<UiState>(UiState.Idle)
    val history = MutableStateFlow<List<HistoryItem>>(emptyList())

    var muted = false

    // ---------- TTS ----------
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val afterInit = ArrayList<() -> Unit>()
    private var curId: String? = null
    private var curText: String? = null
    private var curThen: (() -> Unit)? = null
    private var interrupted = false
    private var listening = false

    // ---------- תור ----------
    private val queue = ArrayDeque<Msg>()
    private var busy = false
    private var wasInCall = false
    private var current: List<Msg> = emptyList()
    private var lastBatch: List<Msg> = emptyList()
    private var lastSenderKey: String? = null
    private var lastSenderTime = 0L
    private var sessionOpen = false

    // ---------- אודיו ----------
    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()
    private var focusReq: AudioFocusRequest? = null
    private val am: AudioManager get() = app.getSystemService(AudioManager::class.java)

    fun init(c: Context) {
        app = c.applicationContext
        tts = CrashGuard.safe(null) { TextToSpeech(app) { status -> onTtsInit(status) } }
    }

    private fun onTtsInit(status: Int) {
        CrashGuard.safe(Unit) {
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("he", "IL")
                tts?.setAudioAttributes(attrs)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        handler.post { onUtteranceEnd(utteranceId) }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        handler.post { onUtteranceEnd(utteranceId) }
                    }
                    override fun onError(utteranceId: String?, errorCode: Int) {
                        handler.post { onUtteranceEnd(utteranceId) }
                    }
                })
                ttsReady = true
                val pending = ArrayList(afterInit)
                afterInit.clear()
                pending.forEach { it() }
            }
        }
    }

    // =====================================================================
    // דיבור
    // =====================================================================
    private fun fixPronunciation(text: String): String {
        var t = text
        Prefs.pairs(Prefs.pronunciation).forEach { (from, to) -> t = t.replace(from, to) }
        return t
    }

    private fun speak(text: String, then: () -> Unit) {
        if (!ttsReady) {
            afterInit.add { speak(text, then) }
            return
        }
        val id = UUID.randomUUID().toString()
        curId = id
        curText = text
        curThen = then
        interrupted = false
        tts?.setSpeechRate(Prefs.speechRate)
        tts?.speak(fixPronunciation(text), TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun onUtteranceEnd(id: String?) {
        if (id == null || id != curId || interrupted) return
        val then = curThen
        curId = null; curThen = null; curText = null
        then?.invoke()
    }

    private fun silence() {
        curId = null; curThen = null; curText = null
        interrupted = false
        tts?.stop()
        VoiceNotes.stop()
    }

    /** הודעת מערכת קצרה (סיכומים, תזכורות, תשובות). נכנסת לתור. */
    fun notice(text: String) {
        if (text.isBlank()) return
        enqueue(Msg.notice(text), force = true)
    }

    fun testVoice() = notice("שלום, ככה אני נשמעת. הודעה מדני בוואטסאפ: אני מגיע בעוד עשר דקות")

    // =====================================================================
    // פוקוס אודיו: המוזיקה יורדת בזמן דיבור וחוזרת לבד
    // =====================================================================
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT, AudioManager.AUDIOFOCUS_LOSS -> {
                // למשל וייז אומר "פנה ימינה": עוצרים ומחכים
                if (!listening && curId != null) {
                    interrupted = true
                    tts?.stop()
                    if (change == AudioManager.AUDIOFOCUS_LOSS) {
                        handler.postDelayed({ resumeInterrupted(true) }, 6000)
                    }
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> handler.postDelayed({ resumeInterrupted(false) }, 400)
        }
    }

    private fun resumeInterrupted(refocus: Boolean) {
        if (!interrupted) return
        val text = curText
        val then = curThen
        interrupted = false
        if (refocus) requestFocus()
        if (text != null && then != null) speak(text, then)
    }

    private fun requestFocus(exclusive: Boolean = false) {
        abandonFocus()
        val gain = if (Prefs.duck && !exclusive) AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
        else AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
        val req = AudioFocusRequest.Builder(gain)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(focusListener, handler)
            .build()
        focusReq = req
        try {
            am.requestAudioFocus(req)
        } catch (e: Exception) {
        }
    }

    private fun abandonFocus() {
        focusReq?.let {
            try {
                am.abandonAudioFocusRequest(it)
            } catch (e: Exception) {
            }
        }
        focusReq = null
    }

    fun localInCall(): Boolean {
        val m = am.mode
        return m == AudioManager.MODE_IN_CALL || m == AudioManager.MODE_IN_COMMUNICATION ||
            m == AudioManager.MODE_RINGTONE
    }

    private fun inCall(): Boolean {
        if (Prefs.isCar && Link.connected.value && Link.phoneInCall) return true
        return localInCall()
    }

    // =====================================================================
    // מסך
    // =====================================================================
    private fun openSession(exclusive: Boolean = false, show: Boolean = true) {
        Wake.stop()
        Voice.cancel()
        if (!sessionOpen) {
            sessionOpen = true
            requestFocus(exclusive)
        }
        if (show) showScreen()
    }

    private fun closeSession() {
        sessionOpen = false
        busy = false
        current = emptyList()
        abandonFocus()
        state.value = UiState.Idle
        if (Wake.configured()) handler.postDelayed({ if (!busy && !sessionOpen) Wake.start(app) }, 800)
        else scheduleWake(1500)
    }

    private fun showScreen() {
        try {
            app.startActivity(
                Intent(app, ReadingActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (e: Exception) {
        }
    }

    // =====================================================================
    // תור הודעות
    // =====================================================================
    fun enqueue(m: Msg, force: Boolean = false) {
        if (!force && (!DriveState.active.value || !Prefs.autoRead || muted)) return
        if (!m.notice && muted) return
        if (!m.notice) {
            if (!Prefs.isCar && Link.connected.value) {
                Relay.forward(m)
                return
            }
            Store.inc("messages")
        }
        if (m.urgent) queue.addFirst(m) else queue.addLast(m)
        pump()
    }

    fun testMessage() {
        enqueue(
            Msg(pkg = "test", app = "וואטסאפ", sender = "דני",
                text = "זו הודעת בדיקה. אני מגיע בעוד עשר דקות, תשמור לי מקום"),
            force = true
        )
    }

    private val pumpRunnable = Runnable { pump() }

    private fun pump() {
        if (busy) return
        if (queue.isEmpty()) {
            if (sessionOpen) closeSession()
            return
        }
        if (Prefs.silentInCalls && inCall()) {
            wasInCall = true
            if (sessionOpen) {
                sessionOpen = false
                abandonFocus()
                state.value = UiState.Idle
            }
            handler.removeCallbacks(pumpRunnable)
            handler.postDelayed(pumpRunnable, 2000)
            return
        }
        if (wasInCall) {
            wasInCall = false
            busy = true
            handler.postDelayed({
                busy = false
                val real = queue.count { !it.notice }
                if (inCall()) {
                    pump()
                } else if (real >= 2) {
                    busy = true
                    openSession(show = false)
                    speak(callSummary()) {
                        busy = false
                        readNext()
                    }
                } else {
                    pump()
                }
            }, 2000)
            return
        }
        readNext()
    }

    private fun callSummary(): String {
        val msgs = queue.filter { !it.notice }
        val counts = msgs.groupingBy { it.sender }.eachCount().entries.take(4)
        val parts = counts.map { (s, n) -> if (n == 1) "אחת מ-$s" else "$n מ-$s" }
        return "בזמן השיחה קיבלת ${msgs.size} הודעות: ${parts.joinToString(", ")}"
    }

    private val otpRe = Regex("(קוד|code|סיסמ|אימות|OTP)", RegexOption.IGNORE_CASE)

    private fun spokenBody(m: Msg): String {
        var t = if (m.isEmail) {
            if (Prefs.shortEmails || m.body.isBlank()) "נושא: ${m.text}"
            else "נושא: ${m.text}. ${m.body}"
        } else m.text
        t = Emoji.toWords(t)
        if (Prefs.otp && otpRe.containsMatchIn(t)) {
            t = Regex("\\b\\d{4,8}\\b").replace(t) { r -> r.value.toCharArray().joinToString(" ") }
        }
        if (t.length > 350) t = t.take(350) + "… ההודעה ממשיכה, אפשר לקרוא אותה בטלפון"
        return t
    }

    private fun readNext() {
        val first = queue.removeFirstOrNull()
        if (first == null) {
            closeSession()
            return
        }
        busy = true

        if (first.notice) {
            current = emptyList()
            state.value = UiState.Info(first.text)
            openSession(show = false)
            speak(first.text) { next() }
            return
        }

        if (first.kind == "voice") {
            readVoice(first)
            return
        }

        val batch = mutableListOf(first)
        if (Prefs.groupMessages) {
            while (true) {
                val n = queue.firstOrNull() ?: break
                if (!n.notice && n.pkg == first.pkg && n.sender == first.sender) batch.add(queue.removeFirst()) else break
            }
        }
        current = batch
        lastBatch = batch
        val lines = batch.map { if (it.kind == "event" || it.kind == "app") listOf(it.sender, spokenBody(it)).filter { s -> s.isNotBlank() }.joinToString(". ") else spokenBody(it) }
        val now = System.currentTimeMillis()
        val key = first.pkg + first.sender
        val continued = key == lastSenderKey && now - lastSenderTime < 90_000
        lastSenderKey = key
        lastSenderTime = now

        val intro = when {
            first.kind == "event" -> "תזכורת מ${first.app}"
            first.kind == "app" -> "התראה מ${first.app}"
            continued -> "ועוד מ-${first.sender}"
            first.isEmail && batch.size > 1 -> "${batch.size} מיילים מ-${first.sender}"
            first.isEmail -> "מייל מ-${first.sender}"
            batch.size > 1 -> "${batch.size} הודעות מ-${first.sender} ב${first.app}"
            else -> "הודעה מ-${first.sender} ב${first.app}"
        }
        val appLabel = if (batch.size > 1) "${first.app} · ${batch.size} הודעות" else first.app
        val canReply = Prefs.voiceReply && batch.last().canReply
        state.value = UiState.Reading(first.sender, appLabel, lines, canReply, queue.count { !it.notice }, first.pkg)
        batch.forEach { remember(it) }
        addHistory(first.sender, first.app, lines.joinToString(" · "), first.pkg, batch.last().id, batch.last().canReply)
        openSession()
        if (Prefs.appSounds) Voice.appTone(first.pkg, first.isEmail)
        handler.postDelayed({
            speak("$intro. " + lines.joinToString(". ")) { afterRead() }
        }, if (Prefs.appSounds) 350L else 0L)
    }

    /** הודעה קולית: "הודעה קולית מדני, 12 שניות" ואז משמיעה אותה. */
    private fun readVoice(m: Msg) {
        current = listOf(m)
        lastBatch = listOf(m)
        remember(m)
        val dur = VoiceNotes.durationText(m.text)
        val label = "🎤 הודעה קולית" + if (dur.isNotEmpty()) " · $dur" else ""
        state.value = UiState.Reading(m.sender, m.app, listOf(label), Prefs.voiceReply && m.canReply, queue.count { !it.notice }, m.pkg)
        addHistory(m.sender, m.app, label, m.pkg, m.id, m.canReply)
        openSession()
        val intro = "הודעה קולית מ-${m.sender}" + if (dur.isNotEmpty()) ", $dur" else ""
        val path = m.audio
        speak(intro) {
            if (path != null && Prefs.voiceNotes) {
                // עוצרים את המוזיקה לגמרי בזמן ההשמעה
                abandonFocus()
                requestFocus(exclusive = true)
                val ok = VoiceNotes.play(path, attrs) { handler.post { afterRead() } }
                if (!ok) speak("לא הצלחתי להשמיע את ההודעה") { afterRead() }
            } else {
                val why = if (!m.remote && !VoiceNotes.canRead(app)) "צריך לאשר גישה לקבצים בהגדרות כדי שאשמיע הודעות קוליות"
                else "אפשר לשמוע אותה בטלפון"
                speak(why) { afterRead() }
            }
        }
    }

    fun addHistory(sender: String, app: String, text: String, pkg: String? = null, id: String? = null, canReply: Boolean = false) {
        history.value = (listOf(HistoryItem(sender, app, text, System.currentTimeMillis(), pkg, id, canReply)) + history.value).take(60)
    }

    // ---------- הודעות אחרונות, כדי שאפשר יהיה להגיב גם מאוחר יותר ----------
    private val recentMsgs = LinkedHashMap<String, Msg>()

    fun remember(m: Msg) {
        if (m.notice) return
        recentMsgs.remove(m.id)
        recentMsgs[m.id] = m
        while (recentMsgs.size > 80) recentMsgs.remove(recentMsgs.keys.first())
    }

    /** לחיצה על הודעה ברשימה: "מה לענות ל-דני?" */
    fun replyTo(id: String): Boolean {
        val m = recentMsgs[id] ?: return false
        if (!m.canReply) return false
        startReply(m, null)
        return true
    }

    /** "תעני לדני שאני בדרך" – גם הרבה אחרי שההודעה הוקראה. */
    fun replyByName(name: String, text: String?): Boolean {
        val n = name.trim().removePrefix("ל").trim()
        val m = recentMsgs.values.reversed().firstOrNull {
            it.canReply && (n.isEmpty() || it.sender.contains(n) || n.contains(it.sender))
        } ?: return false
        startReply(m, text)
        return true
    }

    private fun startReply(m: Msg, text: String?) {
        if (busy) {
            Voice.cancel(); listening = false; silence()
            closeSession()
        }
        busy = true
        current = listOf(m)
        openSession(exclusive = true)
        if (text.isNullOrBlank()) listenForReply(m, explicit = true) else confirmReply(m, text)
    }

    /** "תשתקי" / "תסתמי": מפסיקה מיד ולא מקריאה עד סוף הנסיעה. */
    fun muteNow() {
        muted = true
        queue.removeAll { !it.notice }
    }

    // ---------- שאלה בתחילת נסיעה ----------
    fun askReadingPreference() {
        if (!Prefs.askAtStart || !DriveState.active.value) return
        if (busy || sessionOpen) {
            handler.postDelayed({ askReadingPreference() }, 1500)
            return
        }
        busy = true
        current = emptyList()
        state.value = UiState.Listening("להקריא הודעות בנסיעה הזאת?", "אמור „כן“ או „לא“")
        openSession(exclusive = true)
        speak("להקריא לך הודעות בנסיעה הזאת?") {
            listen { heard ->
                val no = heard != null && Commands.isNoReading(heard)
                if (no) {
                    muteNow()
                    speak("בסדר, לא אקריא הודעות בנסיעה הזאת. אם תרצה, תגיד „תחזרי להקריא“") { closeSession(); pump() }
                } else {
                    muted = false
                    speak(if (heard == null) "אקריא הודעות כרגיל" else "מעולה, אקריא") { closeSession(); pump() }
                }
            }
        }
    }

    /** אייקון האפליקציה שנפתחה עכשיו (ספוטיפיי, וייז…) להצגה במסך. */
    var iconHint: String? = null

    private fun afterRead() {
        val last = current.lastOrNull()
        if (last != null && Prefs.voiceReply && last.canReply && queue.none { it.urgent }) {
            listenForReply(last, explicit = false)
        } else {
            next()
        }
    }

    private fun next() {
        busy = false
        current = emptyList()
        pump()
    }

    fun repeatLast(): Boolean {
        if (lastBatch.isEmpty()) return false
        lastSenderKey = null
        lastBatch.reversed().forEach { queue.addFirst(it) }
        return true
    }

    fun lastMessages(): List<Msg> = lastBatch

    // =====================================================================
    // הקשבה ותגובות
    // =====================================================================
    private fun listen(onResult: (String?) -> Unit) {
        listening = true
        Voice.beep()
        handler.postDelayed({
            Voice.listen(app) { text ->
                listening = false
                onResult(text)
            }
        }, 250)
    }

    private fun listenForReply(m: Msg, explicit: Boolean) {
        state.value = UiState.Listening(
            if (explicit) "מה לענות ל-${m.sender}?" else "אפשר לומר „תעני לו…“", null
        )
        listen { heard ->
            if (heard == null) {
                next()
                return@listen
            }
            state.value = UiState.Listening("שמעתי", heard)
            val reply = if (explicit) Commands.replyFromAnything(heard) else Commands.extractReply(heard)
            when {
                reply != null -> confirmReply(m, reply)
                Commands.isStop(heard) -> uiStop()
                Commands.isLater(heard) -> {
                    saveLater(m)
                    speak("שמרתי לאחר כך") { next() }
                }
                else -> next()
            }
        }
    }

    private fun saveLater(m: Msg) {
        if (Prefs.isCar && Link.connected.value) {
            Link.send(Link.obj("later", "sender" to m.sender, "text" to spokenBody(m)))
        } else {
            Store.add(Store.LATER, Store.text("${m.sender}: ${spokenBody(m)}"))
        }
    }

    private fun confirmReply(m: Msg, text: String) {
        val original = current.lastOrNull()?.let { spokenBody(it) } ?: ""
        state.value = UiState.ConfirmReply(m.sender, m.app, original, text, Prefs.autoSend)
        val proceed: () -> Unit = {
            listen { heard ->
                val change = heard?.let { Commands.changeTo(it) }
                when {
                    heard != null && Commands.isCancel(heard) -> speak("בוטל") { next() }
                    change != null -> confirmReply(m, change)
                    Prefs.autoSend -> send(m, text)
                    heard != null && Commands.isYes(heard) -> send(m, text)
                    else -> speak("לא נשלח") { next() }
                }
            }
        }
        val say = when {
            Prefs.readBack -> "שולחת ל-${m.sender}: $text"
            !Prefs.autoSend -> "לשלוח?"
            else -> ""
        }
        if (say.isNotEmpty()) speak(say) { proceed() } else proceed()
    }

    private fun send(m: Msg, text: String) {
        val ok = if (m.remote) {
            Link.send(Link.obj("reply", "id" to m.id, "text" to text))
            Link.connected.value
        } else {
            Reply.send(app, m, text)
        }
        Store.inc("replies")
        state.value = UiState.Info(if (ok) "נשלח ל-${m.sender}" else "לא הצלחתי לשלוח")
        speak(if (ok) "נשלח" else "לא הצלחתי לשלוח") { next() }
    }

    // =====================================================================
    // פקודות קוליות
    // =====================================================================
    fun listenCommand() {
        if (busy) {
            Voice.cancel(); listening = false; silence()
            queue.removeAll { !it.notice }
            closeSession()
        }
        busy = true
        current = emptyList()
        state.value = UiState.Listening("מקשיבה…", null)
        openSession(exclusive = true)
        listen { heard ->
            if (heard == null) {
                closeSession()
                pump()
            } else {
                runHeard(heard)
            }
        }
    }

    /** מבצע פקודה מטקסט (מכפתור במסך, ממילת הפעלה או מהמיקרופון). */
    fun runText(text: String) {
        if (busy) {
            Voice.cancel(); listening = false; silence()
            closeSession()
        }
        busy = true
        current = emptyList()
        runHeard(text)
    }

    private var lastHeard: String? = null
    private var pendingLearn: String? = null
    private var pendingLearnAt = 0L

    private fun runHeard(heard: String) {
        state.value = UiState.Listening("שמעתי", heard)
        abandonFocus()
        sessionOpen = false
        handler.postDelayed({
            val corr = Commands.correction(heard)
            val cmd = corr ?: heard
            Commands.replyTarget(cmd)?.let { (name, text) ->
                if (replyByName(name, text)) return@postDelayed
            }
            val say = Commands.handle(app, cmd)
            val ok = say != Commands.UNKNOWN
            // למידה: "לא, התכוונתי ל…" או ניסוח חדש אחרי "לא הבנתי"
            val learnFrom = when {
                corr != null -> lastHeard
                System.currentTimeMillis() - pendingLearnAt < 60_000 -> pendingLearn
                else -> null
            }
            var learned = false
            if (ok && learnFrom != null && Intents.norm(learnFrom) != Intents.norm(cmd)) {
                Learn.add(learnFrom, cmd)
                learned = true
            }
            pendingLearn = null
            lastHeard = cmd
            when {
                !ok && Gemini.available() -> {
                    state.value = UiState.Info("רגע, חושבת…")
                    Gemini.interpret(cmd) { res -> onGemini(res, cmd) }
                }
                !ok -> {
                    pendingLearn = cmd
                    pendingLearnAt = System.currentTimeMillis()
                    finishWith("לא הבנתי. תגיד את זה במילים אחרות, ואזכור לפעם הבאה")
                }
                say != null -> finishWith(if (learned) "$say. למדתי לפעם הבאה" else say)
                learned -> finishWith("בוצע, ולמדתי לפעם הבאה")
                else -> finishSilent(cmd)
            }
        }, 300)
    }

    private fun onGemini(res: String?, original: String) {
        val r = res?.trim()
        when {
            r == null -> {
                pendingLearn = original
                pendingLearnAt = System.currentTimeMillis()
                finishWith("לא הצלחתי להבין. תגיד את זה במילים אחרות")
            }
            r.startsWith("CMD:") -> {
                val cmd = r.removePrefix("CMD:").trim()
                val say = Commands.handle(app, cmd)
                when {
                    say == Commands.UNKNOWN -> finishWith(Commands.UNKNOWN_SAY)
                    else -> {
                        Learn.add(original, cmd)
                        if (say != null) finishWith(say) else finishSilent(cmd)
                    }
                }
            }
            r.startsWith("ANSWER:") -> finishWith(r.removePrefix("ANSWER:").trim())
            else -> finishWith(r.take(300))
        }
    }

    private fun finishWith(say: String) {
        state.value = UiState.Info(say, iconHint)
        iconHint = null
        openSession(show = false)
        speak(say) { followUpOrClose() }
    }

    /** שיחה רציפה: אחרי תשובה ממשיכה להקשיב עוד כמה שניות לפקודה הבאה. */
    private fun followUpOrClose() {
        if (!Prefs.followUp || queue.any { !it.notice }) {
            closeSession()
            pump()
            return
        }
        state.value = UiState.Listening("עוד משהו?", null)
        listen { heard ->
            if (heard == null || Commands.isDone(heard)) {
                closeSession()
                pump()
            } else {
                runHeard(heard)
            }
        }
    }

    // =====================================================================
    // שיחה נכנסת: "דני מתקשר" → "תעני" / "תדחי"
    // =====================================================================
    fun incomingCall(name: String, remote: Boolean) {
        if (!Prefs.voiceCalls) return
        if (busy) {
            Voice.cancel(); listening = false; silence()
            closeSession()
        }
        busy = true
        current = emptyList()
        state.value = UiState.Listening("$name מתקשר", "אמור „תעני“ או „תדחי“")
        openSession(exclusive = true)
        speak("$name מתקשר") {
            listen { heard ->
                val op = when {
                    heard == null -> null
                    Commands.isAnswer(heard) -> "answer"
                    Commands.isReject(heard) -> "reject"
                    else -> null
                }
                if (op != null) {
                    if (remote) Link.send(Link.obj("callop", "op" to op)) else CallMonitor.op(app, op)
                }
                closeSession()
                pump()
            }
        }
    }

    private fun finishSilent(text: String) {
        state.value = UiState.Info(if (iconHint != null) text else "בוצע: $text", iconHint)
        iconHint = null
        handler.postDelayed({
            closeSession()
            pump()
        }, 1200)
    }

    // =====================================================================
    // מילת הפעלה (ניסיוני)
    // =====================================================================
    private val wakeRunnable = Runnable { wakeLoop() }

    fun scheduleWake(delay: Long) {
        handler.removeCallbacks(wakeRunnable)
        if (Prefs.wakeWord) handler.postDelayed(wakeRunnable, delay)
    }

    private fun wakeLoop() {
        if (Wake.configured()) return
        if (!Prefs.wakeWord || !DriveState.active.value || !DriveState.isSpeaker()) {
            scheduleWake(5000)
            return
        }
        if (busy || sessionOpen) {
            scheduleWake(2000)
            return
        }
        Voice.listen(app) { text ->
            if (busy || sessionOpen) return@listen
            val name = Prefs.assistantName.trim()
            val t = text?.trim()
            if (t != null && name.isNotEmpty() && t.startsWith(name)) {
                val rest = t.removePrefix(name).trim().trimStart(',', ' ')
                if (rest.isEmpty()) listenCommand() else runText(rest)
            } else {
                scheduleWake(300)
            }
        }
    }

    // =====================================================================
    // כפתורים במסך
    // =====================================================================
    fun uiSkip() {
        Voice.cancel(); listening = false; silence()
        next()
    }

    fun uiStop() {
        Voice.cancel(); listening = false; silence()
        queue.removeAll { !it.notice }
        closeSession()
        pump()
    }

    fun uiReply() {
        val m = current.lastOrNull { it.canReply } ?: return
        Voice.cancel(); listening = false; silence()
        listenForReply(m, explicit = true)
    }

    fun uiQuickReply(text: String) {
        val m = current.lastOrNull { it.canReply } ?: return
        Voice.cancel(); listening = false; silence()
        send(m, text)
    }

    fun uiLater() {
        val m = current.lastOrNull() ?: return
        Voice.cancel(); listening = false; silence()
        saveLater(m)
        speak("שמרתי לאחר כך") { next() }
    }

    fun uiSendNow() {
        val s = state.value as? UiState.ConfirmReply ?: return
        val m = current.lastOrNull { it.canReply } ?: return
        Voice.cancel(); listening = false; silence()
        send(m, s.reply)
    }

    fun uiCancelReply() {
        Voice.cancel(); listening = false; silence()
        speak("בוטל") { next() }
    }

    fun reset() {
        Voice.cancel(); listening = false; silence()
        queue.clear()
        closeSession()
        muted = false
        lastSenderKey = null
    }

    fun mediaStateForUi(): JSONObject? = Link.phoneMedia

    fun isActive() = busy || sessionOpen || listening
}
