package com.kolbaderech.app

import android.content.Context
import android.content.Intent

/** עצירת ניווט בוייז: קודם דרך כפתור בהתראה של וייז, ואם אין – לחיצה בתוך וייז דרך הנגישות. */
object WazeCtl {
    private const val WAZE = "com.waze"
    // "כיבוי" בהתראה של וייז = יציאה מלאה מוייז (עוצר גם את הניווט)
    private val stopWords = listOf(
        "כיבוי", "כבה", "turn off", "shut down", "quit", "יציאה", "exit",
        "עצור", "עצירה", "stop", "סיום", "סיים", "end", "ביטול", "cancel", "הפסק"
    )

    fun stop(ctx: Context): String {
        // 1) פעולה בהתראה הקבועה של וייז
        try {
            val l = NotifListener.instance
            val sbn = l?.activeNotifications?.firstOrNull { it.packageName == WAZE }
            val acts = sbn?.notification?.actions
            DLog.i("🗺️ כפתורים בהתראה של וייז: ${acts?.joinToString { it.title.toString() } ?: "אין התראה / אין גישה"}")
            val a = acts?.firstOrNull { act ->
                val t = act.title?.toString()?.lowercase() ?: ""
                stopWords.any { t.contains(it) }
            }
            if (a != null) {
                a.actionIntent.send()
                DLog.i("🗺️ נלחץ: ${a.title}")
                return "כיביתי את וייז"
            }
        } catch (e: Throwable) {
            DLog.e("waze notif", e)
        }
        // 2) בתוך וייז: פותחים ולוחצים "עצור" (לפעמים צריך קודם ללחוץ על פס זמן ההגעה)
        if (GateService.instance == null) return "כדי לעצור ניווט, צריך להפעיל לנוגה את הרשאת הנגישות"
        val i = ctx.packageManager.getLaunchIntentForPackage(WAZE) ?: return "וייז לא מותקן"
        val stopBtn = listOf("עצור", "Stop", "עצירה", "סיום הנסיעה", "End drive", "הפסק ניווט")
        val done: () -> Unit = { Out.say("עצרתי את הניווט") }
        GateService.armTap(WAZE, stopBtn, 5, goHome = false, done = done, contains = true)
        // אם הכפתור לא גלוי – לוחצים קודם על פס זמן ההגעה, ואז על "עצור"
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (GateService.tapPending()) {
                GateService.armTap(WAZE, listOf("הגעה", "ETA", "דק׳", "min", "ק\"מ", "km"), 5, goHome = false, contains = true, done = {
                    GateService.armTap(WAZE, stopBtn, 6, goHome = false, done = done, contains = true)
                })
            }
        }, 3000)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            "מנסה לעצור את הניווט"
        } catch (e: Throwable) {
            "לא הצלחתי לפתוח את וייז"
        }
    }

    private var lastLogged = ""

    /** כמה דקות נשארו לפי וייז (מההתראה של הניווט), ולאן. null אם אין ניווט. */
    fun eta(): Pair<Int, String>? {
        val l = NotifListener.instance ?: return null
        val sbn = try {
            l.activeNotifications?.firstOrNull { it.packageName == WAZE }
        } catch (e: Throwable) {
            null
        } ?: return null
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = listOfNotNull(
            ex.getCharSequence(android.app.Notification.EXTRA_TEXT),
            ex.getCharSequence(android.app.Notification.EXTRA_SUB_TEXT),
            ex.getCharSequence(android.app.Notification.EXTRA_BIG_TEXT)
        ).joinToString(" ")
        val all = "$title $text"
        if (all != lastLogged) {
            lastLogged = all
            DLog.i("🗺️ וייז: ${all.take(120)}")
        }
        // "12 דק׳", "12 min", "שעה ו-5 דק׳", או שעת הגעה "17:42"
        var mins: Int? = null
        Regex("(\\d+)\\s*(דק|min)").find(all)?.let { mins = it.groupValues[1].toInt() }
        Regex("(\\d+)\\s*(שע|hr|h )").find(all)?.let { h -> mins = (mins ?: 0) + h.groupValues[1].toInt() * 60 }
        if (mins == null) {
            Regex("\\b(\\d{1,2}):(\\d{2})\\b").find(all)?.let { m ->
                val cal = java.util.Calendar.getInstance()
                val now = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
                var at = m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt()
                if (at < now) at += 24 * 60
                mins = at - now
            }
        }
        return mins?.let { it to all }
    }
}
