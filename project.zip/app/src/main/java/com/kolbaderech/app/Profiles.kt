package com.kolbaderech.app

import android.content.Context
import android.content.Intent
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.os.Build
import android.os.Process
import android.os.UserHandle
import android.os.UserManager
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

/** אפליקציה שאפשר לפתוח, באחד הפרופילים (ראשי / עבודה / תיקייה מאובטחת / שכפול). */
data class ProfApp(
    val label: String,
    val pkg: String,
    /** המספר הסידורי של הפרופיל (נשמר בהגדרות). */
    val user: Long,
    val profile: String,
    val main: Boolean,
    val info: LauncherActivityInfo?
)

/** פתיחת אפליקציות בכל הפרופילים שהמכשיר מראה לנו (LauncherApps). */
object Profiles {
    data class Launch(val error: String?, val otherProfile: Boolean)

    private fun la(c: Context) = c.getSystemService(Context.LAUNCHER_APPS_SERVICE) as? LauncherApps
    private fun um(c: Context) = c.getSystemService(Context.USER_SERVICE) as? UserManager

    fun serial(c: Context, h: UserHandle): Long = try {
        um(c)?.getSerialNumberForUser(h) ?: -1L
    } catch (e: Exception) {
        -1L
    }

    /** הפרופיל לפי מספר סידורי; null = הפרופיל הנוכחי (או שלא קיים במכשיר הזה). */
    fun handle(c: Context, serial: Long): UserHandle? {
        if (serial < 0) return null
        return try {
            um(c)?.getUserForSerialNumber(serial)
        } catch (e: Exception) {
            null
        }
    }

    fun isCurrent(c: Context, serial: Long): Boolean {
        val h = handle(c, serial) ?: return true
        return h == Process.myUserHandle()
    }

    /** שם ידידותי לפרופיל. */
    fun profileName(c: Context, h: UserHandle?): String {
        if (h == null || h == Process.myUserHandle()) return "ראשי"
        val badged = try {
            c.packageManager.getUserBadgedLabel("§", h)?.toString() != "§"
        } catch (e: Exception) {
            false
        }
        return if (badged) "עבודה / תיקייה מאובטחת" else "פרופיל ${serial(c, h)}"
    }

    fun label(c: Context, serial: Long): String = profileName(c, handle(c, serial))

    /** כל האפליקציות שאפשר לפתוח, בכל הפרופילים (pkg = רק החבילה הזו). */
    fun apps(c: Context, pkg: String? = null): List<ProfApp> {
        val l = la(c)
        val me = Process.myUserHandle()
        val profiles = try {
            l?.profiles?.takeIf { it.isNotEmpty() } ?: listOf(me)
        } catch (e: Exception) {
            DLog.i("🚧 אין גישה לרשימת הפרופילים: ${e.javaClass.simpleName}")
            listOf(me)
        }
        val out = ArrayList<ProfApp>()
        for (h in profiles) {
            val name = profileName(c, h)
            val ser = if (h == me) -1L else serial(c, h)
            val list = try {
                l?.getActivityList(pkg, h) ?: emptyList()
            } catch (e: Exception) {
                DLog.i("🚧 לא הצלחתי לקרוא אפליקציות בפרופיל $name: ${e.javaClass.simpleName}")
                emptyList()
            }
            list.distinctBy { it.componentName.packageName }.forEach { a ->
                val lbl = try {
                    a.label?.toString() ?: a.componentName.packageName
                } catch (e: Exception) {
                    a.componentName.packageName
                }
                out.add(ProfApp(lbl, a.componentName.packageName, ser, name, h == me, a))
            }
        }
        // בפרופיל הנוכחי, אם LauncherApps לא החזיר כלום – הדרך הרגילה
        if (out.none { it.main } && pkg == null) {
            Perms.launcherApps(c).forEach { (lbl, p) -> out.add(ProfApp(lbl, p, -1L, "ראשי", true, null)) }
        }
        return out.sortedWith(compareBy({ !isGateLike(it) }, { it.label.lowercase() }, { !it.main }))
    }

    private fun isGateLike(a: ProfApp): Boolean {
        val s = (a.pkg + " " + a.label).lowercase()
        return listOf("gate", "bluegate", "שער", "חניון", "parking").any { s.contains(it) }
    }

    /** תיאור קצר: „PalGate · עבודה / תיקייה מאובטחת“. */
    fun describe(c: Context, pkg: String, serial: Long): String {
        if (pkg.isBlank()) return "לא נבחרה"
        val name = Perms.appLabel(c, pkg)
        return if (isCurrent(c, serial)) name else "$name · ${label(c, serial)}"
    }

    private val icons = HashMap<String, ImageBitmap?>()

    /** אייקון עם תג הפרופיל (המזוודה הקטנה וכו'). */
    fun icon(c: Context, pkg: String, serial: Long): ImageBitmap? {
        if (pkg.isBlank()) return null
        return icons.getOrPut("$pkg/$serial") {
            try {
                val h = handle(c, serial)
                val d = if (h == null || h == Process.myUserHandle()) c.packageManager.getApplicationIcon(pkg)
                else la(c)?.getActivityList(pkg, h)?.firstOrNull()?.getBadgedIcon(0)
                    ?: c.packageManager.getUserBadgedIcon(c.packageManager.getApplicationIcon(pkg), h)
                d.toBitmap(96, 96).asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }

    /** פותח את האפליקציה בפרופיל שנבחר. error = מה להגיד אם לא הצליח. */
    fun launch(c: Context, pkg: String, serial: Long): Launch {
        val h = handle(c, serial)
        if (serial >= 0 && h == null) DLog.i("🚧 הפרופיל $serial לא קיים במכשיר הזה – פותחת בפרופיל הראשי")
        if (h == null || h == Process.myUserHandle()) {
            val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return Launch("אפליקציית השער לא מותקנת", false)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            return try {
                c.startActivity(i)
                Launch(null, false)
            } catch (e: Exception) {
                DLog.i("🚧 פתיחת $pkg נכשלה: ${e.javaClass.simpleName}: ${e.message}")
                Launch("לא הצלחתי לפתוח את אפליקציית השער", false)
            }
        }
        val name = profileName(c, h)
        return try {
            val m = um(c)
            if (m != null && Build.VERSION.SDK_INT >= 24 && m.isQuietModeEnabled(h)) {
                DLog.i("🚧 הפרופיל $name כבוי (מושהה)")
                return Launch("הפרופיל $name כבוי כרגע. צריך להפעיל אותו כדי לפתוח את השער", true)
            }
            val l = la(c) ?: return Launch("לא הצלחתי לפתוח את אפליקציית השער", true)
            val act = l.getActivityList(pkg, h).firstOrNull()
                ?: return Launch("אפליקציית השער לא מותקנת בפרופיל $name", true)
            l.startMainActivity(act.componentName, h, null, null)
            DLog.i("🚧 נפתחה $pkg בפרופיל $name")
            Launch(null, true)
        } catch (e: Exception) {
            DLog.i("🚧 פתיחת $pkg בפרופיל $name נכשלה: ${e.javaClass.simpleName}: ${e.message}")
            Launch("לא הצלחתי לפתוח את אפליקציית השער בפרופיל $name", true)
        }
    }
}
