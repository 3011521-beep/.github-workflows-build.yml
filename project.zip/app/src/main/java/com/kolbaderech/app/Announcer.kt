package com.kolbaderech.app

import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale
import java.util.UUID

/**
 * הלב של האפליקציה: תור הודעות, הקראה, הנמכת מוזיקה, תגובות ופקודות.
 * כל הפונקציות רצות על ה-Main thread.
 */
object Announcer {
    private lateinit var app: Context
    private val handler = Handler(Looper.getMainLooper())

    val state = MutableStateFlow<UiState>(UiState.Idle)
    val history = MutableStateFlow<List<HistoryItem>>(emptyList())

    var muted = false

    // ---------- TTS ----------
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var afterInit: (() -> Unit)? = null
    private var curId: String? = null
    private var curText: String? = null
    private var curThen: (() -> Unit)? = null
    private var interrupted = false
    private var listening = false

    // ---------- תור ----------
    private val queue = ArrayDeque<Msg>()
    private var busy = false
    private var wasInCall = false
    private var current: List<Msg> = emptyList()
    private var lastBatch: List<Msg> = emptyList()
    private var lastSenderKey: String? = null
    private var lastSenderTime = 0L
    private var sessionOpen = false

    // ---------- אודיו ----------
    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()
    private var focusReq: AudioFocusRequest? = null
    private val am: AudioManager get() = app.getSystemService(AudioManager::class.java)

    fun init(c: Context) {
        app = c.applicationContext
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("he", "IL")
                tts?.setAudioAttributes(attrs)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        handler.post { onUtteranceEnd(utteranceId) }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        handler.post { onUtteranceEnd(utteranceId) }
                    }
                    override fun onError(utteranceId: String?, errorCode: Int) {
                        handler.post { onUtteranceEnd(utteranceId) }
                    }
                })
                ttsReady = true
                afterInit?.let { afterInit = null; it() }
            }
        }
    }

    // =====================================================================
    // דיבור
    // =====================================================================
    private fun speak(text: String, then: () -> Unit) {
        if (!ttsReady) {
            afterInit = { speak(text, then) }
            return
        }
        val id = UUID.randomUUID().toString()
        curId = id
        curText = text
        curThen = then
        interrupted = false
        tts?.setSpeechRate(Prefs.speechRate)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun onUtteranceEnd(id: String?) {
        if (id == null || id != curId || interrupted) return
        val then = curThen
        curId = null; curThen = null; curText = null
        then?.invoke()
    }

    private fun silence() {
        curId = null; curThen = null; curText = null
        interrupted = false
        tts?.stop()
    }

    fun sayShort(text: String) {
        if (busy) return
        busy = true
        requestFocus()
        speak(text) {
            busy = false
            abandonFocus()
            pump()
        }
    }

    fun testVoice() = sayShort("שלום, ככה אני נשמעת. הודעה מדני בוואטסאפ: אני מגיע בעוד עשר דקות")

    // =====================================================================
    // פוקוס אודיו: המוזיקה יורדת בזמן דיבור וחוזרת לבד
    // =====================================================================
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT, AudioManager.AUDIOFOCUS_LOSS -> {
                // למשל וייז אומר "פנה ימינה": עוצרים ומחכים
                if (!listening && curId != null) {
                    interrupted = true
                    tts?.stop()
                    if (change == AudioManager.AUDIOFOCUS_LOSS) {
                        handler.postDelayed({ resumeInterrupted(true) }, 6000)
                    }
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> handler.postDelayed({ resumeInterrupted(false) }, 400)
        }
    }

    private fun resumeInterrupted(refocus: Boolean) {
        if (!interrupted) return
        val text = curText
        val then = curThen
        interrupted = false
        if (refocus) requestFocus()
        if (text != null && then != null) speak(text, then)
    }

    private fun requestFocus(exclusive: Boolean = false) {
        abandonFocus()
        val gain = if (Prefs.duck && !exclusive) AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
        else AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
        val req = AudioFocusRequest.Builder(gain)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(focusListener, handler)
            .build()
        focusReq = req
        try {
            am.requestAudioFocus(req)
        } catch (e: Exception) {
        }
    }

    private fun abandonFocus() {
        focusReq?.let {
            try {
                am.abandonAudioFocusRequest(it)
            } catch (e: Exception) {
            }
        }
        focusReq = null
    }

    private fun inCall(): Boolean {
        val m = am.mode
        return m == AudioManager.MODE_IN_CALL || m == AudioManager.MODE_IN_COMMUNICATION ||
            m == AudioManager.MODE_RINGTONE
    }

    // =====================================================================
    // מסך
    // =====================================================================
    private fun openSession(exclusive: Boolean = false) {
        if (!sessionOpen) {
            sessionOpen = true
            requestFocus(exclusive)
        }
        showScreen()
    }

    private fun closeSession() {
        sessionOpen = false
        busy = false
        current = emptyList()
        abandonFocus()
        state.value = UiState.Idle
    }

    private fun showScreen() {
        try {
            app.startActivity(
                Intent(app, ReadingActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (e: Exception) {
        }
    }

    // =====================================================================
    // תור הודעות
    // =====================================================================
    fun enqueue(m: Msg, force: Boolean = false) {
        if (!force && (!DriveState.active.value || !Prefs.autoRead || muted)) return
        if (m.urgent) queue.addFirst(m) else queue.addLast(m)
        pump()
    }

    fun testMessage() {
        enqueue(
            Msg("test", "וואטסאפ", "דני", "זו הודעת בדיקה. אני מגיע בעוד עשר דקות, תשמור לי מקום", "",
                false, null, false),
            force = true
        )
    }

    private val pumpRunnable = Runnable { pump() }

    private fun pump() {
        if (busy) return
        if (queue.isEmpty()) {
            if (sessionOpen) closeSession()
            return
        }
        if (Prefs.silentInCalls && inCall()) {
            // בזמן שיחה: שותקים ושומרים הכל בתור
            wasInCall = true
            if (sessionOpen) {
                sessionOpen = false
                abandonFocus()
                state.value = UiState.Idle
            }
            handler.removeCallbacks(pumpRunnable)
            handler.postDelayed(pumpRunnable, 2000)
            return
        }
        if (wasInCall) {
            wasInCall = false
            busy = true
            handler.postDelayed({
                busy = false
                if (inCall()) {
                    pump()
                } else if (queue.size >= 2) {
                    busy = true
                    openSession()
                    speak(callSummary()) {
                        busy = false
                        readNext()
                    }
                } else {
                    pump()
                }
            }, 2000)
            return
        }
        readNext()
    }

    private fun callSummary(): String {
        val counts = queue.groupingBy { it.sender }.eachCount().entries.take(4)
        val parts = counts.map { (s, n) -> if (n == 1) "אחת מ-$s" else "$n מ-$s" }
        return "בזמן השיחה קיבלת ${queue.size} הודעות: ${parts.joinToString(", ")}"
    }

    private fun spokenBody(m: Msg): String {
        var t = if (m.isEmail) {
            if (Prefs.shortEmails || m.body.isBlank()) "נושא: ${m.text}"
            else "נושא: ${m.text}. ${m.body}"
        } else m.text
        t = Emoji.toWords(t)
        if (t.length > 350) t = t.take(350) + "… ההודעה ממשיכה, אפשר לקרוא אותה בטלפון"
        return t
    }

    private fun readNext() {
        val first = queue.removeFirstOrNull()
        if (first == null) {
            closeSession()
            return
        }
        val batch = mutableListOf(first)
        if (Prefs.groupMessages) {
            while (true) {
                val n = queue.firstOrNull() ?: break
                if (n.pkg == first.pkg && n.sender == first.sender) batch.add(queue.removeFirst()) else break
            }
        }
        busy = true
        current = batch
        lastBatch = batch
        val lines = batch.map { spokenBody(it) }
        val now = System.currentTimeMillis()
        val key = first.pkg + first.sender
        val continued = key == lastSenderKey && now - lastSenderTime < 90_000
        lastSenderKey = key
        lastSenderTime = now

        val intro = when {
            continued -> "ועוד מ-${first.sender}"
            first.isEmail && batch.size > 1 -> "${batch.size} מיילים מ-${first.sender}"
            first.isEmail -> "מייל מ-${first.sender}"
            batch.size > 1 -> "${batch.size} הודעות מ-${first.sender} ב${first.app}"
            else -> "הודעה מ-${first.sender} ב${first.app}"
        }
        val appLabel = if (batch.size > 1) "${first.app} · ${batch.size} הודעות" else first.app
        state.value = UiState.Reading(
            first.sender, appLabel, lines,
            Prefs.voiceReply && batch.last().reply != null, queue.size
        )
        addHistory(first.sender, first.app, lines.joinToString(" · "))
        openSession()
        speak("$intro. " + lines.joinToString(". ")) { afterRead() }
    }

    private fun addHistory(sender: String, app: String, text: String) {
        history.value = (listOf(HistoryItem(sender, app, text, System.currentTimeMillis())) + history.value).take(40)
    }

    private fun afterRead() {
        val last = current.lastOrNull()
        if (last != null && Prefs.voiceReply && last.reply != null && queue.none { it.urgent }) {
            listenForReply(last, explicit = false)
        } else {
            next()
        }
    }

    private fun next() {
        busy = false
        current = emptyList()
        pump()
    }

    fun repeatLast(): Boolean {
        if (lastBatch.isEmpty()) return false
        lastSenderKey = null
        lastBatch.reversed().forEach { queue.addFirst(it) }
        return true
    }

    // =====================================================================
    // הקשבה ותגובות
    // =====================================================================
    private fun listen(onResult: (String?) -> Unit) {
        listening = true
        Voice.beep()
        handler.postDelayed({
            Voice.listen(app) { text ->
                listening = false
                onResult(text)
            }
        }, 250)
    }

    private fun listenForReply(m: Msg, explicit: Boolean) {
        state.value = UiState.Listening(
            if (explicit) "מה לענות ל-${m.sender}?" else "אפשר לומר „תעני לו…“", null
        )
        listen { heard ->
            if (heard == null) {
                next()
                return@listen
            }
            state.value = UiState.Listening("שמעתי", heard)
            val reply = if (explicit) Commands.replyFromAnything(heard) else Commands.extractReply(heard)
            when {
                reply != null -> confirmReply(m, reply)
                Commands.isStop(heard) -> uiStop()
                else -> next()
            }
        }
    }

    private fun confirmReply(m: Msg, text: String) {
        val original = current.lastOrNull()?.let { spokenBody(it) } ?: ""
        state.value = UiState.ConfirmReply(m.sender, m.app, original, text, Prefs.autoSend)
        val proceed: () -> Unit = {
            listen { heard ->
                val change = heard?.let { Commands.changeTo(it) }
                when {
                    heard != null && Commands.isCancel(heard) -> speak("בוטל") { next() }
                    change != null -> confirmReply(m, change)
                    Prefs.autoSend -> send(m, text)
                    heard != null && Commands.isYes(heard) -> send(m, text)
                    else -> speak("לא נשלח") { next() }
                }
            }
        }
        val say = when {
            Prefs.readBack -> "שולחת ל-${m.sender}: $text"
            !Prefs.autoSend -> "לשלוח?"
            else -> ""
        }
        if (say.isNotEmpty()) speak(say) { proceed() } else proceed()
    }

    private fun send(m: Msg, text: String) {
        val ok = try {
            val action = m.reply ?: throw IllegalStateException()
            val inputs = action.remoteInputs ?: throw IllegalStateException()
            val bundle = Bundle()
            inputs.forEach { bundle.putCharSequence(it.resultKey, text) }
            val intent = Intent()
            RemoteInput.addResultsToIntent(inputs, intent, bundle)
            action.actionIntent.send(app, 0, intent)
            true
        } catch (e: Exception) {
            false
        }
        state.value = UiState.Info(if (ok) "נשלח ל-${m.sender}" else "לא הצלחתי לשלוח")
        speak(if (ok) "נשלח" else "לא הצלחתי לשלוח") { next() }
    }

    // =====================================================================
    // פקודות קוליות (כפתור המיקרופון)
    // =====================================================================
    fun listenCommand() {
        if (busy) {
            Voice.cancel(); listening = false; silence()
            queue.clear()
            closeSession()
        }
        busy = true
        current = emptyList()
        state.value = UiState.Listening("מקשיבה…", null)
        openSession(exclusive = true)
        listen { heard ->
            if (heard == null) {
                closeSession()
                pump()
                return@listen
            }
            state.value = UiState.Listening("שמעתי", heard)
            // משחררים את המוזיקה לפני הפעולה, כדי שנגן יוכל לקחת פיקוד
            abandonFocus()
            sessionOpen = false
            handler.postDelayed({
                val say = Commands.handle(app, heard)
                if (say != null) {
                    state.value = UiState.Info(say)
                    openSession()
                    speak(say) {
                        closeSession()
                        pump()
                    }
                } else {
                    state.value = UiState.Info("בוצע: $heard")
                    handler.postDelayed({
                        closeSession()
                        pump()
                    }, 1200)
                }
            }, 300)
        }
    }

    // =====================================================================
    // כפתורים במסך
    // =====================================================================
    fun uiSkip() {
        Voice.cancel(); listening = false; silence()
        next()
    }

    fun uiStop() {
        Voice.cancel(); listening = false; silence()
        queue.clear()
        closeSession()
    }

    fun uiReply() {
        val m = current.lastOrNull { it.reply != null } ?: return
        Voice.cancel(); listening = false; silence()
        listenForReply(m, explicit = true)
    }

    fun uiSendNow() {
        val s = state.value as? UiState.ConfirmReply ?: return
        val m = current.lastOrNull { it.reply != null } ?: return
        Voice.cancel(); listening = false; silence()
        send(m, s.reply)
    }

    fun uiCancelReply() {
        Voice.cancel(); listening = false; silence()
        speak("בוטל") { next() }
    }

    fun reset() {
        uiStop()
        muted = false
        lastSenderKey = null
    }
}
