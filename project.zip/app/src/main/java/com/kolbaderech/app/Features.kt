package com.kolbaderech.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** כל מה שקורה סביב הנסיעה: מיקום, שער, מהירות, הפסקות, סיכומים, חניה ועוד. */
object Features {
    private val handler = Handler(Looper.getMainLooper())
    private var lm: LocationManager? = null
    private var listener: LocationListener? = null
    private var lastLoc: Location? = null
    private var tripMeters = 0.0
    private var lastGateDist = Double.MAX_VALUE
    private var lastGateOpen = 0L
    private var lastSpeedAlert = 0L
    private var baseVolume = -1
    private var lastStep = 0
    private var arrivalSent = false
    private var batteryWarned = false
    private var missedSince = 0L
    var sessionArrivalContact: String? = null
    private var approachCount = 0

    /** דקות להגעה לפי וייז (מגיע ממסך הרכב, או מהוייז בטלפון). */
    @Volatile var wazeEtaMins: Int? = null
    private var wazeEtaAt = 0L

    fun setWazeEta(mins: Int?) {
        wazeEtaMins = mins
        wazeEtaAt = System.currentTimeMillis()
    }

    /** במסך הרכב: שולחים לטלפון כל חצי דקה כמה זמן נשאר לפי וייז. */
    private val etaTicker: Runnable = object : Runnable {
        override fun run() {
            if (!DriveState.active.value) return
            val e = CrashGuard.safe(null) { WazeCtl.eta() }
            if (Prefs.isCar) {
                if (Link.connected.value) Link.send(Link.obj("eta", "m" to (e?.first ?: -1)))
            } else {
                setWazeEta(e?.first)
            }
            handler.postDelayed(this, 30_000)
        }
    }
    private var notifMuted = false

    /** פותח את וייז במסך הרכב לפי השעה: בבוקר מהבית לעבודה, אחה״צ הביתה. */
    private fun autoWaze(app: Context) {
        if (!DriveState.active.value) return
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val weekend = dow == Calendar.FRIDAY || dow == Calendar.SATURDAY
        val home = homeLatLng()
        val lat = lastLoc?.latitude ?: Store.lastLat
        val lng = lastLoc?.longitude ?: Store.lastLng
        var nearHome = false
        if (home != null && (lat != 0.0 || lng != 0.0)) {
            val r = FloatArray(1)
            Location.distanceBetween(lat, lng, home.first, home.second, r)
            nearHome = r[0] < 400
        }
        when {
            nearHome && hour in 5..11 && !weekend -> Nav.work(app)
            !nearHome && hour >= 15 -> Nav.home(app)
            else -> Nav.openWaze(app)
        }
    }

    private fun granted(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------------
    private var tripStart: Location? = null

    fun onDriveStart(app: Context) {
        approachCount = 0
        wazeEtaMins = null
        handler.removeCallbacks(etaTicker)
        handler.postDelayed(etaTicker, 20_000)
        tripMeters = 0.0
        lastLoc = null
        tripStart = null
        Prefs.pendingTripType = ""
        arrivalSent = false
        batteryWarned = false
        lastGateDist = Double.MAX_VALUE
        missedSince = System.currentTimeMillis()
        NotifListener.onDriveStart()
        startLocation(app)

        val am = app.getSystemService(AudioManager::class.java)
        baseVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        lastStep = 0

        handler.removeCallbacks(breakRunnable)
        if (Prefs.breakReminder) handler.postDelayed(breakRunnable, TimeUnit.HOURS.toMillis(2))

        if (Prefs.isCar && Prefs.autoWaze) handler.postDelayed({ autoWaze(app) }, 8000)
        if (!Prefs.isCar && Prefs.muteNotifications) {
            try {
                am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0)
                notifMuted = true
            } catch (e: Exception) {
            }
        }
        if (!Prefs.isCar) {
            CallMonitor.register(app)
            handler.postDelayed({ startBrief(app) }, 5000)
            if (Prefs.autoResumeMusic) handler.postDelayed({ Media.play(app) }, 7000)
            handler.removeCallbacks(periodic)
            periodicApp = app
            handler.postDelayed(periodic, 20_000)
        }
    }

    fun onDriveEnd(app: Context) {
        stopLocation()
        handler.removeCallbacks(breakRunnable)
        handler.removeCallbacks(periodic)
        Radio.stop(app)
        if (Prefs.volumeBySpeed && baseVolume >= 0) {
            try {
                app.getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_MUSIC, baseVolume, 0)
            } catch (e: Exception) {
            }
        }
        if (notifMuted) {
            try {
                app.getSystemService(AudioManager::class.java)
                    .adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_UNMUTE, 0)
            } catch (e: Exception) {
            }
            notifMuted = false
        }
        if (Prefs.isCar) return

        // יומן נסיעות (כולל מוצא, יעד וסוג: עסקי / פרטי)
        val start = DriveState.startedAt
        val end = System.currentTimeMillis()
        Store.inc("gps_m", tripMeters.toLong())
        if (end - start > 60_000 && tripMeters > 300) {
            val id = "t$end"
            val s0 = tripStart
            val e0 = lastLoc
            val type = Prefs.pendingTripType.ifBlank { guessType(s0, e0) }
            Store.add(
                Store.TRIPS,
                JSONObject().put("id", id).put("start", start).put("end", end).put("km", tripMeters / 1000.0)
                    .put("slat", s0?.latitude ?: 0.0).put("slng", s0?.longitude ?: 0.0)
                    .put("elat", e0?.latitude ?: 0.0).put("elng", e0?.longitude ?: 0.0)
                    .put("type", type).put("odo", CarBook.odometer() ?: -1.0),
                2000
            )
            Store.inc("drive_minutes", (end - start) / 60_000)
            if (s0 != null || e0 != null) {
                Thread {
                    val from = s0?.let { geocode(app, it) } ?: ""
                    val to = e0?.let { geocode(app, it) } ?: ""
                    Store.update(Store.TRIPS, id) { it.put("from", from).put("to", to) }
                }.start()
            }
        }
        Prefs.pendingTripType = ""
        // חניה
        val lat = Store.lastLat
        val lng = Store.lastLng
        if (lat != 0.0 || lng != 0.0) {
            Store.parking = JSONObject().put("lat", lat).put("lng", lng).put("time", end)
                .put("note", Store.pendingParkingNote)
            Store.pendingParkingNote = ""
        }
        // תזכורת מושב אחורי
        if (Prefs.backSeat) {
            Notify.alert(app, 501, "בדיקת מושב אחורי", "בדקת שלא שכחת אף אחד או שום דבר במושב האחורי?")
            Announcer.notice("רגע לפני שאתה יוצא: בדקת שלא שכחת אף אחד במושב האחורי?")
        }
        // הודעות ששמרת לאחר כך
        val later = Store.list(Store.LATER)
        if (later.isNotEmpty()) {
            Notify.alert(app, 502, "שמרת ${later.size} הודעות לאחר כך", later.joinToString("\n") { it.optString("text") })
        }
        sessionArrivalContact = null
    }

    // ------------------------------------------------------------------
    // סיכום בכניסה לרכב, בוקר טוב, מזג אוויר ותזכורות לרכב (בטלפון)
    // ------------------------------------------------------------------
    private fun startBrief(app: Context) {
        Thread {
            val parts = ArrayList<String>()
            try {
                val now = Calendar.getInstance()
                val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now.time)
                val lat = Store.lastLat
                val lng = Store.lastLng
                if (Prefs.morningBrief && Prefs.lastBriefDay != today && now.get(Calendar.HOUR_OF_DAY) in 4..11) {
                    Prefs.lastBriefDay = today
                    parts += "בוקר טוב"
                    Net.weather(lat, lng)?.let { parts += it }
                    CalendarHelper.firstToday(app)?.let { parts += it }
                } else if (Prefs.rainAlert && Net.rainSoon(lat, lng)) {
                    parts += "צפוי גשם בשעות הקרובות, סע בזהירות"
                }
                if (Prefs.startSummary) NotifListener.unreadSummary()?.let { parts += it }
                carReminders().let { parts.addAll(it) }
                CarBook.alert()?.let { parts += it }
            } catch (e: Exception) {
            }
            if (parts.isNotEmpty()) handler.post { Out.say(parts.joinToString(". ")) }
        }.start()
    }

    private fun carReminders(): List<String> {
        val out = ArrayList<String>()
        val fmt = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        fun check(dateStr: String, what: String) {
            if (dateStr.isBlank()) return
            val d: Date = try {
                fmt.parse(dateStr.trim())
            } catch (e: Exception) {
                null
            } ?: return
            val days = TimeUnit.MILLISECONDS.toDays(d.time - System.currentTimeMillis())
            when {
                days < 0 -> out += "שים לב, תאריך ה$what עבר"
                days <= 14 -> out += "ה$what של הרכב בעוד $days ימים"
            }
        }
        check(Prefs.testDate, "טסט")
        check(Prefs.insuranceDate, "ביטוח")
        check(Prefs.serviceDate, "טיפול")
        return out
    }

    // ------------------------------------------------------------------
    // משימות תקופתיות בטלפון: סוללה ושיחות שלא נענו
    // ------------------------------------------------------------------
    private var periodicApp: Context? = null
    private val periodic: Runnable = object : Runnable {
        override fun run() {
            val app = periodicApp ?: return
            if (!DriveState.active.value) return
            // סוללה
            try {
                val bm = app.getSystemService(BatteryManager::class.java)
                val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                if (level in 1..15 && !bm.isCharging && !batteryWarned) {
                    batteryWarned = true
                    Out.say("הסוללה של הטלפון ב-$level אחוז, כדאי לחבר מטען")
                }
            } catch (e: Exception) {
            }
            // שיחות שלא נענו
            val missed = Contacts.missedSince(app, missedSince)
            if (missed.isNotEmpty()) {
                missedSince = System.currentTimeMillis()
                val names = missed.map { it.first }.distinct()
                Out.say(
                    if (missed.size == 1) "שיחה שלא נענתה מ-${names[0]}"
                    else "${missed.size} שיחות שלא נענו: ${names.joinToString(", ")}"
                )
                if (Prefs.missedCallSms) missed.map { it.second }.distinct().forEach {
                    Contacts.sms(app, it, Prefs.autoReplyText)
                }
            }
            handler.postDelayed(this, 20_000)
        }
    }

    private val breakRunnable = Runnable {
        if (DriveState.active.value && DriveState.isSpeaker()) {
            Announcer.notice("אתה נוהג כבר שעתיים. כדאי לעצור להפסקה קצרה ולשתות משהו")
        }
        scheduleBreakAgain()
    }

    private fun scheduleBreakAgain() {
        if (DriveState.active.value && Prefs.breakReminder) {
            handler.postDelayed(breakRunnable, TimeUnit.HOURS.toMillis(1))
        }
    }

    // ------------------------------------------------------------------
    // מיקום
    // ------------------------------------------------------------------
    @SuppressLint("MissingPermission")
    private fun startLocation(app: Context) {
        stopLocation()
        if (!granted(app, Manifest.permission.ACCESS_FINE_LOCATION)) return
        val m = app.getSystemService(LocationManager::class.java) ?: return
        // באנדרואיד 10 ומטה כל הפונקציות כאן חובה (אחרת קריסה כשה-GPS נכבה)
        val l = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                CrashGuard.safe(Unit) { onLocation(app, loc) }
            }
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
        }
        lm = m
        listener = l
        try {
            m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 5f, l, Looper.getMainLooper())
        } catch (e: Exception) {
        }
        try {
            m.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000L, 30f, l, Looper.getMainLooper())
        } catch (e: Exception) {
        }
    }

    private fun stopLocation() {
        val l = listener
        if (l != null) {
            try {
                lm?.removeUpdates(l)
            } catch (e: Exception) {
            }
        }
        listener = null
    }

    private fun onLocation(app: Context, loc: Location) {
        lastLoc?.let { prev ->
            val d = prev.distanceTo(loc)
            if (d < 500) tripMeters += d
        }
        lastLoc = loc
        if (tripStart == null && loc.accuracy < 100) tripStart = loc
        Store.lastLat = loc.latitude
        Store.lastLng = loc.longitude
        val kmh = if (loc.hasSpeed()) loc.speed * 3.6 else 0.0

        if (DriveState.isSpeaker()) {
            speedAlert(kmh)
            volumeBySpeed(app, kmh)
        }
        if (!Prefs.isCar) {
            gatesCheck(app, loc, kmh)
            homeChecks(app, loc, kmh)
        }
    }

    private fun speedAlert(kmh: Double) {
        if (!Prefs.speedAlert) return
        val now = System.currentTimeMillis()
        if (kmh > Prefs.speedLimit && now - lastSpeedAlert > 120_000) {
            lastSpeedAlert = now
            Announcer.notice("שים לב, אתה נוסע ${kmh.toInt()} קמ״ש")
        }
    }

    private fun volumeBySpeed(app: Context, kmh: Double) {
        if (!Prefs.volumeBySpeed || baseVolume < 0) return
        val step = when {
            kmh > 90 -> 2
            kmh > 60 -> 1
            else -> 0
        }
        if (step == lastStep) return
        lastStep = step
        try {
            val am = app.getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (baseVolume + step).coerceAtMost(max), 0)
        } catch (e: Exception) {
        }
    }

    /** עסקי אם הנסיעה התחילה או נגמרה ליד מקום העבודה. */
    private fun guessType(a: Location?, b: Location?): String {
        val lat = Prefs.workLat.toDoubleOrNull() ?: return "private"
        val lng = Prefs.workLng.toDoubleOrNull() ?: return "private"
        val near = listOfNotNull(a, b).any { distanceTo(it, lat, lng) < 600 }
        return if (near) "business" else "private"
    }

    @Suppress("DEPRECATION")
    private fun geocode(app: Context, l: Location): String = try {
        if (!android.location.Geocoder.isPresent()) "" else {
            val list = android.location.Geocoder(app, Locale("he")).getFromLocation(l.latitude, l.longitude, 1)
            val a = list?.firstOrNull()
            if (a == null) "" else listOfNotNull(
                listOfNotNull(a.thoroughfare, a.subThoroughfare).joinToString(" ").ifBlank { null },
                a.locality
            ).joinToString(", ")
        }
    } catch (e: Exception) {
        ""
    }

    private fun homeLatLng(): Pair<Double, Double>? {
        val gates = Gates.all().filter { it.lat != 0.0 }
        val home = gates.firstOrNull { it.name.contains("בית") } ?: gates.firstOrNull()
        if (home != null) return home.lat to home.lng
        val lat = Prefs.gateLat.toDoubleOrNull() ?: return null
        val lng = Prefs.gateLng.toDoubleOrNull() ?: return null
        return lat to lng
    }

    private val gateDist = HashMap<String, Double>()
    private val gateOpened = HashMap<String, Long>()

    /** פתיחה אוטומטית של השער הנכון כשמתקרבים אליו. */
    private fun gatesCheck(app: Context, loc: Location, kmh: Double) {
        if (!Prefs.gateEnabled) return
        val now = System.currentTimeMillis()
        if ((now - DriveState.startedAt) / 60_000 < 2) return
        for (g in Gates.all()) {
            if (!g.auto || g.lat == 0.0) continue
            val d = distanceTo(loc, g.lat, g.lng)
            val prev = gateDist[g.id] ?: Double.MAX_VALUE
            gateDist[g.id] = d
            val approaching = d < prev - 3
            if (d <= g.radius && approaching && kmh > 3 && now - (gateOpened[g.id] ?: 0L) > 5 * 60_000) {
                gateOpened[g.id] = now
                Out.say(Gate.open(app, g))
                break
            }
        }
    }

    private fun distanceTo(loc: Location, lat: Double, lng: Double): Double {
        val r = FloatArray(1)
        Location.distanceBetween(loc.latitude, loc.longitude, lat, lng, r)
        return r[0].toDouble()
    }

    private fun homeChecks(app: Context, loc: Location, kmh: Double) {
        val home = homeLatLng() ?: return
        val d = distanceTo(loc, home.first, home.second)
        val approaching = d < lastGateDist - 3
        lastGateDist = d
        val now = System.currentTimeMillis()
        val drivingMinutes = (now - DriveState.startedAt) / 60_000


        // הודעת הגעה – רק כשבאמת מתקרבים הביתה (לא כשיוצאים)
        val startD = tripStart?.let { distanceTo(it, home.first, home.second) } ?: 0.0
        if (approaching) approachCount++ else approachCount = 0
        val wazeMins = wazeEtaMins
        val byWaze = wazeMins != null && wazeMins <= Prefs.arrivalMinutes && d < 15_000 && startD > 1500
        val byDistance = wazeMins == null && startD > 2500 && d < 2000 && approachCount >= 4
        if (!arrivalSent && drivingMinutes >= 3 && (byWaze || byDistance)) {
            val contact = sessionArrivalContact ?: if (Prefs.arrivalEnabled) Prefs.arrivalContact else ""
            if (contact.isNotBlank()) {
                arrivalSent = true
                val txt = if (wazeMins != null && wazeMins > 0) "אני מגיע בעוד $wazeMins דקות" else "אני מגיע בעוד כמה דקות"
                DLog.i("🏠 הודעת הגעה (${if (byWaze) "לפי וייז" else "לפי מרחק"}): $txt")
                Out.say(Contacts.message(app, contact, txt))
            }
        }
        // תזכורות "כשאני מגיע הביתה"
        if (d < 300) {
            val list = Store.list(Store.PLACE_REM)
            if (list.isNotEmpty()) {
                Store.clear(Store.PLACE_REM)
                Out.say("הגעת הביתה. תזכורת: " + list.joinToString(". ") { it.optString("text") })
                list.forEachIndexed { i, o -> Notify.alert(app, 600 + i, "תזכורת", o.optString("text")) }
            }
        }
    }
}
