package com.kolbaderech.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper

/** רדיו אינטרנט פשוט. את רשימת התחנות אפשר לערוך בהגדרות. */
object Radio {
    private var player: MediaPlayer? = null
    private var focus: AudioFocusRequest? = null
    private val handler = Handler(Looper.getMainLooper())
    var currentName: String? = null
        private set

    fun stations(): List<Pair<String, String>> = Prefs.pairs(Prefs.radioStations)

    /** שמות בעברית → מה שמופיע במאגר התחנות (שם/מספר). */
    private val aliases = mapOf(
        "גלגלצ" to listOf("galgalatz", "glglz"), "גלי צהל" to listOf("galei tzahal", "galatz", "glz", "army radio"),
        "גלצ" to listOf("galei tzahal", "galatz", "glz"), "כאן ב" to listOf("kan bet", "reshet bet", "kan b"),
        "רשת ב" to listOf("reshet bet", "kan bet"), "כאן גימל" to listOf("kan gimel", "reshet gimel"),
        "רשת גימל" to listOf("reshet gimel", "kan gimel"), "כאן 88" to listOf("kan 88", "88fm"),
        "88" to listOf("88fm", "kan 88"), "כאן תרבות" to listOf("kan tarbut"), "כאן קול המוזיקה" to listOf("kol hamusica", "kan kol"),
        "קול המוזיקה" to listOf("kol hamusica"), "כאן מורשת" to listOf("kan moreshet"), "כאן רקע" to listOf("kan reka"),
        "כאן מכאן" to listOf("makan"), "אקו 99" to listOf("eco 99", "eco99"), "99" to listOf("eco 99", "99fm"),
        "103" to listOf("103fm", "103 fm"), "102" to listOf("102fm", "radio tel aviv"), "רדיו תל אביב" to listOf("radio tel aviv", "102fm"),
        "100" to listOf("100fm", "radius", "100 fm"), "רדיוס" to listOf("radius", "100fm"), "ללא הפסקה" to listOf("100fm", "radius"),
        "קול חי" to listOf("kol chai", "kol hai", "93fm"), "קול ברמה" to listOf("kol barama", "kol berama"),
        "קול רגע" to listOf("kol rega"), "קול הים האדום" to listOf("kol hayam", "eilat"), "רדיו צפון" to listOf("radio north", "radio tsafon", "104.5"),
        "צפון" to listOf("radio north", "104.5"), "רדיו דרום" to listOf("radio darom", "101.5", "darom"),
        "רדיו ירושלים" to listOf("radio jerusalem", "101fm"), "ירושלים" to listOf("jerusalem"), "רדיו חיפה" to listOf("radio haifa", "107.5"),
        "חיפה" to listOf("haifa"), "רדיו לב המדינה" to listOf("lev hamedina", "91fm"), "לב המדינה" to listOf("lev hamedina", "91fm"),
        "רדיו אמצע הדרך" to listOf("emtza haderech", "90fm"), "90" to listOf("90fm"), "91" to listOf("91fm"), "97" to listOf("97fm"),
        "רדיו קול פליי" to listOf("kol play"), "פרש" to listOf("fresh"), "רדיו פרש" to listOf("fresh")
    )

    private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N}. ]"), " ").replace(Regex("\\s+"), " ").trim()

    /** מוצא תחנה לפי מה שנאמר: קודם ברשימה שלך, ואז לפי שמות נרדפים. */
    fun find(text: String): Pair<String, String>? {
        val list = stations()
        if (list.isEmpty()) return null
        val t = norm(text)
        list.firstOrNull { t.contains(norm(it.first)) && norm(it.first).length >= 2 }?.let { return it }
        val keys = aliases.entries.filter { t.contains(it.key) }.sortedByDescending { it.key.length }
        for (k in keys) {
            for (en in k.value) {
                list.firstOrNull { norm(it.first).contains(en) }?.let { return it }
            }
        }
        // מספר תדר ("103", "99") שמופיע בשם התחנה
        Regex("\\d{2,3}(?:\\.\\d)?").findAll(t).forEach { m ->
            list.firstOrNull { norm(it.first).contains(m.value) }?.let { return it }
        }
        return null
    }

    /** טוען את כל התחנות הישראליות שעובדות כרגע ממאגר radio-browser (חינמי, בלי מפתח). */
    fun loadAllIsraeli(done: (Int) -> Unit) {
        Net.async({
            val servers = listOf("de1", "fi1", "nl1", "at1", "de2")
            var res: String? = null
            for (srv in servers) {
                res = Net.get(
                    "https://$srv.api.radio-browser.info/json/stations/search?countrycode=IL&hidebroken=true" +
                        "&order=clickcount&reverse=true&limit=400"
                )
                if (res != null) break
            }
            val arr = org.json.JSONArray(res ?: return@async null)
            val seen = HashSet<String>()
            val lines = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val name = o.optString("name").replace("=", "-").replace("\n", " ").trim()
                val url = o.optString("url_resolved").ifBlank { o.optString("url") }.trim()
                if (name.isEmpty() || url.isEmpty()) continue
                if (!seen.add(norm(name))) continue
                lines.add("$name=$url")
            }
            lines
        }) { lines ->
            if (lines == null || lines.isEmpty()) {
                done(0)
                return@async
            }
            // התחנות שהוספת בעצמך נשארות למעלה
            val mine = Prefs.radioStations.lines().filter { it.contains("=") }
            val merged = (mine + lines).distinctBy { norm(it.substringBefore("=")) }
            Prefs.radioStations = merged.joinToString("\n")
            DLog.i("📻 נטענו ${lines.size} תחנות")
            done(lines.size)
        }
    }

    fun play(ctx: Context, station: Pair<String, String>): String? {
        stop(ctx)
        DLog.i("📻 מפעילה: ${station.first}")
        val am = ctx.getSystemService(AudioManager::class.java)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener({ change ->
                val p = player ?: return@setOnAudioFocusChangeListener
                when (change) {
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> p.setVolume(0.25f, 0.25f)
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> p.setVolume(0.1f, 0.1f)
                    AudioManager.AUDIOFOCUS_GAIN -> p.setVolume(1f, 1f)
                    AudioManager.AUDIOFOCUS_LOSS -> stop(ctx)
                }
            }, handler)
            .build()
        focus = req
        am.requestAudioFocus(req)
        var created: MediaPlayer? = null
        return try {
            val p = MediaPlayer()
            created = p
            p.setAudioAttributes(attrs)
            p.setDataSource(station.second)
            p.setOnPreparedListener { it.start(); DLog.i("📻 מנגן: ${station.first}") }
            p.setOnErrorListener { _, what, extra ->
                DLog.i("📻 שגיאה בתחנה ${station.first}: $what/$extra")
                Announcer.notice("התחנה ${station.first} לא זמינה כרגע. אפשר לעדכן את הכתובת שלה בהגדרות")
                stop(ctx)
                true
            }
            p.prepareAsync()
            player = p
            // הגנה על הגלישה: רדיו שנשכח דלוק נעצר אחרי 3 שעות
            handler.removeCallbacksAndMessages(null)
            handler.postDelayed({ if (player === p) { DLog.i("📻 נעצר אוטומטית אחרי 3 שעות"); stop(ctx) } }, 3 * 60 * 60_000L)
            currentName = station.first
            null
        } catch (e: Exception) {
            // כתובת לא תקינה וכו׳: הנגן עוד לא נשמר ב-player, ולכן משחררים אותו כאן (אחרת דליפה)
            if (created != null && created !== player) try { created.release() } catch (e2: Exception) {}
            stop(ctx)
            "לא הצלחתי להפעיל את ${station.first}"
        }
    }

    fun isPlaying() = player != null

    fun stop(ctx: Context) {
        if (player != null) DLog.i("📻 עוצרת את הרדיו")
        player?.let {
            try {
                it.stop()
            } catch (e: Exception) {
            }
            it.release()
        }
        player = null
        currentName = null
        focus?.let { ctx.getSystemService(AudioManager::class.java).abandonAudioFocusRequest(it) }
        focus = null
    }
}
