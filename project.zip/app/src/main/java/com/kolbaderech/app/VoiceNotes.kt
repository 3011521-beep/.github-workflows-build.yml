package com.kolbaderech.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Environment
import android.util.Base64
import java.io.File

/**
 * הודעות קוליות מוואטסאפ: וואטסאפ שומר כל הודעה קולית כקובץ בטלפון.
 * אנחנו מוצאים את הקובץ החדש ומשמיעים אותו (צריך הרשאת "גישה לכל הקבצים").
 */
object VoiceNotes {
    private val played = LinkedHashSet<String>()

    fun isVoice(text: String): Boolean {
        val l = text.lowercase()
        return text.contains("🎤") || l.contains("הודעה קולית") || l.contains("voice message") ||
            l.contains("הקלטה קולית") || l.startsWith("audio") || l.contains("‏הודעה קולית")
    }

    /** "🎤 הודעה קולית (0:12)" → "12 שניות" */
    fun durationText(text: String): String {
        val m = Regex("(\\d+):(\\d{2})").find(text) ?: return ""
        val min = m.groupValues[1].toInt()
        val sec = m.groupValues[2].toInt()
        return when {
            min == 0 -> "$sec שניות"
            sec == 0 -> if (min == 1) "דקה" else "$min דקות"
            min == 1 -> "דקה ו-$sec שניות"
            else -> "$min דקות ו-$sec שניות"
        }
    }

    fun canRead(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun dirs(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        return listOf(
            File(root, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes"),
            File(root, "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Voice Notes"),
            File(root, "WhatsApp/Media/WhatsApp Voice Notes"),
            File(root, "WhatsApp Business/Media/WhatsApp Business Voice Notes")
        )
    }

    private fun isAudio(f: File) = f.name.endsWith(".opus") || f.name.endsWith(".ogg") || f.name.endsWith(".m4a")

    /** קבצי הקול בתיקייה ובתת-תיקיות (תיקיות שבועיות, Private) עד עומק 2, בלי "Sent". */
    private fun listAudio(d: File, depth: Int = 0, out: ArrayList<File> = ArrayList()): ArrayList<File> {
        val items = try { d.listFiles() } catch (e: Throwable) { null } ?: return out
        for (f in items) {
            if (f.isDirectory) {
                if (depth < 2 && !f.name.equals("Sent", ignoreCase = true)) listAudio(f, depth + 1, out)
            } else if (isAudio(f)) out.add(f)
        }
        return out
    }

    private fun audioPermOk(c: Context): Boolean =
        Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** הקובץ הקולי הכי חדש שעוד לא הושמע. */
    @Synchronized
    fun findLatest(c: Context, since: Long): File? {
        if (!canRead(c) && !audioPermOk(c)) return null
        val hit = try {
            dirs().filter { it.isDirectory }.flatMap { listAudio(it) }.asSequence()
                .filter { it.isFile && it.lastModified() >= since - 180_000 && it.absolutePath !in played }
                .maxByOrNull { it.lastModified() }
        } catch (e: Throwable) {
            null
        } ?: return null
        played.add(hit.absolutePath)
        while (played.size > 200) played.remove(played.first())
        return hit
    }

    /** שורה אחת שמסבירה למה לא נמצא קובץ: הרשאות, תיקיות, ומתי נשמר הקובץ האחרון. */
    fun diagnose(c: Context, since: Long): String = try {
        val fmt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
        val media = if (Build.VERSION.SDK_INT >= 33) (if (audioPermOk(c)) "יש" else "אין") else "לא נדרש"
        val root = Environment.getExternalStorageDirectory().absolutePath
        "גישה לכל הקבצים: ${if (canRead(c)) "יש" else "אין"}, הרשאת אודיו: $media, חיפוש מ-${fmt.format(java.util.Date(since))}. " +
            dirs().joinToString("; ") { d ->
                val name = d.absolutePath.removePrefix(root).trim('/')
                if (!d.isDirectory) "$name: לא קיימת"
                else {
                    val files = listAudio(d)
                    val newest = files.maxByOrNull { it.lastModified() }
                    if (newest == null) "$name: ${if (d.list() == null) "אין גישה" else "ריקה"}"
                    else "$name: ${files.size} קבצים, האחרון ${fmt.format(java.util.Date(newest.lastModified()))}"
                }
            }
    } catch (e: Throwable) {
        "שגיאה באבחון: ${e.javaClass.simpleName}"
    }

    fun toBase64(path: String?): String? {
        if (path == null) return null
        val f = File(path)
        if (!f.exists() || f.length() > 4_000_000) return null
        return try {
            Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    fun fromBase64(c: Context, b64: String, id: String): String? = try {
        val dir = File(c.cacheDir, "voice").apply { mkdirs() }
        dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 6 * 60 * 60_000L }?.forEach { it.delete() }
        val f = File(dir, "$id.opus")
        f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
        f.absolutePath
    } catch (e: Exception) {
        null
    }

    // ---------------- השמעה ----------------
    private var player: MediaPlayer? = null

    fun play(path: String, attrs: android.media.AudioAttributes, done: () -> Unit): Boolean {
        stop()
        var created: MediaPlayer? = null
        return try {
            val p = MediaPlayer()
            created = p
            p.setAudioAttributes(attrs)
            p.setDataSource(path)
            p.setOnCompletionListener { stop(); done() }
            p.setOnErrorListener { _, _, _ -> stop(); done(); true }
            p.prepare()
            p.start()
            player = p
            true
        } catch (e: Exception) {
            // קובץ פגום / לא נגיש: הנגן עוד לא נשמר ב-player – משחררים אותו (אחרת דליפה)
            if (created != null && created !== player) try { created.release() } catch (e2: Exception) {}
            stop()
            false
        }
    }

    fun stop() {
        player?.let {
            try {
                it.stop()
            } catch (e: Exception) {
            }
            it.release()
        }
        player = null
    }
}
