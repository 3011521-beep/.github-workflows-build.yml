package com.kolbaderech.app

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kolbaderech.app.ui.BigButton
import com.kolbaderech.app.ui.C
import com.kolbaderech.app.ui.CardBox
import com.kolbaderech.app.ui.PrefText
import com.kolbaderech.app.ui.PrefToggle

/** הגדרות דיווח תקלות אוטומטי ל-GitHub. */
@Composable
fun DiagCard() {
    val ctx = LocalContext.current
    val st by Diag.status.collectAsState()
    var ver by remember { mutableStateOf(0) }
    val ready = remember(ver) { Diag.configured() }
    CardBox(padding = 16.dp) {
        Text(
            "כשמשהו משתבש, נוגה פותחת דיווח (Issue) במאגר GitHub של האפליקציה. משם התיקון נבנה אוטומטית ומגיע אליך בעדכון הבא. " +
                "אפשר גם להגיד לה בקול „יש באג“ או „משהו לא עובד“.",
            color = C.Muted, fontSize = 13.sp
        )
        PrefToggle("דיווח אוטומטי אחרי קריסה", "פעם אחת לכל קריסה, בפתיחה הבאה", { Prefs.diagOnCrash }, { Prefs.diagOnCrash = it })
        PrefToggle("סיכום תקלות יומי", "לכל היותר פעם ביום, רק אם ביומן נרשמו תקלות", { Prefs.diagDaily }, { Prefs.diagDaily = it })
        PrefText(
            "מפתח GitHub לדיווחים (לא חובה)",
            "ריק = המפתח של העדכונים. מפתח Fine-grained עם הרשאת Issues: Read and write על המאגר",
            { Prefs.diagToken }, { Prefs.diagToken = it; ver++ },
            secret = true
        )
        if (!ready) {
            Text("אין עדיין מפתח GitHub או שם מאגר – אי אפשר לשלוח דיווחים", color = C.Amber, fontSize = 14.sp)
        }
        BigButton("שלח דיווח עכשיו", null, C.Surface, C.Text, Modifier.fillMaxWidth(), outlined = true) {
            Diag.report(ctx, "כפתור ידני")
        }
        if (st.isNotBlank()) Text(st, color = if (st.startsWith("הדיווח נשלח")) C.Teal else C.Soft, fontSize = 14.sp)
        Text(
            "הדיווח כולל את פרטי המכשיר ואת יומן הפעולות, אחרי הסרת מספרי טלפון, מיילים, מפתחות ותוכן הודעות (שמות השולחים נשארים). " +
                "חשוב: המאגר ב-GitHub צריך להיות פרטי (Private).",
            color = C.Muted, fontSize = 12.sp
        )
    }
}
