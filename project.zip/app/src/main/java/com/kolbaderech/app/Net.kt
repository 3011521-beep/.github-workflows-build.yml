package com.kolbaderech.app

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Net {
    val main = Handler(Looper.getMainLooper())

    fun get(url: String): String? = request(url, null)
    fun post(url: String, body: String, headers: Map<String, String> = emptyMap()): String? = request(url, body, headers = headers)
    fun getAsBrowser(url: String): String? = request(url, null, browser = true)
    fun postQuick(url: String, body: String, timeoutMs: Int): String? = request(url, body, timeoutMs = timeoutMs)

    private fun request(url: String, body: String?, browser: Boolean = false, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 15000): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 15000
            c.setRequestProperty(
                "User-Agent",
                if (browser) "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
                else "Noga/1.0"
            )
            if (browser) c.setRequestProperty("Accept-Language", "he-IL,he;q=0.9,en;q=0.8")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.readTimeout = timeoutMs
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            if (c.responseCode !in 200..299) null
            else c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }

    /** מריץ ברקע ומחזיר תוצאה ב-Main thread. */
    fun <T> async(work: () -> T?, done: (T?) -> Unit) {
        Thread {
            val r = try {
                work()
            } catch (e: Exception) {
                null
            }
            main.post { done(r) }
        }.start()
    }

    // ---------------- מזג אוויר (Open-Meteo, חינמי, בלי מפתח) ----------------
    fun weather(lat: Double, lng: Double): String? {
        if (lat == 0.0 && lng == 0.0) return null
        val res = get(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lng" +
                "&current=temperature_2m,weather_code&hourly=precipitation_probability&forecast_hours=4&timezone=auto"
        ) ?: return null
        val o = JSONObject(res)
        val cur = o.getJSONObject("current")
        val temp = Math.round(cur.getDouble("temperature_2m"))
        val code = cur.optInt("weather_code")
        val probs = o.optJSONObject("hourly")?.optJSONArray("precipitation_probability")
        var maxRain = 0
        if (probs != null) for (i in 0 until probs.length()) maxRain = maxOf(maxRain, probs.optInt(i))
        val desc = when (code) {
            0 -> "בהיר"
            1, 2, 3 -> "מעונן חלקית"
            45, 48 -> "ערפל"
            in 51..67 -> "גשום"
            in 71..77 -> "שלג"
            in 80..82 -> "ממטרים"
            in 95..99 -> "סופות רעמים"
            else -> ""
        }
        var s = "בחוץ $temp מעלות" + if (desc.isNotEmpty()) ", $desc" else ""
        if (maxRain >= 50) s += ". צפוי גשם בשעות הקרובות, סע בזהירות"
        return s
    }

    fun rainSoon(lat: Double, lng: Double): Boolean {
        val w = weather(lat, lng) ?: return false
        return w.contains("צפוי גשם")
    }

    // ---------------- חדשות (RSS של ynet) ----------------
    fun news(): String? {
        val xml = get("https://www.ynet.co.il/Integration/StoryRss2.xml") ?: return null
        val re = Regex("<title>(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?</title>", RegexOption.DOT_MATCHES_ALL)
        val titles = re.findAll(xml).map { it.groupValues[1].trim() }.filter { it.isNotEmpty() }.drop(1).take(5).toList()
        if (titles.isEmpty()) return null
        return "הכותרות עכשיו: " + titles.joinToString(". ")
    }

    // ---------------- שערי מטבע ----------------
    fun convert(amount: Double, from: String, to: String): Double? {
        val res = get("https://open.er-api.com/v6/latest/$from") ?: return null
        val rate = JSONObject(res).getJSONObject("rates").optDouble(to, Double.NaN)
        return if (rate.isNaN()) null else amount * rate
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

/** Gemini: הבנת משפטים חופשיים, תשובות לשאלות וסיכום הודעות ארוכות. */
object Gemini {
    fun available() = Prefs.geminiKey.isNotBlank()

    /**
     * שליחה ל-Gemini. המפתח נשלח בכותרת (עובד גם למפתחות הישנים AIza… וגם לפורמט החדש AQ.…),
     * ואם השרת דוחה – ניסיון נוסף כ-Bearer token.
     */
    @Volatile var lastModelUsed = ""

    private val preferred = listOf(
        "gemini-2.5-flash-lite", "gemini-flash-lite-latest", "gemini-2.5-flash", "gemini-flash-latest",
        "gemini-3.5-flash", "gemini-3.1-flash-lite"
    )

    @Volatile private var availableCache: Set<String>? = null
    @Volatile private var availableAt = 0L

    /** כל המודלים שהחשבון יכול להשתמש בהם לטקסט (נשמר לשעה). */
    private fun availableModels(): Set<String> {
        val c = availableCache
        if (c != null && System.currentTimeMillis() - availableAt < 60 * 60_000L) return c
        val key = Prefs.geminiKey.trim()
        val res = Net.get("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200&key=" + Net.enc(key)) ?: return emptySet()
        val set = try {
            val arr = JSONObject(res).optJSONArray("models") ?: return emptySet()
            (0 until arr.length()).mapNotNull { i ->
                val m = arr.optJSONObject(i) ?: return@mapNotNull null
                val methods = m.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
                val n = m.optString("name").removePrefix("models/")
                if (!methods.contains("generateContent") || Regex("tts|image|banana|lyria|robotics|computer|transcribe|embedding").containsMatchIn(n)) null else n
            }.toSet()
        } catch (e: Exception) {
            emptySet()
        }
        if (set.isNotEmpty()) {
            availableCache = set
            availableAt = System.currentTimeMillis()
        }
        return set
    }

    /** בוחר לבד מודל שקיים בחשבון (אם השם בהגדרות לא קיים / ישן). */
    private fun pickModel(exclude: String? = null): String? {
        val key = Prefs.geminiKey.trim()
        val res = Net.get("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200&key=" + Net.enc(key)) ?: return null
        val names = try {
            val arr = JSONObject(res).optJSONArray("models") ?: return null
            (0 until arr.length()).mapNotNull { i ->
                val m = arr.optJSONObject(i) ?: return@mapNotNull null
                val methods = m.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
                if (!methods.contains("generateContent")) null else m.optString("name").removePrefix("models/")
            }.toSet()
        } catch (e: Exception) {
            return null
        }
        return preferred.firstOrNull { it in names && it != exclude }
            ?: names.firstOrNull { it.contains("flash") && !it.contains("tts") && !it.contains("image") && it != exclude }
    }

    private fun sendOnce(model: String, bodyJson: String, mode: String): Pair<Int, String> {
        val key = Prefs.geminiKey.trim()
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        var c: java.net.HttpURLConnection? = null
        return try {
            val u = if (mode == "query") "$url?key=" + Net.enc(key) else url
            c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 20000
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            when (mode) {
                "header" -> c.setRequestProperty("x-goog-api-key", key)
                "bearer" -> c.setRequestProperty("Authorization", "Bearer $key")
            }
            c.outputStream.use { it.write(bodyJson.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            DLog.i("🤖 $model [$mode] → $code")
            code to text
        } catch (e: Exception) {
            DLog.i("🤖 $model [$mode] → אין תשובה: ${e.javaClass.simpleName} ${e.message ?: ""}")
            -1 to (e.message ?: e.javaClass.simpleName)
        } finally {
            c?.disconnect()
        }
    }

    /** מנסה את דרכי ההזדהות; Bearer רק אם שתי האחרות נדחו. מחזיר את התשובה הכי אינפורמטיבית. */
    private fun send(model: String, bodyJson: String): Pair<Int, String> {
        val h = sendOnce(model, bodyJson, "header")
        if (h.first in 200..299 || (h.first != -1 && h.first !in 401..403)) return h
        val q = sendOnce(model, bodyJson, "query")
        if (q.first in 200..299 || (q.first != -1 && q.first !in 401..403)) return q
        if (Prefs.geminiKey.trim().startsWith("AIza")) return if (q.first != -1) q else h
        val b = sendOnce(model, bodyJson, "bearer")
        if (b.first in 200..299) return b
        // לא להסתיר שגיאה אמיתית מאחורי ה-401 של ניסיון ה-Bearer
        return listOf(q, h, b).firstOrNull { it.first != -1 && it.first !in 401..403 } ?: if (q.first != -1) q else b
    }

    /**
     * שליחה ל-Gemini, עם תיקון עצמי: אם המודל לא קיים (404) – בוחר מודל זמין ושומר אותו;
     * אם נגמרה המכסה של המודל (429) – מנסה מודל קל יותר.
     */
    fun post(bodyJson: String): Pair<Int, String> {
        var model = Prefs.geminiModel.trim().removePrefix("models/").ifBlank { "gemini-2.5-flash-lite" }
        var r = send(model, bodyJson)
        lastModelUsed = model
        if (r.first == 404) {
            pickModel()?.let { m ->
                DLog.i("🤖 המודל $model לא זמין, עוברת ל-$m")
                Prefs.geminiModel = m
                model = m
                r = send(m, bodyJson)
            }
        }
        // עומס זמני בשרת (503/500/502): ניסיון חוזר קצר, ואז מודלים חלופיים
        if (r.first in listOf(500, 502, 503, 504)) {
            try { Thread.sleep(1200) } catch (e: InterruptedException) { }
            val again = send(model, bodyJson)
            if (again.first in 200..299) return again
            if (again.first !in 401..403) r = again
        }
        if (r.first in listOf(429, 500, 502, 503, 504)) {
            // מנסה מודלים אחרים שקיימים בחשבון, מהקל והפחות עמוס
            val avail = availableModels()
            val order = listOf(
                "gemini-2.5-flash-lite", "gemini-flash-lite-latest", "gemini-2.5-flash", "gemini-3.1-flash-lite",
                "gemini-3.5-flash-lite", "gemma-4-26b-a4b-it", "gemma-4-31b-it", "gemini-3.5-flash"
            ).filter { it != model && (avail.isEmpty() || it in avail) }.take(5)
            for (alt in order) {
                val r2 = send(alt, bodyJson)
                DLog.i("🤖 ניסיון עם $alt: ${r2.first}")
                if (r2.first in 200..299) {
                    lastModelUsed = alt
                    return r2
                }
                if (r2.first == 401 || r2.first == 403) break
            }
        }
        if (r.first !in 200..299) DLog.i("🤖 Gemini שגיאה ${r.first} ($model): ${r.second.take(160)}")
        return r
    }

    private fun body(prompt: String) = JSONObject().put(
        "contents",
        JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))
    ).toString()

    /** הטקסט מהתשובה (מדלג על "מחשבות" של מודלים חושבים). */
    private fun textOf(res: String): String {
        val parts = JSONObject(res).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.optBoolean("thought", false)) continue
            sb.append(p.optString("text"))
        }
        return sb.toString().trim()
    }

    private fun call(prompt: String): String? {
        if (!available()) return null
        val (code, res) = post(body(prompt))
        return if (code in 200..299) try { textOf(res) } catch (e: Exception) { null } else null
    }

    fun ask(prompt: String, cb: (String?) -> Unit) = Net.async({ call(prompt) }, cb)

    /** בדיקת המפתח: מחזיר (הצליח?, הסבר). */
    fun test(cb: (Pair<Boolean, String>) -> Unit) = Net.async({
        if (!available()) return@async false to "לא הוזן מפתח"
        val (code, res) = post(body("ענה במילה אחת בעברית: מה הבירה של צרפת?"))
        if (code in 200..299) {
            val txt = try { textOf(res) } catch (e: Exception) { "?" }
            true to "המפתח עובד ✓ (מודל: $lastModelUsed, התשובה: $txt)"
        } else {
            val msg = try { JSONObject(res).getJSONObject("error").optString("message") } catch (e: Exception) { res.take(150) }
            false to when (code) {
                -1 -> "אין חיבור לאינטרנט: $msg"
                400 -> "המפתח לא תקין (אולי הועתק חלקית או עם רווח): $msg"
                401, 403 -> "גוגל לא מכירה את המפתח – אולי נמחק, או שהועתק לא שלם. צור מפתח חדש ב-AI Studio והדבק שוב"
                404 -> "לא נמצא מודל זמין לחשבון הזה"
                429 -> "עברת את המכסה החינמית להיום. זה יתאפס מחר"
                500, 502, 503, 504 -> "המפתח תקין ✓ – אבל השרתים של גוגל עמוסים כרגע בכל המודלים. נסה שוב בעוד כמה דקות"
                else -> "שגיאה $code: $msg"
            }
        }
    }) { r -> cb(r ?: (false to "שגיאה לא ידועה")) }

    fun summarize(text: String, cb: (String?) -> Unit) = ask(
        "סכם בעברית, בשני משפטים קצרים שמתאימים להקראה בקול בזמן נהיגה, את ההודעה הבאה. החזר רק את הסיכום.\n\n$text", cb
    )

    /** הופך בקשה חופשית לפקודה שהאפליקציה מבינה, או לתשובה. */
    fun interpret(heard: String, cb: (String?) -> Unit) = ask(
        """
        אתה עוזר קולי ברכב בשם "${Prefs.assistantName}". המשתמש אמר: "$heard"
        אם זו בקשה לפעולה, החזר שורה אחת בפורמט: CMD: <פקודה>
        כאשר <פקודה> היא אחת מהתבניות הבאות בדיוק (מלא את החלקים בסוגריים):
        תדליקי <שיר או זמר> ביוטיוב מיוזיק | תעצרי | השיר הבא | הקודם | תמשיכי | יותר חזק | יותר חלש | מה השיר |
        נווטי ל<יעד> | סעי הביתה | סעי לעבודה | תתקשרי ל<שם> | תשלחי ל<שם> ש<הודעה> | תשלחי ל<שם> איפה אני |
        תזכירי לי בעוד <מספר> דקות <מה> | כשאני מגיע הביתה תזכירי לי <מה> | תרשמי <פתק> | תוסיפי <מוצר> לרשימת הקניות |
        מה ברשימת הקניות | תקריאי את הפתקים | איפה החניתי | תפתחי את השער | מה החדשות | מה מזג האוויר | מה יש לי היום ביומן |
        קבעי פגישה <מחר/היום> ב<שעה> <נושא> | תדליקי רדיו <תחנה> | תכבי את הרדיו | שקט עד סוף הנסיעה | תקריאי שוב | מצב חירום
        אם זו שאלה כללית, החזר שורה אחת בפורמט: ANSWER: <תשובה קצרה בעברית, עד שני משפטים, מתאימה להקראה>
        אל תחזיר שום דבר אחר.
        """.trimIndent(), cb
    )
}
