package com.kolbaderech.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * דיווח תקלות אוטומטי: פותח Issue במאגר GitHub של האפליקציה (תווית noga-bug),
 * עם פרטי המכשיר והיומן (אחרי הסרת מספרי טלפון, מיילים, מפתחות ותוכן הודעות).
 * משם GitHub Action מתקן, בונה גרסה, והעדכון האוטומטי מתקין אותה.
 */
object Diag {
    const val LABEL = "noga-bug"
    private const val MAX_PER_DAY = 5
    private const val MAX_BODY = 60_000

    val status = MutableStateFlow("")

    @Volatile private var app: Context? = null
    private val main get() = Net.main

    private fun sp(): SharedPreferences? = app?.getSharedPreferences("diag", Context.MODE_PRIVATE)

    // ---------------- הגדרות ----------------
    private fun repo(): String = Prefs.updRepo.trim().ifBlank { BuildConfig.UPDATE_REPO }
        .removePrefix("https://github.com/").trim('/')

    private fun token(): String = Prefs.diagToken.trim().ifBlank { Prefs.updToken.trim() }.ifBlank { BuildConfig.UPDATE_TOKEN }

    /** יש מאגר ומפתח – אפשר לדווח. */
    fun configured(): Boolean = try {
        repo().contains("/") && token().isNotBlank()
    } catch (e: Throwable) {
        false
    }

    // ---------------- ספירת תקלות ביומן (לסיכום היומי) ----------------
    private val problemRe = Regex("לא מצאתי|לא הצלחתי|שגיאה|נכשל|❌")
    @Volatile private var problems = -1
    @Volatile private var disconnects = -1

    /** נקרא מ-DLog על כל שורה. לא כותב ליומן (אחרת לולאה). */
    fun noteLine(msg: String) {
        if (msg.startsWith("🐞") || msg.startsWith("📱")) return // שורות של הטלפון נספרות בטלפון עצמו
        val isDisc = msg.contains("החיבור נותק")
        val isProb = !isDisc && problemRe.containsMatchIn(msg)
        if (!isDisc && !isProb) return
        val p = sp() ?: return
        if (problems < 0) {
            problems = p.getInt("problems", 0); disconnects = p.getInt("disconnects", 0)
        }
        if (isDisc) disconnects++ else problems++
        p.edit().putInt("problems", problems).putInt("disconnects", disconnects).apply()
    }

    private fun resetCounters() {
        problems = 0; disconnects = 0
        sp()?.edit()?.putInt("problems", 0)?.putInt("disconnects", 0)?.apply()
    }

    // ---------------- הפעלה ----------------
    private var periodic: Runnable? = null

    /** נקרא בפתיחת האפליקציה: דיווח על קריסה קודמת, ובדיקת סיכום יומי מדי פעם. */
    fun onLaunch(c: Context) {
        app = c.applicationContext
        main.postDelayed({ CrashGuard.safe(Unit) { checkCrash() } }, 8_000)
        if (periodic == null) {
            val r = object : Runnable {
                override fun run() {
                    CrashGuard.safe(Unit) { maybeDaily() }
                    main.postDelayed(this, 2 * 60 * 60_000L)
                }
            }
            periodic = r
            main.postDelayed(r, 90_000)
        }
    }

    private fun checkCrash() {
        val c = app ?: return
        if (!Prefs.diagOnCrash || !configured()) return
        val (txt, at) = CrashGuard.lastCrashFile(c) ?: return
        if (System.currentTimeMillis() - at > 7 * 24 * 60 * 60_000L) return // ישנה מדי
        val h = txt.hashCode().toString()
        val p = sp() ?: return
        if (p.getString("crashHash", "") == h) return // כבר דווחה
        p.edit().putString("crashHash", h).apply()
        report(c, "קריסה", crash = txt)
    }

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun maybeDaily() {
        val c = app ?: return
        if (!Prefs.diagDaily || !configured()) return
        val p = sp() ?: return
        if (p.getString("dailyDay", "") == today()) return
        val pr = p.getInt("problems", 0)
        val dc = p.getInt("disconnects", 0)
        if (pr < 1 && dc <= 10) return
        p.edit().putString("dailyDay", today()).apply()
        val summary = "בעיות שנרשמו ביומן מאז הדיווח הקודם: $pr" + if (dc > 0) ", ניתוקים מהרכב: $dc" else ""
        report(c, "סיכום תקלות יומי", userText = summary) { ok, _ -> if (ok) resetCounters() }
    }

    // ---------------- הגבלת קצב ----------------
    /** מחזיר null אם מותר לשלוח (ומעדכן את המונה), אחרת הסבר. */
    @Synchronized
    private fun takeSlot(): String? {
        val p = sp() ?: return null
        val day = today()
        val n = if (p.getString("day", "") == day) p.getInt("count", 0) else 0
        if (n >= MAX_PER_DAY) return "כבר נשלחו היום $MAX_PER_DAY דיווחים – זה המקסימום ליום"
        p.edit().putString("day", day).putInt("count", n + 1).apply()
        return null
    }

    // ---------------- שליחה ----------------
    /**
     * שולח דיווח ברקע. [trigger]: קריסה / דיווח קולי / סיכום תקלות יומי / כפתור ידני.
     * [done] נקרא ב-Main thread עם הצלחה והודעה.
     */
    fun report(
        c: Context,
        trigger: String,
        userText: String? = null,
        crash: String? = null,
        done: ((Boolean, String) -> Unit)? = null
    ) {
        if (app == null) app = c.applicationContext
        val ctx = c.applicationContext
        fun finish(ok: Boolean, msg: String) {
            status.value = msg
            DLog.i("🐞 $msg")
            CrashGuard.safe(Unit) { done?.invoke(ok, msg) }
        }
        if (!configured()) {
            finish(false, "אין מפתח GitHub או שם מאגר – אי אפשר לשלוח דיווח"); return
        }
        takeSlot()?.let { finish(false, it); return }
        status.value = "שולחת דיווח…"
        // אוספים את היומן עכשיו, לפני שהשורה "🐞" נכנסת
        val log = DLog.text()
        val linkInfo = try {
            (if (Link.connected.value) "מחובר" else "לא מחובר") + " · " + Link.status.value
        } catch (e: Throwable) {
            "?"
        }
        Net.async({
            try {
                val title = "[נוגה] $trigger · v${BuildInfo.version(ctx)} · ${Prefs.role ?: "?"}"
                val body = buildBody(ctx, trigger, userText, crash, log, linkInfo)
                post(title, body)
            } catch (e: Throwable) {
                false to "הדיווח נכשל: ${e.javaClass.simpleName}"
            }
        }) { r ->
            val (ok, msg) = r ?: (false to "הדיווח נכשל")
            finish(ok, msg)
        }
    }

    private fun buildBody(c: Context, trigger: String, userText: String?, crash: String?, log: String, linkInfo: String): String {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val sb = StringBuilder()
        sb.append("### דיווח אוטומטי מנוגה\n\n")
        sb.append("| | |\n|---|---|\n")
        sb.append("| טריגר | ").append(cell(trigger)).append(" |\n")
        sb.append("| גרסה | ").append(cell(BuildInfo.version(c))).append(" (build ").append(Updater.currentBuild(c)).append(") |\n")
        sb.append("| תפקיד | ").append(Prefs.role ?: "?").append(" |\n")
        sb.append("| אנדרואיד | ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(") |\n")
        sb.append("| מכשיר | ").append(cell("${Build.MANUFACTURER} ${Build.MODEL}")).append(" |\n")
        sb.append("| חיבור טלפון↔רכב | ").append(cell(linkInfo)).append(" |\n")
        sb.append("| זמן | ").append(now).append(" |\n\n")
        if (!userText.isNullOrBlank()) {
            sb.append("### תיאור\n\n> ").append(redact(userText).replace("\n", "\n> ")).append("\n\n")
        }
        if (!crash.isNullOrBlank()) {
            sb.append("### קריסה\n\n```text\n").append(fence(redact(crash)).take(15_000)).append("\n```\n\n")
        }
        val lines = log.split("\n").takeLast(400).joinToString("\n") { redactLine(it) }
        val head = "### יומן פעולות (400 השורות האחרונות; מספרי טלפון, מיילים, מפתחות ותוכן הודעות הוסרו)\n\n```text\n"
        val tail = "\n```\n"
        val room = MAX_BODY - sb.length - head.length - tail.length
        val logText = fence(lines).let { if (it.length > room) it.takeLast(maxOf(0, room)) else it }
        sb.append(head).append(logText).append(tail)
        return sb.toString().take(MAX_BODY)
    }

    private fun cell(s: String) = s.replace("|", "/").replace("\n", " ")
    private fun fence(s: String) = s.replace("```", "'''")

    // ---------------- פרטיות ----------------
    private val tokenRes = listOf(
        Regex("AIza[0-9A-Za-z_\\-]{20,}"),
        Regex("github_pat_[A-Za-z0-9_]{20,}"),
        Regex("gh[pousr]_[A-Za-z0-9]{20,}"),
        Regex("(?i)(key|token|auth|bearer|password|secret)([=: ]+)[^\\s&\"']{8,}"),
        // רצף ארוך של base64/hex שיש בו גם ספרות וגם אותיות (לא שמות מחלקות)
        Regex("(?<![A-Za-z0-9+/=_\\-])(?=[A-Za-z0-9+/=_\\-]*\\d)(?=[A-Za-z0-9+/=_\\-]*[A-Za-z])[A-Za-z0-9+/=_\\-]{24,}")
    )
    private val emailRe = Regex("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}")
    private val phoneRe = Regex("(?<![\\w.])\\+?\\(?\\d[\\d\\- ()]{5,}\\d(?![\\w.])")

    fun redact(s: String): String {
        var t = s
        for (r in tokenRes) t = r.replace(t) { m ->
            if (m.groups.size > 2 && m.groupValues.getOrNull(2)?.isNotEmpty() == true && m.groupValues[1].isNotEmpty()) "${m.groupValues[1]}${m.groupValues[2]}[מפתח הוסר]"
            else "[מפתח הוסר]"
        }
        t = emailRe.replace(t, "[מייל הוסר]")
        t = phoneRe.replace(t) { m -> if (m.value.count { it.isDigit() } >= 7) "[מספר הוסר]" else m.value }
        return t
    }

    /** מוריד תוכן הודעות (שנאמר בקול / תיאור תמונה / טקסט במסך) ומשאיר את שם השולח. */
    private val bodyRes = listOf(
        Regex("(🗣️ \\(לא נאמר[^)]*\\)).*"),
        Regex("(🖼️ תיאור:).*"),
        // טקסט מסך של אפליקציות הודעות עלול להכיל שיחות – מוסר. של השער / מוזיקה / הגדרות – נשאר (צריך אותו לתיקון)
        Regex("((?:whatsapp|w4b|telegram|messag|orca|signal|instagram|gm\\b).*?במסך:).*", RegexOption.IGNORE_CASE),
        Regex("(🏠 הודעת הגעה[^:]*:).*"),
        Regex("(🗺️ וייז:).*")
    )

    private fun redactLine(line: String): String {
        var t = line
        for (r in bodyRes) {
            val m = r.find(t) ?: continue
            t = t.substring(0, m.range.first) + m.groupValues[1] + " [תוכן הוסר]"
        }
        return redact(t)
    }

    private fun post(title: String, body: String): Pair<Boolean, String> {
        val repo = repo()
        var res = send(repo, title, body, withLabel = true)
        if (res.first == 422) res = send(repo, title, body, withLabel = false) // תווית לא קיימת / אין הרשאה לתוויות
        val (code, text) = res
        return when (code) {
            201 -> {
                val url = try { JSONObject(text).optString("html_url") } catch (e: Throwable) { "" }
                true to "הדיווח נשלח" + if (url.isNotBlank()) ": $url" else ""
            }
            401 -> false to "הדיווח נכשל: המפתח של GitHub לא תקין או שפג תוקפו"
            403 -> false to "הדיווח נכשל: למפתח אין הרשאת Issues: Read and write על המאגר"
            404 -> false to "הדיווח נכשל: המאגר „$repo“ לא נמצא, או שהמפתח לא כולל אותו"
            410 -> false to "הדיווח נכשל: Issues כבויים במאגר (Settings → Features → Issues)"
            -1 -> false to "הדיווח נכשל: אין חיבור (${text})"
            else -> false to "הדיווח נכשל: שגיאה $code"
        }
    }

    private fun send(repo: String, title: String, body: String, withLabel: Boolean): Pair<Int, String> {
        var c: HttpURLConnection? = null
        return try {
            val o = JSONObject().put("title", title).put("body", body)
            if (withLabel) o.put("labels", JSONArray().put(LABEL))
            c = URL("https://api.github.com/repos/$repo/issues").openConnection() as HttpURLConnection
            c.connectTimeout = 10_000
            c.readTimeout = 20_000
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer ${token()}")
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            c.setRequestProperty("User-Agent", "Noga-Diag")
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.outputStream.use { it.write(o.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val txt = try {
                (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            } catch (e: Throwable) {
                ""
            }
            code to txt
        } catch (e: Throwable) {
            -1 to e.javaClass.simpleName
        } finally {
            try { c?.disconnect() } catch (e: Throwable) { }
        }
    }
}
