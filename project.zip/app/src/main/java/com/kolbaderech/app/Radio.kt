package com.kolbaderech.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper

/** רדיו אינטרנט פשוט. את רשימת התחנות אפשר לערוך בהגדרות. */
object Radio {
    private var player: MediaPlayer? = null
    private var focus: AudioFocusRequest? = null
    private val handler = Handler(Looper.getMainLooper())
    var currentName: String? = null
        private set

    fun stations(): List<Pair<String, String>> = Prefs.pairs(Prefs.radioStations)

    fun find(text: String): Pair<String, String>? =
        stations().firstOrNull { text.contains(it.first) }

    fun play(ctx: Context, station: Pair<String, String>): String? {
        stop(ctx)
        val am = ctx.getSystemService(AudioManager::class.java)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener({ change ->
                val p = player ?: return@setOnAudioFocusChangeListener
                when (change) {
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> p.setVolume(0.25f, 0.25f)
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> p.setVolume(0.1f, 0.1f)
                    AudioManager.AUDIOFOCUS_GAIN -> p.setVolume(1f, 1f)
                    AudioManager.AUDIOFOCUS_LOSS -> stop(ctx)
                }
            }, handler)
            .build()
        focus = req
        am.requestAudioFocus(req)
        return try {
            val p = MediaPlayer()
            p.setAudioAttributes(attrs)
            p.setDataSource(station.second)
            p.setOnPreparedListener { it.start() }
            p.setOnErrorListener { _, _, _ ->
                Announcer.notice("התחנה ${station.first} לא זמינה כרגע. אפשר לעדכן את הכתובת שלה בהגדרות")
                stop(ctx)
                true
            }
            p.prepareAsync()
            player = p
            currentName = station.first
            null
        } catch (e: Exception) {
            stop(ctx)
            "לא הצלחתי להפעיל את ${station.first}"
        }
    }

    fun stop(ctx: Context) {
        player?.let {
            try {
                it.stop()
            } catch (e: Exception) {
            }
            it.release()
        }
        player = null
        currentName = null
        focus?.let { ctx.getSystemService(AudioManager::class.java).abandonAudioFocusRequest(it) }
        focus = null
    }
}
