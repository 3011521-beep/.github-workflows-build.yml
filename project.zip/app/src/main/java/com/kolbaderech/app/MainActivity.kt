package com.kolbaderech.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.kolbaderech.app.ui.AppTheme
import com.kolbaderech.app.ui.Avatar
import com.kolbaderech.app.ui.BigButton
import com.kolbaderech.app.ui.C
import com.kolbaderech.app.ui.CardBox
import com.kolbaderech.app.ui.SectionTitle
import com.kolbaderech.app.ui.ToggleRow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { AppRoot() } }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        UiBus.tick.value = UiBus.tick.value + 1
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("listen", false) == true) {
            i.removeExtra("listen")
            Announcer.listenCommand()
        }
    }
}

// ------------------------------------------------------------------
// הרשאות
// ------------------------------------------------------------------
object Perms {
    fun runtimeList(): Array<String> {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 31) l.add(Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    fun runtimeOk(c: Context) = runtimeList().all { c.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    fun listenerOk(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
    fun overlayOk(c: Context) = Settings.canDrawOverlays(c)
    fun batteryOk(c: Context) = c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
    fun allOk(c: Context) = runtimeOk(c) && listenerOk(c) && overlayOk(c)

    @SuppressLint("MissingPermission")
    fun bondedDevices(c: Context): List<Pair<String, String>> {
        if (Build.VERSION.SDK_INT >= 31 &&
            c.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) return emptyList()
        val adapter = c.getSystemService(BluetoothManager::class.java)?.adapter ?: return emptyList()
        return try {
            adapter.bondedDevices.map { (it.name ?: it.address) to it.address }.sortedBy { it.first }
        } catch (e: SecurityException) {
            emptyList()
        }
    }
}

@Composable
fun AppRoot() {
    var screen by remember { mutableStateOf("home") }
    BackHandler(enabled = screen != "home") { screen = "home" }
    when (screen) {
        "settings" -> SettingsScreen { screen = "home" }
        else -> HomeScreen(onSettings = { screen = "settings" })
    }
}

// ------------------------------------------------------------------
// מסך בית
// ------------------------------------------------------------------
@Composable
fun HomeScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val active by DriveState.active.collectAsState()
    val history by Announcer.history.collectAsState()
    val tick by UiBus.tick.collectAsState()
    var autoRead by remember { mutableStateOf(Prefs.autoRead) }
    val permsOk = remember(tick) { Perms.allOk(ctx) }
    val carName = remember(tick) { Prefs.carName }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("קול בדרך", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text("העוזר הקולי שלך לרכב", color = C.Muted, fontSize = 14.sp)
            }
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(C.Surface)
                    .border(1.dp, C.Border, CircleShape).clickable { onSettings() },
                contentAlignment = Alignment.Center
            ) {
                Icon(painterResource(R.drawable.ic_settings), contentDescription = "הגדרות", tint = C.Text, modifier = Modifier.size(22.dp))
            }
        }

        if (!permsOk) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFF3A2A0E))
                    .clickable { onSettings() }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("חסרות הרשאות כדי שהאפליקציה תעבוד. לחץ כאן להשלמה", color = C.Amber,
                    fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }

        CardBox {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(64.dp).clip(CircleShape).background(if (active) C.TealBg else C.Border),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(painterResource(R.drawable.ic_car), contentDescription = null,
                        tint = if (active) C.Teal else C.Muted, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (active) "מצב נהיגה פעיל" else "ממתין לרכב", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        when {
                            carName == null -> "עוד לא נבחר רכב בהגדרות"
                            active -> "מחובר: $carName"
                            else -> "יופעל לבד כשתתחבר ל-$carName"
                        },
                        color = C.Muted, fontSize = 15.sp
                    )
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(C.Border))
            ToggleRow("הקראה אוטומטית", "בלי שאלות, המוזיקה חוזרת לבד", autoRead) {
                autoRead = it; Prefs.autoRead = it
            }
            Text(
                if (active) "סיים נהיגה ידנית" else "הפעל מצב נהיגה ידנית (לבדיקה)",
                color = C.Amber, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { if (active) DriveState.stop(ctx) else DriveState.start(ctx) }
                    .padding(vertical = 6.dp)
            )
        }

        Text("הוקרא לאחרונה", color = C.Muted, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        if (history.isEmpty()) {
            Text("עוד לא הוקראו הודעות. בהגדרות יש כפתור „הודעת בדיקה“.", color = C.Muted, fontSize = 15.sp,
                modifier = Modifier.weight(1f))
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(history) { h -> HistoryRow(h) }
            }
        }

        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.size(96.dp).clip(CircleShape).background(C.Amber).clickable { Announcer.listenCommand() },
                contentAlignment = Alignment.Center
            ) {
                Icon(painterResource(R.drawable.ic_mic), contentDescription = "דבר אליי", tint = C.OnAmber, modifier = Modifier.size(40.dp))
            }
            Text("לחץ ודבר: „השיר הבא“, „נווטי הביתה“…", color = C.Muted, fontSize = 14.sp)
        }
    }
}

@Composable
private fun HistoryRow(h: HistoryItem) {
    val time = remember(h.time) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(h.time)) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.Surface).padding(16.dp),
        verticalAlignment = Alignment.Top
    ) {
        Avatar(h.sender, 44.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(h.sender, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f, fill = false))
                Spacer(Modifier.width(8.dp))
                Text("${h.app} · $time", color = C.Muted, fontSize = 13.sp)
            }
            Text(h.text, color = C.Soft, fontSize = 15.sp, maxLines = 2)
        }
    }
}

// ------------------------------------------------------------------
// הגדרות
// ------------------------------------------------------------------
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val tick by UiBus.tick.collectAsState()
    var localTick by remember { mutableStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        localTick++
    }
    val key = tick + localTick

    val runtimeOk = remember(key) { Perms.runtimeOk(ctx) }
    val listenerOk = remember(key) { Perms.listenerOk(ctx) }
    val overlayOk = remember(key) { Perms.overlayOk(ctx) }
    val batteryOk = remember(key) { Perms.batteryOk(ctx) }
    val devices = remember(key) { Perms.bondedDevices(ctx) }
    var carAddress by remember { mutableStateOf(Prefs.carAddress) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(C.Surface)
                    .border(1.dp, C.Border, CircleShape).clickable { onBack() },
                contentAlignment = Alignment.Center
            ) {
                Icon(painterResource(R.drawable.ic_back), contentDescription = "חזרה", tint = C.Text, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Text("הגדרות", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }

        // ---- הרשאות ----
        SectionTitle("הרשאות")
        CardBox(padding = 16.dp) {
            PermRow("גישה להתראות", "כדי לקרוא הודעות ולשלוט במוזיקה", listenerOk) {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            PermRow("מיקרופון, בלוטוס, אנשי קשר וטלפון", "לפקודות קוליות ולזיהוי הרכב", runtimeOk) {
                launcher.launch(Perms.runtimeList())
            }
            PermRow("הצגה מעל אפליקציות אחרות", "כדי שמסך ההקראה יקפוץ בזמן נהיגה", overlayOk) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
            }
            PermRow("ללא הגבלת סוללה", "כדי שאנדרואיד לא ירדים את האפליקציה", batteryOk) {
                @SuppressLint("BatteryLife")
                val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
                try { ctx.startActivity(i) } catch (e: Exception) { }
            }
        }

        // ---- רכב ----
        SectionTitle("הרכב שלך")
        CardBox(padding = 16.dp) {
            if (devices.isEmpty()) {
                Text("אשר קודם את הרשאת הבלוטוס, ואז יופיעו כאן המכשירים המחוברים לטלפון.", color = C.Muted, fontSize = 15.sp)
            }
            devices.forEach { (name, addr) ->
                val selected = addr == carAddress
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (selected) C.TealBg else Color.Transparent)
                        .clickable {
                            carAddress = addr; Prefs.carAddress = addr; Prefs.carName = name
                        }
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(painterResource(R.drawable.ic_car), null, tint = if (selected) C.Teal else C.Muted, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(name, fontSize = 17.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        color = if (selected) C.Teal else C.Text, modifier = Modifier.weight(1f))
                    if (selected) Icon(painterResource(R.drawable.ic_check), null, tint = C.Teal, modifier = Modifier.size(20.dp))
                }
            }
        }

        // ---- אפליקציות ----
        SectionTitle("אפליקציות להקראה")
        CardBox(padding = 16.dp) {
            SupportedApps.all.forEach { def ->
                var on by remember { mutableStateOf(Prefs.appEnabled(def)) }
                ToggleRow(def.label, def.sub, on) { on = it; Prefs.setAppEnabled(def, it) }
            }
        }

        // ---- הקראה חכמה ----
        SectionTitle("הקראה חכמה")
        CardBox(padding = 16.dp) {
            PrefToggle("איחוד הודעות", "„3 הודעות מדני“ במקום שלוש הקראות", { Prefs.groupMessages }) { Prefs.groupMessages = it }
            PrefToggle("מיילים מקוצרים", "רק שולח ונושא", { Prefs.shortEmails }) { Prefs.shortEmails = it }
            PrefToggle("שקט בזמן שיחה", "ההודעות יחכו לסוף השיחה ויסוכמו", { Prefs.silentInCalls }) { Prefs.silentInCalls = it }
            PrefToggle("הנמכה במקום עצירה", "המוזיקה ממשיכה בשקט ברקע", { Prefs.duck }) { Prefs.duck = it }
            PrefToggle("הכרזה בכניסה לרכב", "„מצב נהיגה פעיל“", { Prefs.announceStart }) { Prefs.announceStart = it }
        }

        // ---- תגובות ----
        SectionTitle("תגובות")
        CardBox(padding = 16.dp) {
            PrefToggle("תגובה קולית", "אחרי הקראה אפשר לומר „תעני לו…“", { Prefs.voiceReply }) { Prefs.voiceReply = it }
            PrefToggle("שליחה אוטומטית", "נשלחת אלא אם אמרת „בטל“", { Prefs.autoSend }) { Prefs.autoSend = it }
            PrefToggle("הקראת התגובה לפני שליחה", "כדי לוודא שהיא שמעה נכון", { Prefs.readBack }) { Prefs.readBack = it }
        }

        // ---- קול ----
        SectionTitle("קול")
        CardBox(padding = 16.dp) {
            var rate by remember { mutableFloatStateOf(Prefs.speechRate) }
            Row {
                Text("מהירות הקראה", fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Text(
                    when {
                        rate < 0.85f -> "איטית"
                        rate > 1.2f -> "מהירה"
                        else -> "רגילה"
                    },
                    color = C.Amber, fontWeight = FontWeight.Bold
                )
            }
            Slider(
                value = rate, onValueChange = { rate = it }, valueRange = 0.6f..1.6f,
                onValueChangeFinished = { Prefs.speechRate = rate },
                colors = SliderDefaults.colors(thumbColor = C.Amber, activeTrackColor = C.Amber, inactiveTrackColor = C.Border)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton("בדיקת קול", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) {
                    Prefs.speechRate = rate; Announcer.testVoice()
                }
                BigButton("הודעת בדיקה", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) {
                    Announcer.testMessage()
                }
            }
        }

        Text(
            "קול בדרך · גרסה ${BuildConfigHelper.version(ctx)}",
            color = C.Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
        )
    }
}

@Composable
private fun PrefToggle(title: String, sub: String, get: () -> Boolean, set: (Boolean) -> Unit) {
    var v by remember { mutableStateOf(get()) }
    ToggleRow(title, sub, v) { v = it; set(it) }
}

@Composable
private fun PermRow(title: String, sub: String, ok: Boolean, onFix: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = !ok) { onFix() }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = C.Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.width(10.dp))
        if (ok) {
            Icon(painterResource(R.drawable.ic_check), contentDescription = "מאושר", tint = C.Teal, modifier = Modifier.size(24.dp))
        } else {
            Text(
                "אשר", color = C.OnAmber, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(C.Amber)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
    }
}

object BuildConfigHelper {
    fun version(c: Context): String = try {
        c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }
}
