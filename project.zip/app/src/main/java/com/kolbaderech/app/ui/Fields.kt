package com.kolbaderech.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PrefToggle(title: String, sub: String?, get: () -> Boolean, set: (Boolean) -> Unit) {
    var v by remember { mutableStateOf(get()) }
    ToggleRow(title, sub, v) { v = it; set(it) }
}

@Composable
fun PrefText(
    title: String,
    hint: String,
    get: () -> String,
    set: (String) -> Unit,
    multiline: Boolean = false,
    secret: Boolean = false,
    ltr: Boolean = false
) {
    var v by remember { mutableStateOf(get()) }
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, color = C.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        OutlinedTextField(
            value = v,
            onValueChange = { v = it; set(it) },
            placeholder = { Text(hint, color = C.Muted, fontSize = 14.sp) },
            singleLine = !multiline,
            minLines = if (multiline) 3 else 1,
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            textStyle = if (ltr || secret) androidx.compose.ui.text.TextStyle(textDirection = androidx.compose.ui.text.style.TextDirection.Ltr)
            else androidx.compose.ui.text.TextStyle.Default,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = C.Amber, unfocusedBorderColor = C.Border,
                focusedTextColor = C.Text, unfocusedTextColor = C.Text, cursorColor = C.Amber,
                focusedContainerColor = C.Surface2, unfocusedContainerColor = C.Surface2,
                selectionColors = androidx.compose.foundation.text.selection.TextSelectionColors(
                    handleColor = C.Amber, backgroundColor = C.Amber.copy(alpha = 0.3f)
                )
            )
        )
    }
}

@Composable
fun PrefChoice(title: String, options: List<Pair<String, String>>, get: () -> String, set: (String) -> Unit) {
    var v by remember { mutableStateOf(get()) }
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = C.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (key, label) ->
                val sel = key == v
                val shape = RoundedCornerShape(16.dp)
                Text(
                    label, fontSize = 15.sp,
                    color = if (sel) C.OnAmber else C.Text,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.clip(shape)
                        .background(if (sel) C.brand else androidx.compose.ui.graphics.SolidColor(C.Surface2))
                        .border(1.dp, if (sel) androidx.compose.ui.graphics.Color.Transparent else C.Border, shape)
                        .clickable(role = androidx.compose.ui.semantics.Role.RadioButton) { v = key; set(key) }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                )
            }
        }
    }
}

@Composable
fun PrefSlider(
    title: String,
    range: ClosedFloatingPointRange<Float>,
    get: () -> Float,
    set: (Float) -> Unit,
    label: (Float) -> String
) {
    var v by remember { mutableFloatStateOf(get()) }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = C.Text, modifier = Modifier.weight(1f))
            Text(
                label(v), color = C.Amber, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(C.AmberBg)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        Slider(
            value = v, onValueChange = { v = it }, valueRange = range,
            onValueChangeFinished = { set(v) },
            colors = SliderDefaults.colors(thumbColor = C.Amber, activeTrackColor = C.Amber, inactiveTrackColor = C.Border)
        )
    }
}
