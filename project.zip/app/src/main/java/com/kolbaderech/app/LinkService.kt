package com.kolbaderech.app

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** במסך הרכב: שומר על חיבור קבוע לטלפון. */
class LinkService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Notification.Builder(this, "drive")
            .setSmallIcon(R.drawable.ic_car)
            .setContentTitle("קול בדרך")
            .setContentText("מחובר לטלפון דרך הנקודה החמה")
            .setOngoing(true)
            .build()
        val mic = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
        try {
            when {
                Build.VERSION.SDK_INT >= 34 -> {
                    try {
                        startForeground(
                            2, n,
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                                (if (mic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
                        )
                    } catch (e: Throwable) {
                        startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                    }
                }
                Build.VERSION.SDK_INT >= 30 -> startForeground(
                    2, n,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE or
                        (if (mic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
                )
                Build.VERSION.SDK_INT >= 29 -> startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
                else -> startForeground(2, n)
            }
        } catch (e: Throwable) {
        }
        Link.startClient(this)
        return START_STICKY
    }
}
