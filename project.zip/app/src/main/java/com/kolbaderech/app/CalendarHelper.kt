package com.kolbaderech.app

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

object CalendarHelper {
    private fun granted(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun events(c: Context, dayOffset: Int, limit: Int = 5): List<Pair<String, Long>>? {
        if (!granted(c, Manifest.permission.READ_CALENDAR)) return null
        val start = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, dayOffset)
            if (dayOffset != 0) {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            }
        }
        val end = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, dayOffset)
            set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59)
        }
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also {
            ContentUris.appendId(it, start.timeInMillis)
            ContentUris.appendId(it, end.timeInMillis)
        }.build()
        val out = ArrayList<Pair<String, Long>>()
        try {
            c.contentResolver.query(
                uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
                null, null, "${CalendarContract.Instances.BEGIN} ASC"
            )?.use { cur ->
                while (cur.moveToNext() && out.size < limit) {
                    if (cur.getInt(2) == 1) continue
                    out.add((cur.getString(0) ?: "אירוע") to cur.getLong(1))
                }
            }
        } catch (e: Exception) {
            return null
        }
        return out
    }

    fun describe(c: Context, dayOffset: Int): String {
        val list = events(c, dayOffset) ?: return "צריך לאשר גישה ליומן בהגדרות האפליקציה"
        val day = if (dayOffset == 0) "היום" else "מחר"
        if (list.isEmpty()) return "אין לך פגישות $day"
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        return "$day יש לך ${list.size} פגישות: " + list.joinToString(". ") { "${it.first} ב-${fmt.format(it.second)}" }
    }

    fun firstToday(c: Context): String? {
        val list = events(c, 0, 1) ?: return null
        val e = list.firstOrNull() ?: return null
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        return "הפגישה הבאה שלך: ${e.first} ב-${fmt.format(e.second)}"
    }

    fun add(c: Context, title: String, startMillis: Long): String {
        if (!granted(c, Manifest.permission.WRITE_CALENDAR) || !granted(c, Manifest.permission.READ_CALENDAR))
            return "צריך לאשר גישה ליומן בהגדרות האפליקציה"
        var calId = -1L
        try {
            c.contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI,
                arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY),
                "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ${CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR} AND ${CalendarContract.Calendars.VISIBLE} = 1",
                null, null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    if (calId == -1L) calId = cur.getLong(0)
                    if (cur.getInt(1) == 1) {
                        calId = cur.getLong(0); break
                    }
                }
            }
        } catch (e: Exception) {
        }
        if (calId == -1L) return "לא מצאתי יומן לכתוב אליו"
        return try {
            val v = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calId)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DTSTART, startMillis)
                put(CalendarContract.Events.DTEND, startMillis + 60 * 60_000)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            }
            c.contentResolver.insert(CalendarContract.Events.CONTENT_URI, v)
            val fmt = SimpleDateFormat("EEEE בשעה HH:mm", Locale("he"))
            "קבעתי: $title, ${fmt.format(startMillis)}"
        } catch (e: Exception) {
            "לא הצלחתי להוסיף ליומן"
        }
    }
}
