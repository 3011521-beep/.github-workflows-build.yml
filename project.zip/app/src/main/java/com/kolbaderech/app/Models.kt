package com.kolbaderech.app

import android.app.Notification
import kotlinx.coroutines.flow.MutableStateFlow

data class Msg(
    val pkg: String,
    val app: String,
    val sender: String,
    val text: String,
    val body: String,
    val isEmail: Boolean,
    val reply: Notification.Action?,
    val urgent: Boolean,
    val time: Long = System.currentTimeMillis()
)

data class HistoryItem(val sender: String, val app: String, val text: String, val time: Long)

sealed class UiState {
    object Idle : UiState()
    data class Reading(
        val sender: String,
        val app: String,
        val lines: List<String>,
        val canReply: Boolean,
        val queueLeft: Int
    ) : UiState()
    data class Listening(val title: String, val heard: String?) : UiState()
    data class ConfirmReply(
        val sender: String,
        val app: String,
        val original: String,
        val reply: String,
        val autoSend: Boolean
    ) : UiState()
    data class Info(val text: String) : UiState()
}

data class AppDef(val pkg: String, val label: String, val sub: String, val isEmail: Boolean, val defaultOn: Boolean)

object SupportedApps {
    val all = listOf(
        AppDef("com.whatsapp", "וואטסאפ", "הודעות פרטיות וקבוצות", false, true),
        AppDef("com.whatsapp.w4b", "וואטסאפ ביזנס", "הודעות עסקיות", false, true),
        AppDef("com.google.android.gm", "Gmail", "שולח ונושא", true, true),
        AppDef("com.microsoft.office.outlook", "Outlook", "שולח ונושא", true, true),
        AppDef("com.google.android.apps.messaging", "הודעות", "SMS", false, true),
        AppDef("com.samsung.android.messaging", "הודעות סמסונג", "SMS", false, true),
        AppDef("org.telegram.messenger", "טלגרם", "הודעות טלגרם", false, false),
        AppDef("com.facebook.orca", "מסנג'ר", "הודעות פייסבוק", false, false)
    )
    fun find(pkg: String) = all.firstOrNull { it.pkg == pkg }
}

object UiBus {
    val tick = MutableStateFlow(0)
}
