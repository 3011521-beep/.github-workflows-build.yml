package com.kolbaderech.app

import android.app.Notification
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.util.UUID

data class Msg(
    val id: String = UUID.randomUUID().toString(),
    val pkg: String,
    val app: String,
    val sender: String,
    val text: String,
    val body: String = "",
    val isEmail: Boolean = false,
    val reply: Notification.Action? = null,
    val urgent: Boolean = false,
    val isGroup: Boolean = false,
    val remote: Boolean = false,
    val remoteCanReply: Boolean = false,
    val notice: Boolean = false,
    val time: Long = System.currentTimeMillis()
) {
    val canReply: Boolean get() = reply != null || remoteCanReply

    fun toJson(): JSONObject = JSONObject()
        .put("t", "msg").put("id", id).put("pkg", pkg).put("app", app).put("sender", sender)
        .put("text", text).put("body", body).put("isEmail", isEmail).put("canReply", reply != null)
        .put("urgent", urgent).put("isGroup", isGroup)

    companion object {
        fun notice(text: String) = Msg(pkg = "notice", app = "", sender = "", text = text, notice = true)

        fun fromJson(o: JSONObject) = Msg(
            id = o.optString("id"), pkg = o.optString("pkg"), app = o.optString("app"),
            sender = o.optString("sender"), text = o.optString("text"), body = o.optString("body"),
            isEmail = o.optBoolean("isEmail"), urgent = o.optBoolean("urgent"),
            isGroup = o.optBoolean("isGroup"), remote = true, remoteCanReply = o.optBoolean("canReply")
        )
    }
}

data class HistoryItem(val sender: String, val app: String, val text: String, val time: Long)

sealed class UiState {
    object Idle : UiState()
    data class Reading(
        val sender: String,
        val app: String,
        val lines: List<String>,
        val canReply: Boolean,
        val queueLeft: Int
    ) : UiState()
    data class Listening(val title: String, val heard: String?) : UiState()
    data class ConfirmReply(
        val sender: String,
        val app: String,
        val original: String,
        val reply: String,
        val autoSend: Boolean
    ) : UiState()
    data class Info(val text: String) : UiState()
}

data class AppDef(val pkg: String, val label: String, val sub: String, val isEmail: Boolean, val defaultOn: Boolean)

object SupportedApps {
    val all = listOf(
        AppDef("com.whatsapp", "וואטסאפ", "הודעות פרטיות וקבוצות", false, true),
        AppDef("com.whatsapp.w4b", "וואטסאפ ביזנס", "הודעות עסקיות", false, true),
        AppDef("com.google.android.gm", "Gmail", "שולח ונושא", true, true),
        AppDef("com.microsoft.office.outlook", "Outlook", "שולח ונושא", true, true),
        AppDef("com.google.android.apps.messaging", "הודעות", "SMS", false, true),
        AppDef("com.samsung.android.messaging", "הודעות סמסונג", "SMS", false, true),
        AppDef("org.telegram.messenger", "טלגרם", "הודעות טלגרם", false, true),
        AppDef("com.facebook.orca", "מסנג'ר", "הודעות פייסבוק", false, true),
        AppDef("com.instagram.android", "אינסטגרם", "הודעות ישירות", false, false),
        AppDef("org.thoughtcrime.securesms", "סיגנל", "הודעות סיגנל", false, true)
    )

    fun find(pkg: String) = all.firstOrNull { it.pkg == pkg }
}

object UiBus {
    val tick = MutableStateFlow(0)
}
