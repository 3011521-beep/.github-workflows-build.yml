package com.kolbaderech.app

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** פותח את אפליקציית השער (PalGate) ולוחץ בשבילך על כפתור הפתיחה. */
class GateService : AccessibilityService() {
    companion object {
        @Volatile var armedUntil = 0L

        // לחיצה אוטומטית כללית (למשל: "נגן" על התוצאה הראשונה ביוטיוב מיוזיק)
        @Volatile var tapPkg: String? = null
        @Volatile var tapWords: List<String> = emptyList()
        @Volatile var tapUntil = 0L
        @Volatile var tapGoHome = false
        var onTapped: (() -> Unit)? = null

        fun armTap(pkg: String, words: List<String>, seconds: Int, goHome: Boolean, done: (() -> Unit)? = null) {
            tapPkg = pkg; tapWords = words; tapGoHome = goHome; onTapped = done
            tapUntil = System.currentTimeMillis() + seconds * 1000L
        }

        fun isEnabled(c: Context): Boolean {
            val list = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val me = ComponentName(c, GateService::class.java).flattenToString()
            return list.split(':').any { it.equals(me, ignoreCase = true) }
        }
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val evPkg = event?.packageName?.toString() ?: return
        if (System.currentTimeMillis() <= tapUntil && evPkg == tapPkg) {
            val root = rootInActiveWindow ?: return
            for (w in tapWords) {
                var node: AccessibilityNodeInfo? = root.findAccessibilityNodeInfosByText(w)?.firstOrNull()
                while (node != null && !node.isClickable) node = node.parent
                if (node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    tapUntil = 0
                    val cb = onTapped
                    onTapped = null
                    cb?.let { f -> handler.post { f() } }
                    if (tapGoHome) handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 1500)
                    return
                }
            }
            return
        }
        if (System.currentTimeMillis() > armedUntil) return
        val pkg = evPkg
        if (pkg != Prefs.gatePkg) return
        val root = rootInActiveWindow ?: return
        val words = Prefs.list(Prefs.gateButtonText)
        var node: AccessibilityNodeInfo? = null
        for (w in words) {
            node = root.findAccessibilityNodeInfosByText(w)?.firstOrNull()
            if (node != null) break
        }
        var target = node
        while (target != null && !target.isClickable) target = target.parent
        if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            armedUntil = 0
            Out.say("השער נפתח")
            handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 2500)
        }
    }

    override fun onInterrupt() {}
}

object Gate {
    fun open(c: Context): String {
        val pkg = Prefs.gatePkg
        if (pkg.isBlank()) return "צריך לבחור את אפליקציית השער בהגדרות"
        if (!GateService.isEnabled(c)) return "צריך להפעיל את נוגה בהגדרות הנגישות כדי לפתוח את השער"
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return "אפליקציית השער לא מותקנת"
        GateService.armedUntil = System.currentTimeMillis() + 20_000
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            c.startActivity(i)
            "פותחת את השער"
        } catch (e: Exception) {
            "לא הצלחתי לפתוח את אפליקציית השער"
        }
    }
}
