package com.kolbaderech.app

import android.app.Notification
import android.app.Person
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {

    companion object {
        @Volatile var instance: NotifListener? = null
        private val autoReplied = HashSet<String>()
        private val groupCounts = HashMap<String, Int>()
        private val groupLast = HashMap<String, Long>()

        fun onDriveStart() {
            autoReplied.clear()
            groupCounts.clear()
            groupLast.clear()
        }

        /** סיכום הודעות שעדיין לא נקראו (עדיין מוצגות בטלפון). */
        fun unreadSummary(): String? {
            val l = instance ?: return null
            val active = try {
                l.activeNotifications
            } catch (e: Exception) {
                null
            } ?: return null
            val counts = LinkedHashMap<String, Int>()
            for (sbn in active) {
                val def = SupportedApps.find(sbn.packageName) ?: continue
                if (!Prefs.appEnabled(def)) continue
                if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) continue
                if (sbn.isOngoing) continue
                counts[def.label] = (counts[def.label] ?: 0) + 1
            }
            if (counts.isEmpty()) return null
            val parts = counts.map { (app, n) -> if (n == 1) "אחת ב$app" else "$n ב$app" }
            return "מחכות לך הודעות שלא נקראו: " + parts.joinToString(", ")
        }
    }

    private val main = Handler(Looper.getMainLooper())

    override fun onListenerConnected() {
        instance = this
        if (!Prefs.isCar) {
            Link.startServer(applicationContext)
            CallMonitor.register(applicationContext)
        }
    }

    override fun onListenerDisconnected() {
        instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (e: Exception) {
        }
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private val skipPkgs = setOf("android", "com.android.systemui", "com.android.providers.downloads", "com.google.android.gms")

    private fun handle(sbn: StatusBarNotification) {
        if (Prefs.isCar) return
        val pkg = sbn.packageName
        if (pkg == packageName || pkg in skipPkgs) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (sbn.isOngoing) return
        if (n.category in setOf(
                Notification.CATEGORY_PROGRESS, Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM,
                Notification.CATEGORY_STATUS, Notification.CATEGORY_ERROR, Notification.CATEGORY_TRANSPORT,
                Notification.CATEGORY_NAVIGATION, Notification.CATEGORY_CALL
            )
        ) return

        val def = SupportedApps.find(pkg)
        // כל אפליקציה ששולחת התראות נרשמת, כדי שאפשר יהיה להפעיל אותה בהגדרות
        if (def == null && pkg !in Store.seenPackages) {
            Store.seenPackages = (Store.seenPackages + pkg).toList().takeLast(80).toSet()
        }
        val enabled = if (def != null) Prefs.appEnabled(def) else pkg in Prefs.extraApps
        if (!enabled) return
        if (!DriveState.active.value) return

        val kind = def?.kind ?: "app"
        // תיקייה מאובטחת / פרופיל עבודה (סמסונג): משתמש אחר באותו טלפון
        val uid = try { sbn.user.hashCode() } catch (e: Throwable) { 0 }
        val where = when {
            uid == 0 -> ""
            uid >= 150 -> " בתיקייה המאובטחת"
            else -> " בפרופיל העבודה"
        }
        val isEmail = kind == "email"
        val ex = n.extras
        var title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        var text = (ex.getCharSequence(Notification.EXTRA_TEXT) ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))
            ?.toString()?.trim() ?: ""
        var body = ""
        var isGroup = false
        var groupName: String? = null
        val realMsg = ex.containsKey(Notification.EXTRA_MESSAGES)
        var stamp = ""

        when (kind) {
            "email" -> {
                val big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim() ?: ""
                body = big.removePrefix(text).trim()
            }
            "msg" -> {
                if (!realMsg && n.category != Notification.CATEGORY_MESSAGE) return
                @Suppress("DEPRECATION")
                val msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
                val last = msgs?.lastOrNull() as? Bundle
                if (last != null) {
                    last.getCharSequence("text")?.toString()?.let { text = it.trim() }
                    val tm = last.getLong("time", 0L)
                    if (tm > 0) stamp = tm.toString()
                    var sender = last.getCharSequence("sender")?.toString()
                    if (sender == null && Build.VERSION.SDK_INT >= 28) {
                        @Suppress("DEPRECATION")
                        sender = (last.getParcelable<android.os.Parcelable>("sender_person") as? Person)?.name?.toString()
                    }
                    isGroup = ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)
                    groupName = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
                    if (isGroup && groupName != null && sender != null) {
                        title = "$sender בקבוצת $groupName"
                    } else if (!sender.isNullOrBlank()) {
                        title = sender
                    }
                }
                val label = def?.label ?: appLabel(pkg)
                if ((title.equals(label, ignoreCase = true) || title.equals("WhatsApp", ignoreCase = true)) && !realMsg) return
            }
        }

        if (title.isBlank() && text.isBlank()) return
        if (isSystemText(text, realMsg) || isSystemText(title, realMsg)) return
        if (ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0) > 0 || ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)) return

        if (Prefs.spamFilter) {
            val lower = ("$title $text").lowercase()
            if (Prefs.list(Prefs.spamWords).any { lower.contains(it.lowercase()) }) return
        }

        // ---------- לא להקריא פעמיים את אותו דבר ----------
        if (Seen.alreadyRead(kind, "$pkg@$uid", title, text, body, stamp)) return
        val isVoiceNote = kind == "msg" && VoiceNotes.isVoice(text)

        val actions = n.actions ?: emptyArray()
        val reply = actions.firstOrNull {
            Build.VERSION.SDK_INT >= 28 && it.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY &&
                !it.remoteInputs.isNullOrEmpty()
        } ?: actions.firstOrNull { !it.remoteInputs.isNullOrEmpty() }

        val vip = Prefs.list(Prefs.vipNames).any { title.contains(it) }
        val urgent = vip || text.contains("דחוף")
        val appName = (def?.label ?: appLabel(pkg)) + where

        if (kind == "msg" && Prefs.autoReplyDriving && reply != null && !isGroup && autoReplied.add("$pkg|$title")) {
            Reply.send(applicationContext, Msg(pkg = pkg, app = appName, sender = title, text = "", reply = reply), Prefs.autoReplyText)
        }

        if (isGroup && !vip) {
            when (Prefs.groupMode) {
                "none" -> return
                "mentions" -> {
                    val me = Prefs.myName.trim()
                    if (!(text.contains("@") || (me.isNotEmpty() && text.contains(me)))) return
                }
                "summary" -> {
                    summarize(groupName ?: title, appName)
                    return
                }
            }
        }
        if (Prefs.vipOnly && !vip && kind == "msg") {
            summarize("others", appName)
            return
        }

        val m = Msg(
            pkg = pkg, app = appName, sender = title.ifBlank { appName }, text = text, body = body,
            isEmail = isEmail, reply = if (kind == "msg") reply else null, urgent = urgent, isGroup = isGroup,
            kind = if (isVoiceNote) "voice" else kind
        )
        Pipeline.process(applicationContext, m)
    }

    private fun summarize(group: String, app: String) {
        val now = System.currentTimeMillis()
        groupCounts[group] = (groupCounts[group] ?: 0) + 1
        val last = groupLast[group] ?: 0L
        if (now - last < 10 * 60_000) return
        val count = groupCounts[group] ?: 1
        groupCounts[group] = 0
        groupLast[group] = now
        val txt = if (group == "others") {
            if (count == 1) "הודעה חדשה ב$app" else "$count הודעות חדשות"
        } else {
            if (count == 1) "הודעה חדשה בקבוצת $group" else "$count הודעות חדשות בקבוצת $group"
        }
        main.post { Out.say(txt) }
    }

    private fun isSystemText(t: String, realMsg: Boolean): Boolean {
        val l = t.lowercase()
        if (realMsg) return Regex("^\\d+ (new messages|הודעות חדשות)").containsMatchIn(t)
        val junk = listOf(
            "checking for new messages", "מחפש הודעות", "בודק הודעות", "בודק אם יש הודעות",
            "גיבוי", "מגבה", "backup", "backing up", "משחזר", "restoring",
            "מעלה", "uploading", "מוריד", "downloading", "מתחבר", "connecting",
            "whatsapp web", "וואטסאפ ווב", "is active", "פעיל במכשיר", "sending", "שולח…"
        )
        if (junk.any { l.contains(it) }) return true
        if (Regex("^\\d+ (new messages|הודעות חדשות)").containsMatchIn(t)) return true
        return false
    }
}

/** עיבוד לפני הקראה: תרגום וסיכום, ואז הקראה בטלפון או העברה למסך הרכב. */
object Pipeline {
    private val main = Handler(Looper.getMainLooper())

    fun process(app: android.content.Context, m: Msg) {
        if (m.kind == "voice") {
            val since = System.currentTimeMillis()
            if (!Prefs.voiceNotes) {
                deliver(m); return
            }
            // וואטסאפ שומר את הקובץ שניה-שתיים אחרי ההתראה
            main.postDelayed({
                Thread {
                    var f = VoiceNotes.findLatest(app, since)
                    if (f == null) {
                        try { Thread.sleep(2500) } catch (e: InterruptedException) { }
                        f = VoiceNotes.findLatest(app, since)
                    }
                    val path = f?.absolutePath
                    main.post { deliver(m.copy(audio = path)) }
                }.start()
            }, 1500)
            return
        }
        if (Prefs.translate && !m.isEmail && Translate.needs(m.text)) {
            var done = false
            val finish = { t: String? ->
                if (!done) {
                    done = true
                    val next = if (t != null) m.copy(text = "(מתורגם) $t") else m
                    summarizeThenDeliver(next)
                }
            }
            main.postDelayed({ finish(null) }, 6000)
            Translate.run(m.text) { t -> main.post { finish(t) } }
            return
        }
        summarizeThenDeliver(m)
    }

    private fun summarizeThenDeliver(m: Msg) {
        if (Prefs.summarizeLong && Gemini.available() && !m.isEmail && m.text.length > 400) {
            var done = false
            val finish = { s: String? ->
                if (!done) {
                    done = true
                    deliver(if (s != null) m.copy(text = "סיכום: $s") else m)
                }
            }
            main.postDelayed({ finish(null) }, 8000)
            Gemini.summarize(m.text) { s -> finish(s) }
            return
        }
        deliver(m)
    }

    private fun deliver(m: Msg) {
        Relay.remember(m)
        if (!Prefs.isCar && Link.connected.value) {
            Announcer.remember(m)
            Announcer.addHistory(m.sender, m.app, m.text, m.pkg, m.id, m.canReply)
            Store.inc("messages")
            Relay.forward(m)
        } else {
            Announcer.enqueue(m)
        }
    }
}

/** אומר משפט במכשיר הנכון: במסך הרכב אם הוא מחובר, אחרת בטלפון. */
object Out {
    fun say(text: String) {
        if (!Prefs.isCar && Link.connected.value) Link.send(Link.obj("say", "text" to text))
        else Announcer.notice(text)
    }
}
