package com.kolbaderech.app

import org.json.JSONObject

/** ספר רכב: קילומטראז׳ משוער (לפי GPS), טיפולים ותזכורות לטיפול. */
object CarBook {
    fun gpsKm(): Double = Store.count("gps_m") / 1000.0

    fun odometer(): Double? {
        val base = Prefs.odoBase.toDoubleOrNull() ?: return null
        return base + (gpsKm() - (Prefs.odoBaseGpsKm.toDoubleOrNull() ?: 0.0))
    }

    fun setOdometer(km: Double) {
        Prefs.odoBase = km.toString()
        Prefs.odoBaseGpsKm = gpsKm().toString()
    }

    fun interval(): Double = Prefs.serviceInterval.toDoubleOrNull() ?: 15000.0

    fun nextServiceOdo(): Double? = Prefs.lastServiceOdo.toDoubleOrNull()?.let { it + interval() }

    fun kmToService(): Double? {
        val o = odometer() ?: return null
        val n = nextServiceOdo() ?: return null
        return n - o
    }

    fun serviceDone(note: String): String {
        val o = odometer()
        Store.add(
            Store.SERVICE,
            JSONObject().put("time", System.currentTimeMillis()).put("odo", o ?: -1.0).put("note", note)
        )
        if (o == null) return "רשמתי טיפול. כדי לחשב את הטיפול הבא, הגדר את הקילומטראז׳ הנוכחי בהגדרות או אמור „הקילומטראז׳ עכשיו…“"
        Prefs.lastServiceOdo = o.toString()
        return "רשמתי טיפול ב-${o.toInt()} קילומטר. הטיפול הבא ב-${(o + interval()).toInt()}"
    }

    fun status(): String {
        val o = odometer() ?: return "עוד לא הוגדר קילומטראז׳. אמור למשל „הקילומטראז׳ עכשיו 85000“"
        val left = kmToService()
        val base = "הרכב עומד על כ-${o.toInt()} קילומטר"
        return when {
            left == null -> "$base. לא נרשם טיפול אחרון"
            left < 0 -> "$base. עברת את מועד הטיפול ב-${(-left).toInt()} קילומטר"
            else -> "$base. נשארו ${left.toInt()} קילומטר עד הטיפול הבא"
        }
    }

    /** התראה בכניסה לרכב אם הטיפול קרוב. */
    fun alert(): String? {
        val left = kmToService() ?: return null
        return when {
            left < 0 -> "שים לב, עברת את מועד הטיפול ב-${(-left).toInt()} קילומטר"
            left <= 1000 -> "בעוד ${left.toInt()} קילומטר צריך טיפול לרכב"
            else -> null
        }
    }
}
