package com.kolbaderech.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * מילת הפעלה ("היי דני") עם Vosk: קוד פתוח, חינמי, בלי הרשמה ובלי אינטרנט.
 * מאזין כל הזמן במסך הרכב בלי לעצור מוזיקה, ומושהה בזמן שהעוזרת מדברת או מקשיבה.
 * בפעם הראשונה מוריד מודל זיהוי באנגלית (כ-40MB).
 */
object Wake {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private val handler = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var service: SpeechService? = null
    private var appCtx: Context? = null
    @Volatile private var running = false
    private var preparing = false
    private var lastWake = 0L
    val status = MutableStateFlow("כבוי")

    fun configured() = Prefs.wakeEnabled

    private fun shouldRun() = Prefs.isCar && Prefs.wakeEnabled && DriveState.active.value

    private fun phrases(): List<String> =
        Prefs.list(Prefs.wakePhrase.lowercase()).ifEmpty { listOf("hey danny") }

    fun start(ctx: Context) {
        if (!shouldRun() || Announcer.isActive() || running) return
        val app = ctx.applicationContext
        appCtx = app
        if (app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.value = "חסרה הרשאת מיקרופון"
            return
        }
        val m = model
        if (m == null) {
            prepare(app)
            return
        }
        try {
            val grammar = JSONArray(phrases() + "[unk]").toString()
            val rec = Recognizer(m, 16000.0f, grammar)
            val s = SpeechService(rec, 16000.0f)
            s.startListening(listener)
            service = s
            running = true
            status.value = "מאזין ל-„${phrases().first()}“"
        } catch (e: Exception) {
            running = false
            status.value = "שגיאה: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    fun stop() {
        val s = service
        service = null
        running = false
        if (s != null) {
            try {
                s.stop()
                s.shutdown()
            } catch (e: Exception) {
            }
        }
        if (status.value.startsWith("מאזין")) status.value = "מושהה"
    }

    fun release() = stop()

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) = check(hypothesis, "partial")
        override fun onResult(hypothesis: String?) = check(hypothesis, "text")
        override fun onFinalResult(hypothesis: String?) {}
        override fun onError(exception: Exception?) {
            stop()
            status.value = "שגיאה, מנסה שוב"
            handler.postDelayed({ appCtx?.let { start(it) } }, 3000)
        }
        override fun onTimeout() {}
    }

    private fun check(json: String?, key: String) {
        val text = try {
            JSONObject(json ?: return).optString(key)
        } catch (e: Exception) {
            return
        }
        if (text.isBlank()) return
        if (phrases().any { text.contains(it) }) {
            val now = System.currentTimeMillis()
            if (now - lastWake < 2000) return
            lastWake = now
            handler.post {
                stop()
                Announcer.listenCommand()
            }
        }
    }

    // ------------------------------------------------------------------
    // הורדת מודל הזיהוי (פעם אחת)
    // ------------------------------------------------------------------
    private fun prepare(app: Context) {
        if (preparing) return
        preparing = true
        Thread {
            val dir = try {
                ensureModel(app)
            } catch (e: Exception) {
                null
            }
            val m = dir?.let {
                try {
                    Model(it.absolutePath)
                } catch (e: Exception) {
                    null
                }
            }
            handler.post {
                preparing = false
                model = m
                if (m == null) {
                    status.value = "לא הצלחתי להוריד את מודל הזיהוי. ננסה בנסיעה הבאה"
                } else {
                    start(app)
                }
            }
        }.start()
    }

    private fun findModelDir(root: File): File? {
        if (File(root, "am").isDirectory || File(root, "conf").isDirectory) return root
        root.listFiles()?.forEach { f -> if (f.isDirectory) findModelDir(f)?.let { return it } }
        return null
    }

    private fun ensureModel(app: Context): File? {
        val root = File(app.filesDir, "vosk")
        val ready = File(root, ".ready")
        if (ready.exists()) return findModelDir(root)

        handler.post { status.value = "מוריד מודל זיהוי (פעם אחת, כ-40MB)…" }
        root.deleteRecursively()
        root.mkdirs()
        val zip = File(app.cacheDir, "vosk.zip")
        var c: HttpURLConnection? = null
        try {
            c = URL(MODEL_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.instanceFollowRedirects = true
            if (c.responseCode !in 200..299) return null
            c.inputStream.use { input -> FileOutputStream(zip).use { out -> input.copyTo(out) } }
        } finally {
            c?.disconnect()
        }
        handler.post { status.value = "פורס את המודל…" }
        ZipInputStream(zip.inputStream()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val out = File(root, e.name)
                if (!out.canonicalPath.startsWith(root.canonicalPath)) continue
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zin.copyTo(it) }
                }
            }
        }
        zip.delete()
        val dir = findModelDir(root) ?: return null
        ready.writeText("ok")
        return dir
    }
}
