package com.kolbaderech.app

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

/**
 * מילת הפעלה אמיתית (Porcupine): מאזין כל הזמן במסך הרכב, בלי אינטרנט
 * ובלי לעצור מוזיקה. מושהה בזמן שהעוזרת מדברת או מקשיבה.
 */
object Wake {
    private val handler = Handler(Looper.getMainLooper())
    private var mgr: PorcupineManager? = null
    private var configHash = 0
    @Volatile private var running = false
    val status = MutableStateFlow("כבוי")
    private var errorAnnounced = false

    fun configured() = Prefs.picoKey.isNotBlank()

    private fun shouldRun() = Prefs.isCar && configured() && DriveState.active.value

    private fun hash() = (Prefs.picoKey + "|" + Prefs.wakePpn.length + "|" + Prefs.wakePpn.take(64) + "|" + Prefs.wakeSensitivity).hashCode()

    fun start(ctx: Context) {
        if (!shouldRun() || Announcer.isActive()) return
        val app = ctx.applicationContext
        if (app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.value = "חסרה הרשאת מיקרופון"
            return
        }
        if (hash() != configHash) release()
        if (running) return
        try {
            if (mgr == null) {
                mgr = build(app)
                configHash = hash()
            }
            mgr?.start()
            running = true
            status.value = "מאזין"
            errorAnnounced = false
        } catch (e: Exception) {
            running = false
            release()
            status.value = "שגיאה: ${e.message ?: e.javaClass.simpleName}"
            if (!errorAnnounced) {
                errorAnnounced = true
                Announcer.notice("מילת ההפעלה לא עובדת. בדוק את המפתח ואת הקובץ בהגדרות")
            }
        }
    }

    fun stop() {
        if (!running) return
        try {
            mgr?.stop()
        } catch (e: Exception) {
        }
        running = false
        status.value = "מושהה"
    }

    fun release() {
        stop()
        try {
            mgr?.delete()
        } catch (e: Exception) {
        }
        mgr = null
        status.value = "כבוי"
    }

    private fun build(app: Context): PorcupineManager {
        val b = PorcupineManager.Builder()
            .setAccessKey(Prefs.picoKey.trim())
            .setSensitivity(Prefs.wakeSensitivity.coerceIn(0.1f, 0.99f))
        val ppn = Prefs.wakePpn
        if (ppn.isNotBlank()) {
            val f = File(app.filesDir, "wake.ppn")
            f.writeBytes(Base64.decode(ppn, Base64.DEFAULT))
            b.setKeywordPath(f.absolutePath)
        } else {
            b.setKeyword(Porcupine.BuiltInKeyword.JARVIS)
        }
        return b.build(app) { _ -> handler.post { onWake() } }
    }

    private fun onWake() {
        stop()
        Announcer.listenCommand()
    }
}
