package com.kolbaderech.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kolbaderech.app.ui.AppIcon
import com.kolbaderech.app.ui.C

/** משתנה כשבוחרים אפליקציית שער (כדי שהמסך יתעדכן גם כשרק הפרופיל השתנה). */
val GateAppVer = androidx.compose.runtime.mutableStateOf(0)

/** אייקון האפליקציה עם תג הפרופיל (אם היא בפרופיל עבודה / תיקייה מאובטחת). */
@Composable
fun ProfileAppIcon(pkg: String, user: Long, size: Dp, fallbackName: String = "?") {
    val ctx = LocalContext.current
    val bmp = remember(pkg, user) { Profiles.icon(ctx, pkg, user) }
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(size).clip(RoundedCornerShape(size * 0.24f)))
    } else {
        AppIcon(pkg, size, fallbackName)
    }
}

/** תווית קטנה עם שם הפרופיל. */
@Composable
fun ProfileTag(text: String, main: Boolean) {
    val shape = RoundedCornerShape(10.dp)
    Text(
        text, color = if (main) C.Muted else C.Amber, fontSize = 12.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(shape).background(if (main) C.Bg else C.AmberBg).border(1.dp, C.Border, shape)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    )
}

/**
 * בחירת אפליקציית שער מכל הפרופילים (ראשי / עבודה / תיקייה מאובטחת / שכפול).
 * allowDefault: שורה ראשונה „כמו ברירת המחדל“ (onPick(null)).
 */
@Composable
fun GateAppPickerDialog(title: String, allowDefault: Boolean, onPick: (ProfApp?) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val apps = remember { Profiles.apps(ctx) }
    val multi = remember(apps) { apps.any { !it.main } }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = C.Surface,
        title = { Text(title) },
        text = {
            Column {
                if (multi) {
                    Text(
                        "יש כמה פרופילים במכשיר. עדיף לבחור עותק מהפרופיל הראשי – לאפליקציה בפרופיל עבודה / תיקייה מאובטחת אולי לא תהיה לי גישה ללחוץ.",
                        color = C.Muted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    if (allowDefault) {
                        item {
                            Row(
                                Modifier.fillMaxWidth().clickable { onPick(null) }.padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(32.dp))
                                Spacer(Modifier.width(12.dp))
                                Text("כמו אפליקציית השער הכללית", fontSize = 17.sp, color = C.Teal)
                            }
                        }
                    }
                    items(apps) { a ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onPick(a) }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ProfileAppIcon(a.pkg, a.user, 32.dp, a.label)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(a.label, fontSize = 17.sp)
                                if (multi) Text(a.pkg, color = C.Muted, fontSize = 11.sp)
                            }
                            if (multi) ProfileTag(a.profile, a.main)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("סגור", color = C.Amber) } }
    )
}
