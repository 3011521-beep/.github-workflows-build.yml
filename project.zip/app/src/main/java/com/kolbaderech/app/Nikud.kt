package com.kolbaderech.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * ניקוד אוטומטי לפני הקראה (לא מוצג על המסך), כדי שהקול יבטא נכון.
 * משתמש בשירות הניקוד החינמי של דיקטה. אם אין תשובה תוך שתי שניות – מקריאה בלי ניקוד.
 */
object Nikud {
    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 200
    }

    fun needed(text: String) = Prefs.nikud && text.any { it in '\u05D0'..'\u05EA' } && text.length <= 700

    @Synchronized
    private fun cached(t: String) = cache[t]

    @Synchronized
    private fun put(t: String, v: String) {
        cache[t] = v
    }

    /** מחזיר טקסט מנוקד, או null. רץ ברקע. */
    fun vocalize(text: String): String? {
        cached(text)?.let { return it }
        val body = JSONObject()
            .put("task", "nakdan").put("data", text).put("genre", "modern")
            .put("addmorph", true).put("keepnikud", true).put("keepqq", false)
            .put("nodageshdefmem", false).put("patachma", false)
        val res = Net.postQuick(Prefs.nikudUrl.trim(), body.toString(), 2500) ?: return null
        val out = try {
            parse(res)
        } catch (e: Exception) {
            null
        } ?: return null
        if (out.isBlank() || out.none { it in '\u0591'..'\u05C7' }) return null
        put(text, out)
        return out
    }

    private fun firstOption(o: JSONObject): String? {
        val opts = o.optJSONArray("options") ?: o.optJSONObject("nakdan")?.optJSONArray("options") ?: return null
        if (opts.length() == 0) return null
        return when (val f = opts.get(0)) {
            is String -> f
            is JSONArray -> if (f.length() > 0) f.optString(0) else null
            is JSONObject -> f.optString("w").ifBlank { null }
            else -> null
        }
    }

    private fun parse(res: String): String? {
        val trimmed = res.trim()
        val arr: JSONArray = when {
            trimmed.startsWith("[") -> JSONArray(trimmed)
            trimmed.startsWith("{") -> JSONObject(trimmed).optJSONArray("data") ?: return null
            else -> return null
        }
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val word = o.optString("word", o.optJSONObject("nakdan")?.optString("word") ?: o.optString("str"))
            if (o.optBoolean("sep", false) || o.has("str") && !o.has("nakdan")) {
                sb.append(if (o.has("str")) o.optString("str") else word)
                continue
            }
            sb.append(firstOption(o) ?: word)
        }
        return sb.toString().replace("|", "")
    }
}
