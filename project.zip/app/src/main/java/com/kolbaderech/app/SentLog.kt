package com.kolbaderech.app

/** מה שנשלח עכשיו (תגובות והודעות), כדי לא להקריא אותו בחזרה כשהוא מופיע בהתראה. */
object SentLog {
    private val sent = LinkedHashMap<String, Long>()

    @Synchronized
    fun add(text: String) {
        sent[Intents.norm(text)] = System.currentTimeMillis()
        while (sent.size > 30) sent.remove(sent.keys.first())
    }

    @Synchronized
    fun wasJustSent(text: String): Boolean {
        val t = sent[Intents.norm(text)] ?: return false
        return System.currentTimeMillis() - t < 5 * 60_000
    }
}
