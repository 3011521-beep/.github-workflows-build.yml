package com.kolbaderech.app

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BluetoothReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Prefs.isCar) return
        val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        }
        val address = device?.address ?: return
        if (address !in Prefs.cars) return
        when (intent.action) {
            BluetoothDevice.ACTION_ACL_CONNECTED -> {
                DriveState.btConnected = true
                DriveState.start(context)
            }
            BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                DriveState.btConnected = false
                if (!Link.connected.value) DriveState.stopSoon(context, 10_000)
            }
        }
    }
}
