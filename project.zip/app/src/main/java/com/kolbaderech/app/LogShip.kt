package com.kolbaderech.app

import android.content.Context
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * "שבוע למידה": כל שעתיים שולחת ל-GitHub את כל היומן מאז השליחה הקודמת –
 * מה נשמע, מה הובן, מה בוצע ומה נכשל. כל יום נפתח Issue אחד לכל מכשיר (תווית noga-log),
 * והשליחות נכנסות אליו כתגובות. בסוף היום Claude (ב-GitHub Actions) קורא את כל היום,
 * מתקן, בונה גרסה – והאפליקציה מתעדכנת לבד.
 * מספרי טלפון, מיילים, מפתחות ותוכן הודעות של אחרים מוסרים לפני השליחה.
 */
object LogShip {
    const val LABEL = "noga-log"
    private const val EVERY = 2 * 60 * 60_000L
    private const val WEEK = 7 * 24 * 60 * 60_000L
    private const val MAX_PENDING = 1_500_000L
    private const val CHUNK = 60_000

    val status = MutableStateFlow("")

    @Volatile private var app: Context? = null
    private var started = false
    private val lock = Any()

    private fun pendingFile(c: Context) = File(c.filesDir, "ship_pending.txt")
    private fun sp(c: Context) = c.getSharedPreferences("logship", Context.MODE_PRIVATE)

    /** עד מתי פעיל (0 = כבוי). */
    fun until(c: Context): Long = sp(c).getLong("until", -1L).let { if (it == -1L) 0L else it }

    fun active(c: Context): Boolean = System.currentTimeMillis() < until(c)

    /** הפעלה לשבוע מעכשיו / כיבוי. */
    fun setActive(c: Context, on: Boolean) {
        sp(c).edit().putLong("until", if (on) System.currentTimeMillis() + WEEK else 0L).apply()
        DLog.i(if (on) "🐞 שבוע למידה הופעל: היומן יישלח כל שעתיים" else "🐞 שבוע למידה כובה")
    }

    fun start(c: Context) {
        val a = c.applicationContext
        app = a
        if (started) return
        started = true
        // בפעם הראשונה (גרסה חדשה) – מופעל אוטומטית לשבוע, אם יש מפתח
        val p = sp(a)
        if (!p.contains("until") && Diag.configured()) {
            p.edit().putLong("until", System.currentTimeMillis() + WEEK).apply()
            DLog.i("🐞 שבוע למידה הופעל אוטומטית: היומן יישלח כל שעתיים לתיקון")
        }
        val r = object : Runnable {
            override fun run() {
                CrashGuard.safe(Unit) { maybeShip(force = false) }
                Net.main.postDelayed(this, 10 * 60_000L)
            }
        }
        Net.main.postDelayed(r, 60_000)
    }

    /** נקרא מ-DLog על כל שורה (כבר עם השעה). */
    fun note(line: String) {
        val c = app ?: return
        if (!active(c)) return
        // במסך הרכב שורות שהגיעו מהטלפון כבר נשלחות מהטלפון עצמו
        if (line.contains(" 📱 ")) return
        try {
            synchronized(lock) {
                val f = pendingFile(c)
                if (f.length() > MAX_PENDING) {
                    // לא אמור לקרות (אין אינטרנט כמה ימים) – שומרים את החצי האחרון
                    val keep = f.readText().takeLast((MAX_PENDING / 2).toInt())
                    f.writeText(keep.substringAfter('\n'))
                }
                f.appendText(line + "\n")
            }
        } catch (e: Throwable) {
        }
    }

    /** שולחת עכשיו (מהכפתור), או כשעברו שעתיים מהשליחה הקודמת. */
    fun maybeShip(force: Boolean, done: ((String) -> Unit)? = null) {
        val c = app ?: return
        if (!force && !active(c)) return
        if (!Diag.configured()) {
            done?.invoke("אין מפתח GitHub – אי אפשר לשלוח"); return
        }
        val p = sp(c)
        if (!force && System.currentTimeMillis() - p.getLong("last", 0L) < EVERY) return
        p.edit().putLong("last", System.currentTimeMillis()).apply()
        Net.async({ ship(c) }) { msg ->
            val m = msg ?: "שגיאה"
            status.value = m
            DLog.i("🐞 יומן: $m")
            done?.invoke(m)
        }
    }

    private fun day() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun now() = SimpleDateFormat("HH:mm", Locale.US).format(Date())

    /** רץ ברקע. */
    private fun ship(c: Context): String {
        val f = pendingFile(c)
        val raw = synchronized(lock) { if (f.exists()) f.readText() else "" }
        if (raw.isBlank()) return "אין שורות חדשות לשליחה"
        val text = raw.lines().filter { it.isNotBlank() }.joinToString("\n") { Diag.redactLine(it) }
        val issue = issueForToday(c) ?: return "לא הצלחתי לפתוח את היומן היומי ב-GitHub (בדוק מפתח והרשאת Issues)"
        val chunks = text.chunked(CHUNK)
        chunks.forEachIndexed { i, part ->
            val head = "**${now()}** · ${Prefs.role ?: "?"}" + if (chunks.size > 1) " · חלק ${i + 1}/${chunks.size}" else ""
            val body = "$head\n\n```text\n${part.replace("```", "'''")}\n```"
            val (code, _) = api("POST", "/issues/$issue/comments", JSONObject().put("body", body))
            if (code !in 200..299) return "שליחת היומן נכשלה (שגיאה $code) – אנסה שוב בעוד שעתיים"
        }
        // נשלח – מוחקים רק את מה ששלחנו (שורות חדשות שנכתבו בינתיים נשארות)
        synchronized(lock) {
            try {
                val now = if (f.exists()) f.readText() else ""
                f.writeText(if (now.startsWith(raw)) now.substring(raw.length) else "")
            } catch (e: Throwable) {
            }
        }
        return "נשלחו ${raw.lines().count { it.isNotBlank() }} שורות ליומן #$issue"
    }

    /** Issue אחד ליום לכל מכשיר. */
    private fun issueForToday(c: Context): Int? {
        val p = sp(c)
        val key = "issue_" + day()
        p.getInt(key, 0).takeIf { it > 0 }?.let { return it }
        val role = if (Prefs.isCar) "מסך הרכב" else "טלפון"
        val title = "[נוגה] יומן מלא ${day()} · $role"
        val body = "יומן מלא של יום שלם (שבוע למידה). כל שעתיים נוספת תגובה עם השורות החדשות.\n\n" +
            "| | |\n|---|---|\n" +
            "| גרסה | ${BuildInfo.version(c)} |\n| תפקיד | $role |\n" +
            "| אנדרואיד | ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) |\n" +
            "| מכשיר | ${Build.MANUFACTURER} ${Build.MODEL} |\n\n" +
            "מספרי טלפון, מיילים, מפתחות ותוכן הודעות הוסרו."
        var (code, txt) = api("POST", "/issues", JSONObject().put("title", title).put("body", body).put("labels", JSONArray().put(LABEL)))
        if (code == 422) {
            val r = api("POST", "/issues", JSONObject().put("title", title).put("body", body))
            code = r.first; txt = r.second
        }
        if (code !in 200..299) return null
        val n = try { JSONObject(txt).optInt("number") } catch (e: Throwable) { 0 }
        if (n <= 0) return null
        p.edit().putInt(key, n).apply()
        return n
    }

    private fun api(method: String, path: String, json: JSONObject): Pair<Int, String> {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL("https://api.github.com/repos/${Diag.repo()}$path").openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.readTimeout = 30_000
            conn.requestMethod = method
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer ${Diag.token()}")
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            conn.setRequestProperty("User-Agent", "Noga-Log")
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(json.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val txt = try {
                (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            } catch (e: Throwable) {
                ""
            }
            code to txt
        } catch (e: Throwable) {
            -1 to e.javaClass.simpleName
        } finally {
            try { conn?.disconnect() } catch (e: Throwable) { }
        }
    }
}
