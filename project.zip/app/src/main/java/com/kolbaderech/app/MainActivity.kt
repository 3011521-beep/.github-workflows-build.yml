package com.kolbaderech.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.kolbaderech.app.ui.AppTheme
import com.kolbaderech.app.ui.Avatar
import com.kolbaderech.app.ui.BigButton
import com.kolbaderech.app.ui.C
import com.kolbaderech.app.ui.CardBox
import com.kolbaderech.app.ui.ToggleRow
import com.kolbaderech.app.ui.SenderWithApp
import com.kolbaderech.app.ui.Banner
import com.kolbaderech.app.ui.Dot
import com.kolbaderech.app.ui.HLine
import com.kolbaderech.app.ui.MicOrb
import com.kolbaderech.app.ui.RoundIconButton
import com.kolbaderech.app.ui.StatusBadge
import com.kolbaderech.app.ui.pressable
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.text.style.TextOverflow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { AppRoot() } }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        UiBus.tick.value = UiBus.tick.value + 1
        if (Prefs.role != null && !CrashGuard.safeMode(this)) {
            if (Prefs.isCar) App.startCarLink(this) else {
                Link.startServer(this)
                CallMonitor.register(this)
                Prefs.waBoth = Contacts.installed(this, "com.whatsapp") && Contacts.installed(this, "com.whatsapp.w4b")
            }
            CrashGuard.safe(Unit) { Updater.autoCheck(this) }
            CrashGuard.safe(Unit) { Announcer.retryTts() }
        }
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("listen", false) == true) {
            i.removeExtra("listen")
            Announcer.listenCommand()
        }
    }
}

// ------------------------------------------------------------------
// הרשאות ועזרים
// ------------------------------------------------------------------
object Perms {
    fun runtimeList(): Array<String> {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (!Prefs.isCar) {
            l += listOf(
                Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS, Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR,
                Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS
            )
            if (Build.VERSION.SDK_INT >= 31) l.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    fun granted(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    fun runtimeOk(c: Context) = runtimeList().all { granted(c, it) }
    fun backgroundLocOk(c: Context) =
        Build.VERSION.SDK_INT < 29 || granted(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    fun listenerOk(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
    fun overlayOk(c: Context) = Settings.canDrawOverlays(c)
    fun batteryOk(c: Context) = c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
    fun allOk(c: Context) = runtimeOk(c) && listenerOk(c) && overlayOk(c)

    @SuppressLint("MissingPermission")
    fun bondedDevices(c: Context): List<Pair<String, String>> {
        if (Build.VERSION.SDK_INT >= 31 && !granted(c, Manifest.permission.BLUETOOTH_CONNECT)) return emptyList()
        val adapter = c.getSystemService(BluetoothManager::class.java)?.adapter ?: return emptyList()
        return try {
            adapter.bondedDevices.map { (it.name ?: it.address) to it.address }.sortedBy { it.first }
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    fun currentLocation(c: Context): Location? {
        if (!granted(c, Manifest.permission.ACCESS_FINE_LOCATION)) return null
        val lm = c.getSystemService(LocationManager::class.java) ?: return null
        val a = try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (e: Exception) { null }
        val b = try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (e: Exception) { null }
        return listOfNotNull(a, b).maxByOrNull { it.time }
    }

    fun launcherApps(c: Context): List<Pair<String, String>> {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return try {
            pm.queryIntentActivities(i, 0)
                .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .distinctBy { it.second }
                .sortedBy { it.first }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun appLabel(c: Context, pkg: String): String = try {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}

@Composable
fun AppRoot() {
    val tick by UiBus.tick.collectAsState()
    var role by remember(tick) { mutableStateOf(Prefs.role) }
    var screen by rememberSaveable { mutableStateOf("home") }
    val ctx = LocalContext.current
    BackHandler(enabled = role != null && screen != "home") { screen = "home" }

    var crash by remember { mutableStateOf(CrashGuard.safe(null) { CrashGuard.lastCrash(ctx) }) }
    crash?.let { txt ->
        CrashScreen(txt, onDone = {
            CrashGuard.dismiss(ctx)
            crash = null
        }, onReset = {
            CrashGuard.dismiss(ctx)
            Prefs.role = null
            role = null
            crash = null
        })
        return
    }

    if (role == null) {
        RoleScreen { r ->
            Prefs.role = r
            role = r
            screen = "home"
            CrashGuard.safe(Unit) { if (r == "car") App.startCarLink(ctx) else Link.startServer(ctx) }
        }
        return
    }
    // מעבר חלק בין המסכים
    AnimatedContent(
        targetState = screen,
        transitionSpec = {
            val forward = targetState != "home"
            (fadeIn(tween(220)) + slideInHorizontally(tween(260)) { w -> if (forward) -w / 6 else w / 6 }) togetherWith
                fadeOut(tween(160))
        },
        label = "screen"
    ) { s ->
        when (s) {
            "settings" -> if (Prefs.isCar) CarSettingsScreen(onBack = { screen = "home" }, onRole = {
                Prefs.role = null; role = null; screen = "home"
            }) else SettingsScreen(onBack = { screen = "home" }, onRole = {
                Prefs.role = null; role = null; screen = "home"
            })
            "data" -> DataScreen { screen = "home" }
            else -> if (Prefs.isCar) CarHomeScreen(onSettings = { screen = "settings" })
            else HomeScreen(onSettings = { screen = "settings" }, onData = { screen = "data" })
        }
    }
}

// ------------------------------------------------------------------
// מסך שגיאה אחרי קריסה
// ------------------------------------------------------------------
@Composable
fun CrashScreen(text: String, onDone: () -> Unit, onReset: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(CircleShape).background(C.AmberBg), contentAlignment = Alignment.Center) {
                Text("!", color = C.Amber, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("משהו השתבש בפעם הקודמת", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text("השירותים ברקע לא הופעלו הפעם, כדי לא לקרוס שוב", color = C.Muted, fontSize = 14.sp)
            }
        }
        Text("אפשר ללחוץ „שתף“ ולשלוח את הפרטים למפתח – זה עוזר לתקן מהר.", color = C.Soft, fontSize = 15.sp)
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(C.Surface)
                .border(1.dp, C.Border, RoundedCornerShape(18.dp)).padding(14.dp)
        ) {
            Text(
                text.lines().take(60).joinToString("\n"), fontSize = 12.sp, color = C.Soft, lineHeight = 17.sp,
                style = androidx.compose.ui.text.TextStyle(textDirection = androidx.compose.ui.text.style.TextDirection.Ltr),
                modifier = Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState())
            )
        }
        BigButton("שתף את פרטי השגיאה", R.drawable.ic_send, C.Teal, C.OnTeal, Modifier.fillMaxWidth()) {
            try {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                ctx.startActivity(Intent.createChooser(i, "שגיאה").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton("המשך", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { onDone() }
            BigButton("בחר תפקיד מחדש", null, C.Surface, C.Text, Modifier.weight(1.3f), outlined = true) { onReset() }
        }
    }
}

// ------------------------------------------------------------------
// בחירת תפקיד
// ------------------------------------------------------------------
@Composable
fun RoleScreen(onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        LogoMark(88.dp)
        Text("נוגה", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
        Text("העוזרת הקולית שלך לרכב", color = C.Soft, fontSize = 17.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text("על איזה מכשיר האפליקציה מותקנת עכשיו?", color = C.Muted, fontSize = 16.sp, textAlign = TextAlign.Center)
        RoleCard("זה הטלפון שלי", "קולט את ההודעות, שולח תגובות ומחזיק את ההגדרות", null, primary = true) { onPick("phone") }
        RoleCard("זה מסך הרכב", "מקריא, מקשיב לפקודות ופותח את וייז", R.drawable.ic_car, primary = false) { onPick("car") }
        Text(
            "מתקינים את אותו קובץ גם בטלפון וגם במסך הרכב. אפשר לשנות את הבחירה אחר כך בהגדרות.",
            color = C.Muted, fontSize = 13.sp, textAlign = TextAlign.Center, lineHeight = 19.sp
        )
    }
}

@Composable
private fun RoleCard(title: String, sub: String, icon: Int?, primary: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (primary) C.brand else androidx.compose.ui.graphics.SolidColor(C.Surface))
            .then(if (primary) Modifier else Modifier.border(1.dp, C.Border, shape))
            .pressable(onClick = onClick).padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val fg = if (primary) C.OnAmber else C.Text
        Box(
            Modifier.size(52.dp).clip(CircleShape).background(if (primary) C.OnAmber.copy(alpha = 0.12f) else C.TealBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(painterResource(icon ?: R.drawable.ic_mic), contentDescription = null,
                tint = if (primary) fg else C.Teal, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = fg, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
            Text(sub, color = fg.copy(alpha = 0.75f), fontSize = 14.sp, lineHeight = 19.sp)
        }
    }
}

/** סמל האפליקציה: עיגול בצבעי המותג עם מיקרופון. */
@Composable
fun LogoMark(size: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(C.brand),
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(R.drawable.ic_mic), contentDescription = null, tint = C.OnAmber, modifier = Modifier.size(size * 0.48f))
    }
}

private fun greeting(): String {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when (h) {
        in 5..11 -> "בוקר טוב"
        in 12..16 -> "צהריים טובים"
        in 17..20 -> "ערב טוב"
        else -> "לילה טוב"
    }
}

// ------------------------------------------------------------------
// מסך בית בטלפון
// ------------------------------------------------------------------
@Composable
fun HomeScreen(onSettings: () -> Unit, onData: () -> Unit) {
    val ctx = LocalContext.current
    val active by DriveState.active.collectAsState()
    val linked by Link.connected.collectAsState()
    val history by Announcer.history.collectAsState()
    val tick by UiBus.tick.collectAsState()
    val uiState by Announcer.state.collectAsState()
    var autoRead by remember { mutableStateOf(Prefs.autoRead) }
    val permsOk = remember(tick) { CrashGuard.safe(true) { Perms.allOk(ctx) } }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Header(greeting(), onSettings)

        val isMuted by Announcer.mutedFlow.collectAsState()
        val upd by Updater.available.collectAsState()
        val dl by Updater.progress.collectAsState()
        val updMsg by Updater.status.collectAsState()
        val needOk by Updater.needsConfirm.collectAsState()
        AnimatedVisibility(!permsOk, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
            Banner("חסרות הרשאות כדי שהאפליקציה תעבוד. לחץ כאן להשלמה", "!", C.Amber, onSettings)
        }
        AnimatedVisibility(isMuted, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
            Banner("ההקראה מושתקת בנסיעה הזאת – לחץ כדי להחזיר", "🔇", C.Amber) { Announcer.muted = false }
        }
        if (dl != null) UpdateProgressView()
        else upd?.let { u ->
            Banner("יש גרסה חדשה (${u.build})${Updater.sizeText(u)} – לחץ לעדכון", "↓", C.Teal) { Updater.downloadAndInstall(ctx) }
        }
        if (needOk) Banner("$updMsg. לחץ כאן כדי להוריד בכל זאת", "↓", C.Amber) { Updater.downloadAndInstall(ctx, force = true) }

        CardBox(padding = 18.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusBadge(active || linked) { fg ->
                    Icon(painterResource(R.drawable.ic_car), contentDescription = null, tint = fg, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Dot(if (active) C.Teal else if (linked) C.Amber else C.Muted, pulse = active)
                        Spacer(Modifier.width(8.dp))
                        Text(if (active) "מצב נהיגה פעיל" else "ממתינה לרכב", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Text(
                        when {
                            linked -> "מחובר למסך הרכב – ההקראה שם"
                            active -> "מקריאה כאן בטלפון"
                            else -> "תופעל לבד כשמסך הרכב יתחבר"
                        },
                        color = C.Muted, fontSize = 14.sp
                    )
                }
            }
            HLine()
            ToggleRow("הקראה אוטומטית", "בלי שאלות, המוזיקה חוזרת לבד", autoRead) {
                autoRead = it; Prefs.autoRead = it
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton(
                    if (active) "סיים נהיגה" else "התחל נהיגה", R.drawable.ic_car,
                    if (active) C.Surface else C.TealBg, if (active) C.Text else C.Teal, Modifier.weight(1f), outlined = active
                ) { CrashGuard.safe(Unit) { if (active) DriveState.stop(ctx) else DriveState.start(ctx) } }
                BigButton("הנתונים שלי", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { onData() }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("הוקרא לאחרונה", color = C.Muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            if (history.isNotEmpty()) Text("${history.size}", color = C.Muted, fontSize = 13.sp)
        }
        HistoryList(history, Modifier.weight(1f))

        MicButton("לחץ ודבר: „השיר הבא“, „נווטי הביתה“…", uiState is UiState.Listening)
    }
}

@Composable
private fun Header(sub: String, onSettings: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        LogoMark(44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("נוגה", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 28.sp)
            Text(sub, color = C.Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        RoundIconButton(R.drawable.ic_settings, "הגדרות") { onSettings() }
    }
}

@Composable
private fun WarningBar(text: String, onClick: () -> Unit) {
    Banner(text, "!", C.Amber, onClick)
}

@Composable
private fun HistoryList(history: List<HistoryItem>, modifier: Modifier) {
    if (history.isEmpty()) {
        Column(
            modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).border(1.dp, C.Border, RoundedCornerShape(22.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically)
        ) {
            Text("💬", fontSize = 30.sp)
            Text("עוד לא הוקראו הודעות", fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text("בהגדרות יש כפתור „הודעת בדיקה“ כדי לשמוע איך זה נשמע.", color = C.Muted, fontSize = 14.sp,
                textAlign = TextAlign.Center)
        }
    } else {
        LazyColumn(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(history) { h -> HistoryRow(h) }
        }
    }
}

@Composable
private fun MicButton(hint: String, listening: Boolean) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        MicOrb(88.dp, R.drawable.ic_mic, "דבר אליי", active = listening) { Announcer.listenCommand() }
        Text(if (listening) "מקשיבה…" else hint, color = if (listening) C.Teal else C.Muted, fontSize = 14.sp,
            textAlign = TextAlign.Center)
    }
}

@Composable
private fun HistoryRow(h: HistoryItem) {
    val time = remember(h.time) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(h.time)) }
    val id = h.id
    val replyable = h.canReply && id != null
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(C.Surface).border(1.dp, C.Border, shape)
            .then(if (replyable && id != null) Modifier.pressable(label = "הגב") { Announcer.replyTo(id) } else Modifier)
            .padding(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        SenderWithApp(h.sender, h.pkg, 44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(h.sender, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f, fill = false),
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.width(8.dp))
                Text("${h.app} · $time", color = C.Muted, fontSize = 12.sp, maxLines = 1)
            }
            Text(h.text, color = C.Soft, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 20.sp)
        }
        if (replyable) {
            Spacer(Modifier.width(8.dp))
            Row(
                Modifier.clip(RoundedCornerShape(14.dp)).background(C.TealBg).padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(painterResource(R.drawable.ic_mic), contentDescription = null, tint = C.Teal, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("הגב", color = C.Teal, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ------------------------------------------------------------------
// מסך בית במסך הרכב (רחב)
// ------------------------------------------------------------------
@Composable
fun CarHomeScreen(onSettings: () -> Unit) {
    val linked by Link.connected.collectAsState()
    val status by Link.status.collectAsState()
    val history by Announcer.history.collectAsState()
    val uiState by Announcer.state.collectAsState()
    val tiles = listOf(
        Triple("פתח שער", "תפתחי את השער", "🚧"), Triple("הביתה", "סעי הביתה", "🏠"),
        Triple("לעבודה", "סעי לעבודה", "💼"), Triple("תחנת דלק", "תחנת דלק", "⛽"),
        Triple("מה השיר?", "מה השיר", "🎵"), Triple("חדשות", "מה החדשות", "📰"),
        Triple("רדיו", "תדליקי רדיו", "📻"), Triple("שקט בנסיעה", "שקט עד סוף הנסיעה", "🔇")
    )
    Row(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Column(
            Modifier.weight(0.28f).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Header(if (linked) "מחובר לטלפון" else status, onSettings)
            val ctx = LocalContext.current
            val isMuted by Announcer.mutedFlow.collectAsState()
            if (isMuted) Banner("מושתקת – לחץ להחזיר", "🔇", C.Amber) { Announcer.muted = false }
            val tickA by UiBus.tick.collectAsState()
            val a11y = remember(tickA) { CrashGuard.safe(true) { GateService.isEnabled(ctx) } }
            if (!a11y) WarningBar("נגישות כבויה (לסגירת וייז) – לחץ להפעלה") {
                try { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
            }
            val upd by Updater.available.collectAsState()
            val dl by Updater.progress.collectAsState()
            if (dl != null) UpdateProgressView()
            else upd?.let { u -> Banner("גרסה חדשה (${u.build}) – לחץ לעדכון", "↓", C.Teal) { Updater.downloadAndInstall(ctx) } }
            Spacer(Modifier.weight(1f))
            val listening = uiState is UiState.Listening
            MicOrb(124.dp, R.drawable.ic_mic, "דבר אליי", active = listening) { Announcer.listenCommand() }
            Text(if (listening) "מקשיבה…" else "דבר אליי", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                color = if (listening) C.Teal else C.Text)
            Spacer(Modifier.weight(1f))
        }
        Column(Modifier.weight(0.4f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            tiles.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { (label, cmd, emoji) ->
                        val shape = RoundedCornerShape(22.dp)
                        Column(
                            Modifier.weight(1f).fillMaxHeight().clip(shape)
                                .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(C.Surface2, C.Surface)))
                                .border(1.dp, C.Border, shape)
                                .pressable(label = label) { Announcer.runText(cmd) },
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterVertically)
                        ) {
                            Text(emoji, fontSize = 24.sp)
                            Text(label, fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
        Column(Modifier.weight(0.32f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("הודעות אחרונות", color = C.Muted, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            HistoryList(history, Modifier.weight(1f))
        }
    }
}
