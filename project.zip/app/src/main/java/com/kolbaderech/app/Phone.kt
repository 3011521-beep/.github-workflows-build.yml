package com.kolbaderech.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract

object Phone {
    fun call(ctx: Context, rawName: String): String? {
        val name = rawName.trim()
        if (name.isEmpty()) return "למי להתקשר?"
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return "צריך לאשר גישה לאנשי קשר בהגדרות האפליקציה"
        var number: String? = null
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"), null
            )?.use { c -> if (c.moveToFirst()) number = c.getString(1) }
        } catch (e: Exception) {
        }
        val num = number ?: return "לא מצאתי את $name באנשי הקשר"
        val canCall = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val i = Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$num"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i); null
        } catch (e: Exception) {
            "לא הצלחתי להתקשר"
        }
    }
}
