package com.kolbaderech.app

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow

object DriveState {
    val active = MutableStateFlow(false)

    fun start(ctx: Context) {
        if (active.value) return
        active.value = true
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DriveService::class.java))
        } catch (e: Exception) {
            // ממשיכים גם בלי התראה קבועה
        }
        if (Prefs.announceStart) Announcer.sayShort("מצב נהיגה פעיל")
    }

    fun stop(ctx: Context) {
        if (!active.value) return
        active.value = false
        Announcer.reset()
        try {
            ctx.stopService(Intent(ctx, DriveService::class.java))
        } catch (e: Exception) {
        }
    }
}
