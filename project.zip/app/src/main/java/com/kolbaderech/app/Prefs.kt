package com.kolbaderech.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        sp = c.getSharedPreferences("kol", Context.MODE_PRIVATE)
    }

    private fun b(key: String, def: Boolean) = sp.getBoolean(key, def)
    private fun setB(key: String, v: Boolean) = sp.edit().putBoolean(key, v).apply()

    var carAddress: String?
        get() = sp.getString("carAddress", null)
        set(v) = sp.edit().putString("carAddress", v).apply()
    var carName: String?
        get() = sp.getString("carName", null)
        set(v) = sp.edit().putString("carName", v).apply()

    var autoRead: Boolean get() = b("autoRead", true); set(v) = setB("autoRead", v)
    var groupMessages: Boolean get() = b("group", true); set(v) = setB("group", v)
    var shortEmails: Boolean get() = b("shortEmails", true); set(v) = setB("shortEmails", v)
    var silentInCalls: Boolean get() = b("silentCalls", true); set(v) = setB("silentCalls", v)
    var duck: Boolean get() = b("duck", true); set(v) = setB("duck", v)
    var voiceReply: Boolean get() = b("voiceReply", true); set(v) = setB("voiceReply", v)
    var autoSend: Boolean get() = b("autoSend", true); set(v) = setB("autoSend", v)
    var readBack: Boolean get() = b("readBack", true); set(v) = setB("readBack", v)
    var announceStart: Boolean get() = b("announceStart", true); set(v) = setB("announceStart", v)

    var speechRate: Float
        get() = sp.getFloat("rate", 1.0f)
        set(v) = sp.edit().putFloat("rate", v).apply()

    fun appEnabled(def: AppDef) = b("app_" + def.pkg, def.defaultOn)
    fun setAppEnabled(def: AppDef, v: Boolean) = setB("app_" + def.pkg, v)
}
