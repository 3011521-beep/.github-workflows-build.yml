package com.kolbaderech.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** נתונים שנשמרים: פתקים, קניות, נסיעות, דלק, חניה ועוד. */
object Store {
    private lateinit var sp: SharedPreferences

    const val NOTES = "notes"
    const val SHOP = "shop"
    const val TRIPS = "trips"
    const val FUEL = "fuel"
    const val LATER = "later"
    const val PLACE_REM = "placeRem"
    const val SERVICE = "service"

    fun init(c: Context) {
        sp = c.getSharedPreferences("store", Context.MODE_PRIVATE)
    }

    private fun arr(k: String): JSONArray = try {
        JSONArray(sp.getString(k, "[]") ?: "[]")
    } catch (e: Exception) {
        JSONArray()
    }

    @Synchronized
    fun add(k: String, o: JSONObject, max: Int = 500) {
        val a = arr(k)
        a.put(o)
        while (a.length() > max) a.remove(0)
        sp.edit().putString(k, a.toString()).apply()
    }

    fun list(k: String): List<JSONObject> {
        val a = arr(k)
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }
    }

    @Synchronized
    fun removeAt(k: String, index: Int) {
        val a = arr(k)
        if (index in 0 until a.length()) a.remove(index)
        sp.edit().putString(k, a.toString()).apply()
    }

    /** מעדכן רשומה לפי id. */
    @Synchronized
    fun update(k: String, id: String, fn: (JSONObject) -> Unit) {
        val a = arr(k)
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (o.optString("id") == id) {
                fn(o); break
            }
        }
        sp.edit().putString(k, a.toString()).apply()
    }

    @Synchronized
    fun clear(k: String) = sp.edit().putString(k, "[]").apply()

    fun text(o: String) = JSONObject().put("text", o).put("time", System.currentTimeMillis())

    var parking: JSONObject?
        get() = sp.getString("parking", null)?.let { try { JSONObject(it) } catch (e: Exception) { null } }
        set(v) = sp.edit().putString("parking", v?.toString()).apply()

    var pendingParkingNote: String
        get() = sp.getString("parkNote", "") ?: ""
        set(v) = sp.edit().putString("parkNote", v).apply()

    var lastLat: Double
        get() = sp.getString("lastLat", null)?.toDoubleOrNull() ?: 0.0
        set(v) = sp.edit().putString("lastLat", v.toString()).apply()
    var lastLng: Double
        get() = sp.getString("lastLng", null)?.toDoubleOrNull() ?: 0.0
        set(v) = sp.edit().putString("lastLng", v.toString()).apply()

    var seenPackages: Set<String>
        get() = sp.getStringSet("seenPkgs", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet("seenPkgs", v).apply()

    @Synchronized
    fun inc(counter: String, by: Long = 1) =
        sp.edit().putLong("c_$counter", sp.getLong("c_$counter", 0) + by).apply()

    fun count(counter: String) = sp.getLong("c_$counter", 0)

    // ---- זיכרון "כבר הוקרא" (שורד גם אתחול) ----
    fun readMarks(): JSONObject = try {
        JSONObject(sp.getString("readMarks", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    fun saveReadMarks(o: JSONObject) = sp.edit().putString("readMarks", o.toString()).apply()
}
