package com.kolbaderech.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Announcer.init(this)
    }
}
