package com.kolbaderech.app

import android.app.SearchManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.KeyEvent
import org.json.JSONObject

object Media {
    const val YT_MUSIC = "com.google.android.apps.youtube.music"
    const val SPOTIFY = "com.spotify.music"

    private fun controllers(ctx: Context): List<MediaController> = try {
        ctx.getSystemService(MediaSessionManager::class.java)
            .getActiveSessions(ComponentName(ctx, NotifListener::class.java))
    } catch (e: Exception) {
        DLog.e("נגנים (צריך גישה להתראות)", e)
        emptyList()
    }

    private fun primary(ctx: Context): MediaController? {
        val list = controllers(ctx)
        return list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
    }

    private fun key(ctx: Context, code: Int) {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun describe(list: List<MediaController>): String =
        list.joinToString { "${it.packageName}(${stateName(it)})" }.ifEmpty { "אין נגנים פעילים" }

    /** עצירה: עוצרים כל נגן שמנגן, וגם שולחים מקש "השהה" לגיבוי. */
    fun pause(ctx: Context) {
        val list = controllers(ctx)
        DLog.i("⏸️ עצירה. נגנים: ${describe(list)}")
        val playing = list.filter { it.playbackState?.state == PlaybackState.STATE_PLAYING || it.playbackState?.state == PlaybackState.STATE_BUFFERING }
        playing.forEach {
            try {
                it.transportControls.pause()
            } catch (e: Throwable) {
                DLog.e("pause ${it.packageName}", e)
            }
        }
        if (playing.isEmpty()) key(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE)
        handler.postDelayed({
            val still = controllers(ctx).filter { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            if (still.isNotEmpty()) {
                DLog.i("⏸️ עדיין מנגן: ${describe(still)} – שולחת מקש השהה")
                key(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE)
            }
        }, 1200)
    }

    fun play(ctx: Context) {
        val list = controllers(ctx)
        DLog.i("▶️ המשך. נגנים: ${describe(list)}")
        val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED } ?: list.firstOrNull()
        if (c != null) c.transportControls.play() else key(ctx, KeyEvent.KEYCODE_MEDIA_PLAY)
    }

    fun next(ctx: Context) {
        val c = primary(ctx)
        DLog.i("⏭️ הבא ב-${c?.packageName ?: "מקש"}")
        if (c != null) c.transportControls.skipToNext() else key(ctx, KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun prev(ctx: Context) {
        val c = primary(ctx)
        DLog.i("⏮️ הקודם ב-${c?.packageName ?: "מקש"}")
        if (c != null) c.transportControls.skipToPrevious() else key(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    fun volume(ctx: Context, up: Boolean) {
        val am = ctx.getSystemService(AudioManager::class.java)
        repeat(2) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0
            )
        }
    }

    fun nowPlaying(ctx: Context): String? {
        val md = primary(ctx)?.metadata ?: return null
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
        return if (artist.isNullOrBlank()) "מתנגן עכשיו: $title" else "מתנגן עכשיו: $title, של $artist"
    }

    /** "תדליקי שירים": ממשיך מה שהיה, ואם אין נגן פעיל – פותח את אפליקציית המוזיקה ומפעיל. */
    fun playAnything(ctx: Context, pkg: String?) {
        val c = primary(ctx)
        if (c != null && pkg == null) {
            c.transportControls.play()
            DLog.i("🎵 ממשיכה לנגן ב-${c.packageName}")
            return
        }
        val want = pkg ?: if (Prefs.musicApp == "spotify") SPOTIFY else YT_MUSIC
        val target = if (want == YT_MUSIC) ytPkg(ctx) else want
        openApp(ctx, target)
        handler.postDelayed({
            val s = controllerFor(ctx, target)
            if (s != null) s.transportControls.play() else key(ctx, KeyEvent.KEYCODE_MEDIA_PLAY)
            DLog.i("🎵 הפעלה ב-$target (נגן ${if (s != null) "נמצא" else "לא נמצא"})")
        }, 3000)
    }

    fun openApp(ctx: Context, pkg: String) {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
        }
    }

    private val handler = Handler(Looper.getMainLooper())

    private var ytCache: String? = null

    /** החבילה האמיתית של יוטיוב מיוזיק במכשיר (גם גרסאות מותאמות כמו Morphe / ReVanced). */
    fun ytPkg(ctx: Context): String {
        ytCache?.let { return it }
        val pm = ctx.packageManager
        val known = listOf(
            "app.morphe.android.apps.youtube.music", "app.revanced.android.apps.youtube.music",
            "app.rvx.android.apps.youtube.music", YT_MUSIC
        )
        var found = known.firstOrNull { pm.getLaunchIntentForPackage(it) != null }
        if (found == null) {
            found = try {
                pm.queryIntentActivities(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/watch?v=x")).addCategory(Intent.CATEGORY_BROWSABLE), 0
                ).map { it.activityInfo.packageName }.firstOrNull { it.contains("youtube.music") }
            } catch (e: Throwable) {
                null
            }
        }
        val r = found ?: YT_MUSIC
        ytCache = r
        DLog.i("🎵 יוטיוב מיוזיק במכשיר: $r")
        return r
    }

    private fun stateName(c: MediaController?): String = when (c?.playbackState?.state) {
        null -> if (c == null) "אין נגן" else "לא ידוע"
        PlaybackState.STATE_PLAYING -> "מנגן"
        PlaybackState.STATE_PAUSED -> "מושהה"
        PlaybackState.STATE_BUFFERING -> "טוען"
        PlaybackState.STATE_STOPPED -> "עצור"
        PlaybackState.STATE_NONE -> "ריק"
        else -> "מצב ${c.playbackState?.state}"
    }

    private fun title(c: MediaController?): String =
        c?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""

    private fun controllerFor(ctx: Context, pkg: String): MediaController? =
        controllers(ctx).firstOrNull { it.packageName == pkg }

    /**
     * השמעת שיר מסוים: 1) דרך הנגן שכבר פתוח, 2) פתיחה + בקשה חוזרת,
     * 3) גיבוי: חיפוש באפליקציה ולחיצה על "נגן" (דרך שירות הנגישות).
     */
    fun playSearch(ctx: Context, query: String, pkg: String?) {
        val app = ctx.applicationContext
        // אפליקציית המוזיקה: מה שנאמר, אחרת מה שנבחר בהגדרות (ברירת מחדל: יוטיוב מיוזיק)
        val wantYt = (pkg ?: if (Prefs.musicApp == "spotify") SPOTIFY else YT_MUSIC) == YT_MUSIC
        val target = if (wantYt) ytPkg(app) else SPOTIFY
        DLog.i("🎵 בקשה: „$query“ → ${if (wantYt) "יוטיוב מיוזיק" else "ספוטיפיי"}")
        if (wantYt) {
            DLog.i("🎵 מחפשת ביוטיוב מיוזיק: $query")
            Net.async({ findVideoId(query) }) { id ->
                if (id == null) {
                    DLog.i("🎵 לא נמצא מזהה שיר, עוברת לחיפוש דרך הנגן")
                    playViaSession(app, query, target)
                    return@async
                }
                DLog.i("🎵 נמצא שיר: $id")
                val uri = Uri.parse("https://music.youtube.com/watch?v=$id")
                val session = controllerFor(app, target)
                var sent = false
                if (session != null) {
                    try {
                        session.transportControls.playFromUri(uri, Bundle())
                        sent = true
                        DLog.i("🎵 נשלח לנגן הפתוח")
                    } catch (e: Throwable) {
                        DLog.e("playFromUri", e)
                    }
                }
                val before = title(session)
                handler.postDelayed({
                    val c = controllerFor(app, target)
                    val ok = c?.playbackState?.state == PlaybackState.STATE_PLAYING && title(c) != before && title(c).isNotBlank()
                    if (!ok) {
                        DLog.i("🎵 פותחת קישור לשיר")
                        if (!openYtWatch(app, uri)) playViaSession(app, query, target)
                        else {
                            // יש גרסאות שפותחות את השיר אבל מחכות ל"נגן" – לוחצים בשבילך
                            handler.postDelayed({
                                val c1 = controllerFor(app, target)
                                DLog.i("🎵 מצב אחרי פתיחה: ${stateName(c1)} · ${title(c1)}")
                                if (c1 != null && c1.playbackState?.state != PlaybackState.STATE_PLAYING) {
                                    c1.transportControls.play()
                                    DLog.i("🎵 שלחתי „נגן“")
                                }
                            }, 3500)
                            handler.postDelayed({
                                val c2 = controllerFor(app, target)
                                if (c2?.playbackState?.state != PlaybackState.STATE_PLAYING) {
                                    DLog.i("🎵 עדיין לא מנגן (${stateName(c2)}), מנסה דרך הנגן")
                                    playViaSession(app, query, target)
                                } else DLog.i("🎵 מנגן: ${title(c2)}")
                            }, 8000)
                        }
                    } else DLog.i("🎵 מנגן: ${title(c)}")
                }, if (sent) 3500L else 0L)
            }
            return
        }
        playViaSession(app, query, target)
    }

    private const val DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

    /** חיפוש שיר: קודם בממשק של יוטיוב מיוזיק עצמו (שירים בלבד), ואז בחיפוש הרגיל של יוטיוב. */
    private fun findVideoId(query: String): String? {
        val re = Regex("\"videoId\":\"([A-Za-z0-9_-]{11})\"")
        try {
            val body = JSONObject()
                .put(
                    "context", JSONObject().put(
                        "client", JSONObject().put("clientName", "WEB_REMIX").put("clientVersion", "1.20250310.01.00")
                            .put("hl", "he").put("gl", "IL")
                    )
                )
                .put("query", query)
                .put("params", "EgWKAQIIAWoKEAkQBRAKEAMQBA==")
            val res = Net.post(
                "https://music.youtube.com/youtubei/v1/search?prettyPrint=false&key=AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30", body.toString(),
                mapOf("Origin" to "https://music.youtube.com", "Referer" to "https://music.youtube.com/", "User-Agent" to DESKTOP_UA)
            )
            if (res != null) re.find(res)?.groupValues?.get(1)?.let { return it }
            DLog.i("🎵 חיפוש יוטיוב מיוזיק לא החזיר תוצאה")
        } catch (e: Throwable) {
            DLog.e("ytm search", e)
        }
        val html = Net.getAsBrowser("https://www.youtube.com/results?search_query=" + Net.enc(query))
        if (html == null) {
            DLog.i("🎵 החיפוש ביוטיוב לא החזיר תשובה")
        } else {
            val id = re.find(html)?.groupValues?.get(1)
            if (id != null) return id
            DLog.i("🎵 עמוד החיפוש ביוטיוב לא הכיל שירים (${html.length} תווים)")
        }
        // גיבוי: שירותי חיפוש פתוחים של יוטיוב (Piped / Invidious)
        val q = Net.enc(query)
        for (u in listOf(
            "https://pipedapi.kavin.rocks/search?q=$q&filter=music_songs",
            "https://pipedapi.adminforge.de/search?q=$q&filter=music_songs",
            "https://inv.nadeko.net/api/v1/search?q=$q&type=video",
            "https://invidious.nerdvpn.de/api/v1/search?q=$q&type=video"
        )) {
            val res = Net.get(u) ?: continue
            val id = Regex("watch\\?v=([A-Za-z0-9_-]{11})").find(res)?.groupValues?.get(1) ?: re.find(res)?.groupValues?.get(1)
            if (id != null) {
                DLog.i("🎵 נמצא דרך שירות גיבוי")
                return id
            }
        }
        DLog.i("🎵 לא הצלחתי למצוא את השיר באף מקור")
        return null
    }

    /** פותח את השיר ביוטיוב מיוזיק – לפי מי שבאמת יודע לפתוח קישורי music.youtube.com במכשיר. */
    private fun openYtWatch(app: Context, uri: Uri): Boolean {
        val base = Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val handlers = try {
            app.packageManager.queryIntentActivities(base, 0).map { it.activityInfo.packageName }.distinct()
        } catch (e: Throwable) {
            emptyList()
        }
        DLog.i("🎵 מי יודע לפתוח את הקישור: ${handlers.joinToString().ifEmpty { "לא נמצא" }}")
        val pkg = handlers.firstOrNull { it == ytPkg(app) } ?: handlers.firstOrNull { it.contains("youtube.music") }
            ?: handlers.firstOrNull { it.contains("youtube") && !it.contains("echo") }
        val attempts = listOfNotNull(
            pkg?.let { Intent(base).setPackage(it) },
            Intent(base).setPackage(YT_MUSIC),
            Intent(base) // בלי חבילה: אנדרואיד יבחר לבד (בדרך כלל יוטיוב מיוזיק)
        )
        for (i in attempts) {
            try {
                app.startActivity(i)
                DLog.i("🎵 נפתח ב-${i.`package` ?: "ברירת המחדל"}")
                return true
            } catch (e: Throwable) {
                DLog.e("openYtWatch(${i.`package` ?: "default"})", e)
            }
        }
        return false
    }

    private fun playViaSession(app: Context, query: String, target: String) {
        val before = title(controllerFor(app, target))
        val existing = controllerFor(app, target)
        if (existing != null) {
            try {
                existing.transportControls.playFromSearch(query, Bundle())
            } catch (e: Exception) {
            }
        } else {
            sendSearchIntent(app, query, target)
            handler.postDelayed({
                try {
                    controllerFor(app, target)?.transportControls?.playFromSearch(query, Bundle())
                } catch (e: Exception) {
                }
            }, 3500)
        }
        // בדיקה: האם באמת התחיל שיר חדש?
        handler.postDelayed({
            val c = controllerFor(app, target)
            val playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
            val changed = title(c).isNotBlank() && title(c) != before
            if (!(playing && changed)) fallbackTap(app, query, target)
        }, if (existing != null) 3500L else 8000L)
    }

    private fun sendSearchIntent(app: Context, query: String, pkg: String?) {
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(MediaStore.EXTRA_MEDIA_TITLE, query)
            if (pkg != null) setPackage(pkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            app.startActivity(i)
        } catch (e: Exception) {
            try {
                i.setPackage(null)
                app.startActivity(i)
            } catch (e2: Exception) {
            }
        }
    }

    private fun fallbackTap(app: Context, query: String, pkg: String) {
        if (!GateService.isEnabled(app)) return
        val url = if (pkg == YT_MUSIC) "https://music.youtube.com/search?q=" + Uri.encode(query)
        else "spotify:search:" + Uri.encode(query)
        GateService.armTap(
            pkg, listOf("Play", "הפעלה", "הפעל", "נגן", "השמעה", "Shuffle", "ערבוב"), 15, goHome = false
        )
        try {
            app.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
    }

    fun state(ctx: Context): JSONObject? {
        val c = primary(ctx) ?: return null
        val md = c.metadata
        return JSONObject()
            .put("playing", c.playbackState?.state == PlaybackState.STATE_PLAYING)
            .put("title", md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "")
            .put("artist", md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "")
            .put("pkg", c.packageName)
    }

    fun op(ctx: Context, op: String) {
        when (op) {
            "pause" -> pause(ctx)
            "play" -> play(ctx)
            "next" -> next(ctx)
            "prev" -> prev(ctx)
            "up" -> volume(ctx, true)
            "down" -> volume(ctx, false)
        }
    }
}
