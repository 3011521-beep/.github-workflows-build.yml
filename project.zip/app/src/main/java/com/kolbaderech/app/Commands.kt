package com.kolbaderech.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** הבנת פקודות בעברית לפי מילות מפתח. עובד בלי אינטרנט ובחינם. */
object Commands {
    const val UNKNOWN = "__unknown__"
    const val UNKNOWN_SAY = "לא הבנתי. אפשר לומר למשל: השיר הבא, תדליקי עומר אדם, נווטי הביתה או תפתחי את השער"

    private fun clean(s: String) =
        s.replace(Regex("[\"״'׳?!.,:]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }
    private fun word(t: String, vararg w: String): Boolean {
        val words = t.split(" ")
        return w.any { it in words }
    }

    private fun startsAny(t: String, prefixes: List<String>): String? =
        prefixes.sortedByDescending { it.length }.firstOrNull { t.startsWith(it) }

    // ================= תגובות =================
    private val replyPrefixes = listOf(
        "תעני לו", "תעני לה", "תעני להם", "תעני", "עני לו", "עני לה",
        "תגיבי לו", "תגיבי לה", "תגיבי", "תכתבי לו", "תכתבי לה", "תכתבי",
        "תשיבי לו", "תשיבי לה", "תגידי לו", "תגידי לה", "תשלחי לו", "תשלחי לה"
    )

    private val afterShin = listOf(
        "אני", "את", "אתה", "הוא", "היא", "אנחנו", "זה", "אין", "יש", "כן", "לא",
        "אגיע", "אחזור", "אתקשר", "נדבר", "נתראה", "אהיה", "הכל", "אבוא", "מגיע", "בדרך", "תודה"
    )

    private fun stripShin(r: String): String {
        if (r.startsWith("ש") && r.length > 1) {
            val rest = r.substring(1)
            if (afterShin.any { rest.startsWith(it) }) return rest
        }
        return r
    }

    fun extractReply(heard: String): String? {
        val t = clean(heard)
        val p = startsAny(t, replyPrefixes) ?: return null
        return stripShin(t.removePrefix(p).trim()).ifBlank { null }
    }

    fun replyFromAnything(heard: String): String? {
        val t = clean(heard)
        if (isCancel(t) || isStop(t)) return null
        return extractReply(t) ?: stripShin(t).ifBlank { null }
    }

    fun changeTo(heard: String): String? {
        val t = clean(heard)
        val p = startsAny(t, listOf("תשני ל", "תשני את זה ל", "תחליפי ל", "במקום זה", "לא תכתבי", "תכתבי במקום")) ?: return null
        return stripShin(t.removePrefix(p).trim()).ifBlank { null }
    }

    fun isCancel(heard: String): Boolean {
        val t = clean(heard)
        return t.split(" ").size <= 3 && word(t, "בטל", "בטלי", "תבטלי", "ביטול", "לא", "אל")
    }

    fun isYes(heard: String) = word(clean(heard), "כן", "שלחי", "תשלחי", "שלח", "בטח", "יאללה")
    fun isStop(heard: String) = word(clean(heard), "עצרי", "תעצרי", "עצור", "תפסיקי", "הפסיקי", "די", "תשתקי")
    fun isLater(heard: String) = has(clean(heard), "לאחר כך", "אחר כך", "כשאני חונה", "תשמרי")

    // ================= ניתוב בין מסך הרכב לטלפון =================
    /** במסך הרכב: פקודות שצריכות את הטלפון נשלחות אליו. */
    private fun forwardToPhone(text: String): Boolean {
        if (Prefs.isCar && Link.connected.value) {
            Link.send(Link.obj("cmd", "text" to text))
            return true
        }
        return false
    }

    private fun mediaRemote() = Prefs.isCar && Link.connected.value && Prefs.musicSource == "phone"

    private fun mediaOp(ctx: Context, op: String) {
        if (mediaRemote()) Link.send(Link.obj("media", "op" to op)) else Media.op(ctx, op)
    }

    // ================= זמנים =================
    private fun parseMinutes(t: String): Pair<Int, String>? {
        val words = mapOf("חצי שעה" to 30, "רבע שעה" to 15, "שעתיים" to 120, "דקה" to 1, "שעה" to 60)
        val m = Regex("בעוד (\\d+) ?(דקות|דקה|שעות|שעה)").find(t)
        if (m != null) {
            val n = m.groupValues[1].toInt()
            val mins = if (m.groupValues[2].startsWith("שע")) n * 60 else n
            return mins to t.replace(m.value, " ")
        }
        for ((w, mins) in words) {
            val phrase = "בעוד $w"
            if (t.contains(phrase)) return mins to t.replace(phrase, " ")
        }
        return null
    }

    private fun parseDayHour(t: String): Long? {
        val cal = Calendar.getInstance()
        when {
            t.contains("מחרתיים") -> cal.add(Calendar.DAY_OF_YEAR, 2)
            t.contains("מחר") -> cal.add(Calendar.DAY_OF_YEAR, 1)
            else -> {
                val days = listOf("ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת")
                val idx = days.indexOfFirst { t.contains("ביום $it") || t.contains("יום $it") }
                if (idx >= 0) {
                    val target = idx + 1 // Calendar.SUNDAY = 1
                    var diff = target - cal.get(Calendar.DAY_OF_WEEK)
                    if (diff <= 0) diff += 7
                    cal.add(Calendar.DAY_OF_YEAR, diff)
                }
            }
        }
        val m = Regex("ב[- ]?(\\d{1,2})(?:[:.](\\d{2}))?").find(t) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].toIntOrNull() ?: 0
        if (h in 1..7 && (t.contains("אחר הצהריים") || t.contains("בערב"))) h += 12
        if (h > 23) return null
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, min)
        cal.set(Calendar.SECOND, 0)
        return cal.timeInMillis
    }

    // ================= הפקודות =================
    /**
     * מבצע את הפקודה. מחזיר משפט להקראה, null אם אין מה להגיד,
     * או UNKNOWN אם לא הבין.
     */
    fun handle(ctx: Context, heard: String): String? {
        val t = clean(heard)
        if (t.isEmpty()) return UNKNOWN

        // ---------- השקט / הקראה ----------
        if (has(t, "שקט עד סוף", "בלי הודעות", "תפסיקי להקריא", "אל תקריאי")) {
            Announcer.muted = true
            return "בסדר, לא אקריא הודעות עד סוף הנסיעה"
        }
        if (has(t, "תחזרי להקריא", "תקריאי הודעות", "תקריאי לי הודעות")) {
            Announcer.muted = false
            return "חזרתי להקריא הודעות"
        }
        if (has(t, "תקריאי שוב", "תקריאי עוד פעם", "שוב את ההודעה"))
            return if (Announcer.repeatLast()) null else "אין הודעה להקריא שוב"
        Regex("מה (.+?) (כתב|כתבה|שלח|שלחה)").find(t)?.let { m ->
            val name = m.groupValues[1].removePrefix("ש").trim()
            if (name in listOf("הוא", "היא", "הם")) return if (Announcer.repeatLast()) null else "אין הודעה להקריא שוב"
            val h = Announcer.history.value.firstOrNull { it.sender.contains(name) }
            return if (h != null) "${h.sender} כתב: ${h.text}" else "לא קיבלתי הודעות מ-$name בנסיעה הזאת"
        }

        // ---------- מידע ----------
        if (has(t, "מה השעה")) return "השעה " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(System.currentTimeMillis())
        if (has(t, "מה השיר", "איזה שיר", "מה מתנגן", "מי שר")) {
            if (mediaRemote()) {
                val m = Link.phoneMedia
                val title = m?.optString("title").orEmpty()
                val artist = m?.optString("artist").orEmpty()
                return if (title.isBlank()) "לא מתנגן כרגע שום שיר"
                else if (artist.isBlank()) "מתנגן עכשיו: $title" else "מתנגן עכשיו: $title, של $artist"
            }
            return Media.nowPlaying(ctx) ?: "לא מתנגן כרגע שום שיר"
        }
        if (has(t, "חדשות", "כותרות")) {
            Net.async({ Net.news() }) { r -> Announcer.notice(r ?: "לא הצלחתי להביא חדשות כרגע") }
            return null
        }
        if (has(t, "מזג האוויר", "מזג אוויר", "יהיה גשם", "יורד גשם")) {
            Net.async({ Net.weather(Store.lastLat, Store.lastLng) }) { r ->
                Announcer.notice(r ?: "לא הצלחתי לבדוק מזג אוויר כרגע")
            }
            return null
        }
        Regex("כמה זה (\\d+(?:\\.\\d+)?) ?(דולר|יורו|פאונד|שקל|שקלים)").find(t)?.let { m ->
            val amount = m.groupValues[1].toDouble()
            val from = when {
                m.groupValues[2].startsWith("דולר") -> "USD"
                m.groupValues[2].startsWith("יורו") -> "EUR"
                m.groupValues[2].startsWith("פאונד") -> "GBP"
                else -> "ILS"
            }
            val to = when {
                from != "ILS" -> "ILS"
                t.contains("ביורו") -> "EUR"
                else -> "USD"
            }
            val toName = mapOf("ILS" to "שקלים", "USD" to "דולר", "EUR" to "יורו")[to] ?: to
            Net.async({ Net.convert(amount, from, to) }) { r ->
                Announcer.notice(if (r == null) "לא הצלחתי לבדוק שער כרגע" else "זה בערך ${"%.0f".format(r)} $toName")
            }
            return null
        }
        Regex("(\\d+(?:\\.\\d+)?) ?(כפול|ועוד|פלוס|פחות|מינוס|חלקי|לחלק ל) ?(\\d+(?:\\.\\d+)?)").find(t)?.let { m ->
            val a = m.groupValues[1].toDouble()
            val b = m.groupValues[3].toDouble()
            val r = when (m.groupValues[2]) {
                "כפול" -> a * b
                "ועוד", "פלוס" -> a + b
                "פחות", "מינוס" -> a - b
                else -> if (b == 0.0) return "אי אפשר לחלק באפס" else a / b
            }
            val s = if (r == Math.floor(r)) r.toLong().toString() else "%.2f".format(r)
            return "זה $s"
        }

        // ---------- ניווט (במכשיר שבו נאמר, כלומר במסך הרכב) ----------
        if (has(t, "הביתה") && has(t, "סעי", "נווטי", "תנווטי", "קחי", "ניווט", "דרך", "תיקחי")) {
            Nav.home(ctx); return null
        }
        if (has(t, "לעבודה") && has(t, "סעי", "נווטי", "תנווטי", "קחי", "ניווט", "תיקחי")) {
            Nav.work(ctx); return null
        }
        if (t == "סעי" || t == "תסעי" || t == "נווטי") {
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            if (hour < 13) Nav.work(ctx) else Nav.home(ctx)
            return null
        }
        if (has(t, "תחנת דלק", "תחנה דלק")) { Nav.to(ctx, "תחנת דלק"); return null }
        if (has(t, "חניה קרובה", "חניון")) { Nav.to(ctx, "חניון"); return null }
        if (has(t, "כספומט")) { Nav.to(ctx, "כספומט"); return null }
        startsAny(t, listOf("נווטי ל", "תנווטי ל", "סעי ל", "תסעי ל", "קחי אותי ל", "תיקחי אותי ל", "נווט ל", "ניווט ל"))?.let { p ->
            val q = t.removePrefix(p).trim()
            if (q.isNotEmpty()) {
                Nav.to(ctx, q); return null
            }
        }

        // ---------- רדיו ----------
        if (has(t, "תכבי את הרדיו", "תכבי רדיו", "תעצרי את הרדיו", "בלי רדיו")) {
            Radio.stop(ctx); return null
        }
        if (has(t, "רדיו") || Radio.find(t) != null) {
            val st = Radio.find(t) ?: Radio.stations().firstOrNull()
            if (st != null && has(t, "תדליקי", "תשמיעי", "שימי", "תשימי", "תפעילי", "רדיו")) return Radio.play(ctx, st)
        }

        // ---------- עוצמה ----------
        if (has(t, "יותר חזק", "תגבירי", "הגבירי", "חזק יותר")) {
            Media.volume(ctx, true); return null
        }
        if (has(t, "יותר חלש", "תנמיכי", "הנמיכי", "יותר בשקט", "חלש יותר")) {
            Media.volume(ctx, false); return null
        }

        // ---------- שער ----------
        if (has(t, "שער")) {
            if (has(t, "תפתחי", "פתחי", "פתח", "לפתוח", "תפתח")) {
                if (forwardToPhone(heard)) return null
                return Gate.open(ctx)
            }
        }

        // ---------- שיחות ----------
        if (has(t, "תחזרי למי שהתקשר", "תחזרי לשיחה", "מי התקשר")) {
            if (forwardToPhone(heard)) return null
            val c = Contacts.lastCaller(ctx) ?: return "לא מצאתי שיחה אחרונה. צריך לאשר גישה ליומן השיחות"
            if (t.contains("מי התקשר")) return "השיחה האחרונה הייתה מ-${c.first}"
            return if (Contacts.call(ctx, c.second)) null else "לא הצלחתי להתקשר"
        }
        startsAny(t, listOf("תתקשרי ל", "התקשרי ל", "תחייגי ל", "חייגי ל", "תתקשר ל", "תצלצלי ל"))?.let { p ->
            if (forwardToPhone(heard)) return null
            val name = t.removePrefix(p).trim()
            val c = Contacts.find(ctx, name) ?: return "לא מצאתי את $name באנשי הקשר"
            return if (Contacts.call(ctx, c.second)) null else "לא הצלחתי להתקשר"
        }

        // ---------- חירום ----------
        if (has(t, "מצב חירום", "אס או אס", "עזרה דחופה", "SOS")) {
            if (forwardToPhone(heard)) return null
            val link = Contacts.locationLink() ?: "המיקום לא ידוע"
            val names = Prefs.list(Prefs.emergencyContacts)
            if (names.isEmpty()) return "לא הוגדרו אנשי קשר לחירום. אפשר להגדיר אותם בהגדרות"
            val sent = names.mapNotNull { n ->
                val c = Contacts.find(ctx, n) ?: return@mapNotNull null
                if (Contacts.sms(ctx, c.second, "חירום! אני צריך עזרה. המיקום שלי: $link")) c.first else null
            }
            return if (sent.isEmpty()) "לא הצלחתי לשלוח. בדוק את הרשאת ה-SMS" else "שלחתי את המיקום שלך ל: ${sent.joinToString(", ")}"
        }

        // ---------- שליחת מיקום / הודעות ----------
        if (has(t, "איפה אני", "את המיקום שלי")) {
            startsAny(t, listOf("תשלחי ל", "שלחי ל", "תשלח ל"))?.let { p ->
                if (forwardToPhone(heard)) return null
                val rest = t.removePrefix(p)
                val name = rest.substringBefore(" איפה").substringBefore(" את המיקום").trim()
                val link = Contacts.locationLink() ?: return "המיקום עוד לא ידוע"
                return Contacts.message(ctx, name, "אני כאן: $link")
            }
        }
        startsAny(t, listOf("תודיעי ל", "תגידי ל", "תעדכני את", "תעדכני ל"))?.let { p ->
            if (has(t, "כשאני מגיע", "כשאגיע")) {
                if (forwardToPhone(heard)) return null
                val name = t.removePrefix(p).substringBefore(" כש").trim()
                Features.sessionArrivalContact = name
                return "בסדר, אודיע ל-$name כשנתקרב הביתה"
            }
        }
        startsAny(t, listOf("תשלחי ל", "שלחי ל", "תכתבי ל", "תשלח ל"))?.let { p ->
            if (forwardToPhone(heard)) return null
            val rest = t.removePrefix(p).trim()
            val words = rest.split(" ")
            for (k in minOf(3, words.size - 1) downTo 1) {
                val name = words.take(k).joinToString(" ")
                val msg = stripShin(words.drop(k).joinToString(" ").trim())
                if (msg.isBlank()) continue
                val known = Relay.recentFor(Contacts.resolveNickname(name)) != null || Contacts.find(ctx, name) != null
                if (known) return Contacts.message(ctx, name, msg)
            }
            return "לא הבנתי למי לשלוח"
        }

        // ---------- תזכורות ----------
        if (has(t, "כשאני מגיע הביתה", "כשאגיע הביתה")) {
            if (forwardToPhone(heard)) return null
            val what = t.replace(Regex(".*?(כשאני מגיע הביתה|כשאגיע הביתה)"), "")
                .replace("תזכירי לי", "").trim().ifBlank { "תזכורת" }
            Store.add(Store.PLACE_REM, Store.text(what))
            return "בסדר, אזכיר לך כשתגיע הביתה: $what"
        }
        if (has(t, "תזכירי לי", "תזכורת")) {
            parseMinutes(t)?.let { (mins, rest) ->
                if (forwardToPhone(heard)) return null
                val what = rest.replace("תזכירי לי", "").replace("תזכורת", "").replace(Regex("\\s+"), " ").trim()
                    .removePrefix("ל").trim().ifBlank { "תזכורת" }
                Reminders.inMinutes(ctx, mins, what)
                return "בסדר, אזכיר לך בעוד ${if (mins >= 60 && mins % 60 == 0) "${mins / 60} שעות" else "$mins דקות"}"
            }
        }

        // ---------- יומן ----------
        if (has(t, "מה יש לי", "מה ביומן", "פגישות")) {
            if (has(t, "קבעי", "תקבעי")) {
                // מטופל למטה
            } else {
                if (forwardToPhone(heard)) return null
                return CalendarHelper.describe(ctx, if (t.contains("מחר")) 1 else 0)
            }
        }
        startsAny(t, listOf("קבעי", "תקבעי", "תוסיפי ליומן", "תכניסי ליומן"))?.let { p ->
            if (forwardToPhone(heard)) return null
            val time = parseDayHour(t) ?: return "באיזו שעה? אפשר לומר למשל: קבעי פגישה מחר ב-10 עם יוסי"
            val title = t.removePrefix(p)
                .replace(Regex("מחרתיים|מחר|היום|ביום \\S+|ב[- ]?\\d{1,2}(?:[:.]\\d{2})?|בערב|אחר הצהריים"), " ")
                .replace(Regex("\\s+"), " ").trim().ifBlank { "פגישה" }
            return CalendarHelper.add(ctx, title, time)
        }

        // ---------- פתקים וקניות ----------
        startsAny(t, listOf("תרשמי פתק", "תרשמי", "תכתבי פתק", "פתק"))?.let { p ->
            if (forwardToPhone(heard)) return null
            val what = t.removePrefix(p).trim()
            if (what.isEmpty()) return "מה לרשום?"
            Store.add(Store.NOTES, Store.text(what))
            return "רשמתי"
        }
        if (has(t, "תקריאי את הפתקים", "מה הפתקים", "הפתקים שלי")) {
            if (forwardToPhone(heard)) return null
            val notes = Store.list(Store.NOTES).takeLast(5)
            return if (notes.isEmpty()) "אין פתקים" else "הפתקים האחרונים: " + notes.joinToString(". ") { it.optString("text") }
        }
        if (has(t, "רשימת הקניות", "לרשימה", "רשימת קניות")) {
            if (forwardToPhone(heard)) return null
            if (has(t, "מה ב", "תקריאי")) {
                val items = Store.list(Store.SHOP)
                return if (items.isEmpty()) "רשימת הקניות ריקה" else "ברשימה: " + items.joinToString(", ") { it.optString("text") }
            }
            if (has(t, "תנקי", "תמחקי")) {
                Store.clear(Store.SHOP); return "ניקיתי את רשימת הקניות"
            }
            val item = t.replace(Regex("^(תוסיפי|הוסיפי|תכניסי|תשימי)"), "")
                .replace(Regex("(ל)?רשימת (ה)?קניות|לרשימה"), "").trim()
            if (item.isEmpty()) return "מה להוסיף?"
            item.split(" ו").map { it.trim() }.filter { it.isNotEmpty() }.forEach { Store.add(Store.SHOP, Store.text(it)) }
            return "הוספתי $item לרשימה"
        }

        // ---------- חניה ----------
        if (has(t, "איפה החניתי", "איפה הרכב", "איפה חניתי")) {
            if (forwardToPhone(heard)) return null
            val p = Store.parking ?: return "עוד לא שמרתי מיקום חניה"
            val lat = p.optDouble("lat")
            val lng = p.optDouble("lng")
            try {
                ctx.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lng?q=$lat,$lng(החניה שלי)"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
            }
            val note = p.optString("note")
            return if (note.isNotBlank()) "פתחתי במפה. רשמת: $note" else "פתחתי את מיקום החניה במפה"
        }
        startsAny(t, listOf("חניתי ב", "חניתי ליד", "חניתי", "פתק חניה"))?.let { p ->
            if (forwardToPhone(heard)) return null
            val note = t.removePrefix("פתק חניה").trim()
            Store.pendingParkingNote = note
            Store.parking?.let { Store.parking = it.put("note", note) }
            return "שמרתי: $note"
        }

        // ---------- דלק וסטטיסטיקה ----------
        Regex("תדלקתי (?:ב)?[- ]?(\\d+)").find(t)?.let { m ->
            if (forwardToPhone(heard)) return null
            Store.add(Store.FUEL, JSONObject().put("amount", m.groupValues[1].toInt()).put("time", System.currentTimeMillis()))
            return "רשמתי תדלוק ב-${m.groupValues[1]} שקל"
        }
        if (has(t, "על דלק", "הוצאות דלק")) {
            if (forwardToPhone(heard)) return null
            val monthStart = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            }.timeInMillis
            val sum = Store.list(Store.FUEL).filter { it.optLong("time") >= monthStart }.sumOf { it.optInt("amount") }
            return "החודש הוצאת $sum שקל על דלק"
        }
        if (has(t, "כמה נסעתי", "כמה נהגתי", "סטטיסטיקה")) {
            if (forwardToPhone(heard)) return null
            return Stats.monthSummary()
        }

        // ---------- מוזיקה לפי מצב רוח ----------
        val moods = mapOf(
            "שקט" to "מוזיקה שקטה ורגועה", "רגוע" to "מוזיקה שקטה ורגועה",
            "קצבי" to "שירים קצביים", "שמח" to "שירים שמחים", "ישראלי" to "להיטים ישראליים",
            "מזרחי" to "להיטים מזרחיים"
        )
        if (has(t, "משהו", "מוזיקה")) {
            moods.entries.firstOrNull { t.contains(it.key) }?.let { (_, q) ->
                if (mediaRemote() && forwardToPhone(heard)) return null
                Media.playSearch(ctx, q, if (Prefs.musicSource == "phone" || !Prefs.isCar) Media.YT_MUSIC else Media.YT_MUSIC)
                return null
            }
        }

        // ---------- השמעת שיר ----------
        val playP = startsAny(
            t, listOf(
                "תדליקי לי", "תדליקי", "תשמיעי לי", "תשמיעי", "שימי לי", "תשימי לי", "שימי", "תשימי",
                "נגני לי", "תנגני לי", "נגני", "תנגני", "תפעילי לי", "תפעילי"
            )
        )
        if (playP != null) {
            var q = " " + t.removePrefix(playP).trim() + " "
            val pkg = when {
                has(q, "יוטיוב") -> Media.YT_MUSIC
                has(q, "ספוטיפיי", "ספוטיפי") -> Media.SPOTIFY
                else -> null
            }
            listOf("ביוטיוב מיוזיק", "יוטיוב מיוזיק", "ביוטיוב", "יוטיוב", "בספוטיפיי", "בספוטיפי", "ספוטיפיי", "באפליקציה")
                .forEach { q = q.replace(it, " ") }
            val filler = setOf("את", "השיר", "שיר", "של", "בבקשה", "משהו", "לי", "מוזיקה", "המוזיקה", "שירים")
            val query = q.split(" ").filter { it.isNotBlank() && it !in filler }.joinToString(" ")
            if (mediaRemote()) {
                if (query.isEmpty()) mediaOp(ctx, "play") else forwardToPhone(heard)
                return null
            }
            if (query.isEmpty()) {
                if (pkg != null) Media.openApp(ctx, pkg) else Media.play(ctx)
            } else {
                Media.playSearch(ctx, query, pkg)
            }
            return null
        }

        // ---------- שליטה במוזיקה ----------
        if (word(t, "עצרי", "תעצרי", "עצור", "הפסיקי", "תפסיקי", "שקט")) {
            mediaOp(ctx, "pause"); return null
        }
        if (word(t, "הבא", "דלגי", "תדלגי", "הלאה")) {
            mediaOp(ctx, "next"); return null
        }
        if (word(t, "הקודם", "אחורה")) {
            mediaOp(ctx, "prev"); return null
        }
        if (has(t, "תמשיכי", "המשיכי", "תחזרי לשיר", "תחזרי למוזיקה", "נגני", "תנגני", "המשך")) {
            mediaOp(ctx, "play"); return null
        }

        return UNKNOWN
    }
}

object Stats {
    fun monthSummary(): String {
        val monthStart = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        }.timeInMillis
        val trips = Store.list(Store.TRIPS).filter { it.optLong("start") >= monthStart }
        val km = trips.sumOf { it.optDouble("km") }
        val minutes = trips.sumOf { (it.optLong("end") - it.optLong("start")) / 60_000 }
        val h = minutes / 60
        val m = minutes % 60
        return "החודש נסעת ${trips.size} נסיעות, כ-${km.toInt()} קילומטר, ${h} שעות ו-$m דקות"
    }
}
