package com.kolbaderech.app

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BluetoothReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        }
        val address = device?.address ?: return
        if (address != Prefs.carAddress) return
        when (intent.action) {
            BluetoothDevice.ACTION_ACL_CONNECTED -> DriveState.start(context)
            BluetoothDevice.ACTION_ACL_DISCONNECTED -> DriveState.stop(context)
        }
    }
}
