package com.kolbaderech.app.ui

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

/** אייקונים אמיתיים של האפליקציות (וואטסאפ, ספוטיפיי, וייז…). */
object IconCache {
    private val cache = HashMap<String, ImageBitmap?>()

    fun get(c: Context, pkg: String?): ImageBitmap? {
        if (pkg.isNullOrBlank()) return null
        return cache.getOrPut(pkg) {
            try {
                c.packageManager.getApplicationIcon(pkg).toBitmap(144, 144).asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
}

@Composable
fun AppIcon(pkg: String?, size: Dp, fallbackName: String = "?") {
    val ctx = LocalContext.current
    val bmp = remember(pkg) { IconCache.get(ctx, pkg) }
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(size).clip(RoundedCornerShape(size * 0.24f)))
    } else {
        Avatar(fallbackName, size)
    }
}

/** אווטאר של השולח עם אייקון קטן של האפליקציה בפינה. */
@Composable
fun SenderWithApp(name: String, pkg: String?, size: Dp, ring: Boolean = false) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) { IconCache.get(ctx, pkg) }
    Box(Modifier.size(size + size * 0.12f)) {
        Box(Modifier.align(Alignment.TopStart)) { Avatar(name, size, ring) }
        if (bmp != null) {
            val b = size * 0.42f
            Box(
                Modifier.align(Alignment.BottomEnd).size(b).clip(RoundedCornerShape(b * 0.28f))
                    .background(C.Bg).border(2.dp, C.Bg, RoundedCornerShape(b * 0.28f))
            ) {
                Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(b).clip(RoundedCornerShape(b * 0.28f)))
            }
        }
    }
}

@Composable
fun AppChip(label: String, pkg: String?) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) { IconCache.get(ctx, pkg) }
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.clip(shape).background(C.Surface).border(1.dp, C.Border, shape).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(20.dp).clip(CircleShape))
            Spacer(Modifier.width(8.dp))
        }
        Text(label, color = C.Muted, fontSize = 15.sp)
    }
}
