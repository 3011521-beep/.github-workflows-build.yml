package com.kolbaderech.app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Notify {
    fun alert(c: Context, id: Int, title: String, text: String) {
        try {
            val open = PendingIntent.getActivity(
                c, id, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(c, "alerts")
                .setSmallIcon(R.drawable.ic_car)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            c.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (e: Exception) {
        }
    }
}
