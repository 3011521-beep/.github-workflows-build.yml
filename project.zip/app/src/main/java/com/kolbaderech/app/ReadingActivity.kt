package com.kolbaderech.app

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kolbaderech.app.ui.AppTheme
import com.kolbaderech.app.ui.Avatar
import com.kolbaderech.app.ui.BigButton
import com.kolbaderech.app.ui.C
import com.kolbaderech.app.ui.CardBox
import com.kolbaderech.app.ui.Chip
import com.kolbaderech.app.ui.AppChip
import com.kolbaderech.app.ui.AppIcon
import com.kolbaderech.app.ui.SenderWithApp
import com.kolbaderech.app.ui.Dot
import kotlinx.coroutines.delay

class ReadingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            AppTheme {
                val s by Announcer.state.collectAsState()
                LaunchedEffect(s) { if (s is UiState.Idle) finish() }
                when (val st = s) {
                    is UiState.Reading -> ReadingScreen(st)
                    is UiState.Listening -> ListeningScreen(st)
                    is UiState.ConfirmReply -> ReplyScreen(st)
                    is UiState.Info -> InfoScreen(st)
                    UiState.Idle -> Box(Modifier.fillMaxSize())
                }
            }
        }
    }
}

@Composable
private fun TopLabel(text: String, dotColor: androidx.compose.ui.graphics.Color, end: String? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Dot(dotColor)
        Spacer(Modifier.width(8.dp))
        Text(text, color = C.Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.weight(1f))
        if (end != null) Text(end, color = C.Muted, fontSize = 14.sp)
    }
}

@Composable
fun ReadingScreen(st: UiState.Reading) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth > maxHeight
        if (wide) {
            Row(
                Modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(32.dp)
            ) {
                Column(
                    Modifier.weight(0.38f).fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)
                ) {
                    TopLabel("מקריאה הודעה", C.Amber, if (st.queueLeft > 0) "עוד ${st.queueLeft} בתור" else null)
                    SenderWithApp(st.sender, st.pkg, 104.dp, ring = true)
                    Text(st.sender, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    AppChip(st.app, st.pkg)
                }
                Column(Modifier.weight(0.62f).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    CardBox(Modifier.weight(1f)) {
                        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            st.lines.forEach { Text(it, fontSize = 24.sp, lineHeight = 34.sp, fontWeight = FontWeight.Medium) }
                        }
                    }
                    if (st.canReply) QuickReplies()
                    ReadingButtons(st)
                }
            }
        } else {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 32.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                TopLabel("מקריאה הודעה", C.Amber, if (st.queueLeft > 0) "עוד ${st.queueLeft} בתור" else null)
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SenderWithApp(st.sender, st.pkg, 112.dp, ring = true)
                    Text(st.sender, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    AppChip(st.app, st.pkg)
                }
                CardBox(Modifier.weight(1f, fill = false)) {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        st.lines.forEach { Text(it, fontSize = 22.sp, lineHeight = 32.sp, fontWeight = FontWeight.Medium) }
                    }
                }
                Spacer(Modifier.weight(1f))
                if (st.canReply) QuickReplies()
                ReadingButtons(st)
                Text(
                    if (st.canReply) "בסיום אפשר פשוט לומר „תעני לו…“" else "המוזיקה תחזור לבד בסיום",
                    color = C.Muted, fontSize = 14.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun QuickReplies() {
    val replies = Prefs.list(Prefs.quickReplies)
    if (replies.isEmpty()) return
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        replies.forEach { r ->
            val shape = RoundedCornerShape(18.dp)
            Text(
                r, fontSize = 16.sp, color = C.Teal, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(shape).background(C.TealBg).border(1.dp, C.TealBg, shape)
                    .clickable { Announcer.uiQuickReply(r) }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun ReadingButtons(st: UiState.Reading) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (st.canReply) {
            BigButton("הגב", R.drawable.ic_mic, C.Teal, C.OnTeal, Modifier.weight(1.2f)) { Announcer.uiReply() }
        }
        BigButton("אח״כ", null, C.Surface, C.Text, Modifier.weight(0.9f), outlined = true) { Announcer.uiLater() }
        BigButton("דלג", R.drawable.ic_skip, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { Announcer.uiSkip() }
        BigButton("עצור", R.drawable.ic_stop, C.Amber, C.OnAmber, Modifier.weight(1f)) { Announcer.uiStop() }
    }
}

@Composable
fun ListeningScreen(st: UiState.Listening) {
    val small = LocalConfiguration.current.screenHeightDp < 560
    val s1 = if (small) 140.dp else 220.dp
    val s2 = if (small) 104.dp else 164.dp
    val s3 = if (small) 76.dp else 112.dp
    val t = rememberInfiniteTransition(label = "pulse")
    val pulse by t.animateFloat(
        initialValue = 0.85f, targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p"
    )
    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 32.dp),
        verticalArrangement = Arrangement.spacedBy(if (small) 12.dp else 26.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("פקודה קולית", color = C.Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(C.Surface)
                    .then(Modifier.padding(0.dp)),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.material3.IconButton(onClick = { Announcer.uiStop() }) {
                    Icon(painterResource(R.drawable.ic_close), contentDescription = "סגור", tint = C.Text)
                }
            }
        }
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(if (small) 10.dp else 22.dp)) {
            Box(Modifier.size(s1), contentAlignment = Alignment.Center) {
                Box(Modifier.size(s1).scale(pulse).clip(CircleShape).background(androidx.compose.ui.graphics.Color(0xFF1C1A14)))
                Box(Modifier.size(s2).clip(CircleShape).background(androidx.compose.ui.graphics.Color(0xFF2E2614)))
                Box(Modifier.size(s3).clip(CircleShape).background(C.Amber), contentAlignment = Alignment.Center) {
                    Icon(painterResource(R.drawable.ic_mic), contentDescription = null, tint = C.OnAmber, modifier = Modifier.size(46.dp))
                }
            }
            Text(st.title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
        }
        if (st.heard != null) {
            CardBox {
                Text("שמעתי:", color = C.Muted, fontSize = 13.sp)
                Text("„${st.heard}“", fontSize = 21.sp, lineHeight = 30.sp, fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.weight(1f))
        Text(
            "אפשר לומר: „השיר הבא“, „תחזרי לשיר“, „תדליקי עומר אדם ביוטיוב מיוזיק“, „נווטי הביתה“, „תתקשרי לאמא“",
            color = C.Muted, fontSize = 14.sp, lineHeight = 21.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun ReplyScreen(st: UiState.ConfirmReply) {
    var count by remember(st) { mutableIntStateOf(3) }
    LaunchedEffect(st) {
        while (count > 0) {
            delay(1000); count--
        }
    }
    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 32.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        TopLabel("תגובה קולית", C.Teal)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(st.sender, 56.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text("תגובה ל-${st.sender}", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(st.app, color = C.Muted, fontSize = 14.sp)
            }
        }
        if (st.original.isNotBlank()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ההודעה", color = C.Muted, fontSize = 13.sp)
                Text(
                    st.original, color = C.Soft, fontSize = 17.sp,
                    modifier = Modifier.widthIn(max = 320.dp)
                        .clip(RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp))
                        .background(C.Surface).padding(horizontal = 16.dp, vertical = 14.dp)
                )
            }
        }
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("התגובה שלך", color = C.Muted, fontSize = 13.sp)
            Text(
                st.reply, color = androidx.compose.ui.graphics.Color(0xFFE6FFFB), fontSize = 21.sp,
                lineHeight = 30.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.widthIn(max = 320.dp)
                    .clip(RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp))
                    .background(C.TealBg).padding(horizontal = 18.dp, vertical = 16.dp)
            )
        }
        Spacer(Modifier.weight(1f))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (st.autoSend) {
                Text("$count", color = C.Teal, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
                Text("נשלחת אוטומטית אם לא תגיד „בטל“", fontSize = 16.sp, fontWeight = FontWeight.Medium)
            } else {
                Text("אמור „שלחי“ או „בטל“", fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
            Text("אפשר גם „תשני ל…“ כדי לתקן", color = C.Muted, fontSize = 14.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BigButton("בטל", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { Announcer.uiCancelReply() }
            BigButton("שלח עכשיו", R.drawable.ic_send, C.Teal, C.OnTeal, Modifier.weight(1f)) { Announcer.uiSendNow() }
        }
    }
}

@Composable
fun InfoScreen(st: UiState.Info) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (st.pkg != null) {
            AppIcon(st.pkg, 112.dp)
        } else {
            Box(Modifier.size(88.dp).clip(CircleShape).background(C.TealBg), contentAlignment = Alignment.Center) {
                Icon(painterResource(R.drawable.ic_check), contentDescription = null, tint = C.Teal, modifier = Modifier.size(40.dp))
            }
        }
        Spacer(Modifier.size(24.dp))
        Text(st.text, fontSize = 22.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}
