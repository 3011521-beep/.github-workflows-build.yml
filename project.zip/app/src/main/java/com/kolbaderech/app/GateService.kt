package com.kolbaderech.app

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * פותח את אפליקציית השער (PalGate) ולוחץ בשבילך על כפתור הפתיחה.
 * משמש גם ללחיצות אוטומטיות אחרות (נגן ביוטיוב מיוזיק, אריח בהגדרות המהירות, שלח בוואטסאפ).
 * כשמחכים ללחיצה: גם מאזינים לאירועים וגם סורקים את כל החלונות כל 400ms עד שנגמר הזמן.
 */
class GateService : AccessibilityService() {
    companion object {
        // לחיצה אוטומטית כללית (למשל: "נגן" על התוצאה הראשונה ביוטיוב מיוזיק)
        @Volatile var tapPkg: String? = null
        @Volatile var tapWords: List<String> = emptyList()
        @Volatile var tapUntil = 0L
        @Volatile var tapGoHome = false
        @Volatile var tapIds: List<String> = emptyList()
        @Volatile var tapContains = false
        @Volatile var onTapped: (() -> Unit)? = null

        /** נקרא כשנגמר הזמן בלי לחיצה: (האם חלון של האפליקציה נראה בכלל, טקסטים שנראו בה). */
        @Volatile var onTapFail: ((Boolean, List<String>) -> Unit)? = null
        @Volatile var tapScroll = false
        @Volatile private var tapStart = 0L
        @Volatile private var dumpedMid = false
        @Volatile private var sawTarget = false
        @Volatile private var scrolls = 0
        @Volatile private var scrollBack = false
        @Volatile private var lastScrollAt = 0L
        private val seenAt = java.util.concurrent.ConcurrentHashMap<String, Long>()

        fun armTap(
            pkg: String, words: List<String>, seconds: Int, goHome: Boolean,
            done: (() -> Unit)? = null, ids: List<String> = emptyList(), contains: Boolean = false,
            fail: ((Boolean, List<String>) -> Unit)? = null, scroll: Boolean = false
        ) {
            tapPkg = pkg; tapWords = words; tapGoHome = goHome; onTapped = done; tapIds = ids; tapContains = contains
            onTapFail = fail; tapScroll = scroll
            val now = System.currentTimeMillis()
            tapStart = now; dumpedMid = false; sawTarget = false; scrolls = 0; scrollBack = false; lastScrollAt = 0L
            tapUntil = now + seconds * 1000L
            instance?.let { s -> s.handler.post { s.startPoll() } }
        }

        /** ביטול ההמתנה (בלי הודעת כישלון). */
        fun cancelTap() {
            tapUntil = 0; onTapped = null; onTapFail = null
        }

        /** עדיין מחכה ללחיצה? */
        fun tapPending() = System.currentTimeMillis() <= tapUntil

        /** האם ראינו חלון / אירוע של החבילה הזו מאז t. */
        fun seenSince(pkg: String, t: Long) = (seenAt[pkg] ?: 0L) >= t

        @Volatile var instance: GateService? = null

        /** פותח את ההגדרות המהירות ולוחץ על אריח (למשל נקודה חמה). */
        fun tapQuickSetting(words: List<String>) {
            val s = instance ?: return
            armTap("com.android.systemui", words, 8, goHome = false, contains = true, done = {
                s.handler.postDelayed({
                    s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                    s.handler.postDelayed({ s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) }, 400)
                }, 900)
            })
            s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        }

        fun isEnabled(c: Context): Boolean {
            val list = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val me = ComponentName(c, GateService::class.java).flattenToString()
            return list.split(':').any { it.equals(me, ignoreCase = true) }
        }

        private val NIQQUD = Regex("[\\u0591-\\u05BD\\u05BF\\u05C1\\u05C2\\u05C4\\u05C5\\u05C7]")
        private val QUOTES = Regex("[\\u05F3\\u05F4'\"`\\u2018\\u2019\\u201C\\u201D]")
        private val NON_WORD = Regex("[^\\p{L}\\p{N}]+")

        /** השוואה סלחנית: בלי ניקוד, סימני פיסוק, מקפים ורווחים כפולים. "מתחם B גני איילון-" = "מתחם B - גני איילון". */
        fun norm(s: String): String =
            s.lowercase().replace(NIQQUD, "").replace(QUOTES, "").replace(NON_WORD, " ").trim()
    }

    val handler = Handler(Looper.getMainLooper())
    private var lastEventTry = 0L

    private val poll = object : Runnable {
        override fun run() {
            val again = CrashGuard.safe(true) { pollOnce() }
            if (again && tapUntil != 0L) handler.postDelayed(this, 400)
        }
    }

    fun startPoll() {
        handler.removeCallbacks(poll)
        handler.post(poll)
    }

    override fun onServiceConnected() {
        instance = this
        if (tapPending()) startPoll()
    }

    override fun onDestroy() {
        handler.removeCallbacks(poll)
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // שגיאה בקריאת עץ המסך (חלון שנסגר באמצע וכו') לא תפיל את כל האפליקציה
        CrashGuard.safe(Unit) { handleEvent(event) }
    }

    private fun handleEvent(event: AccessibilityEvent?) {
        val evPkg = event?.packageName?.toString() ?: return
        val now = System.currentTimeMillis()
        seenAt[evPkg] = now
        if (now <= tapUntil && evPkg == tapPkg) {
            sawTarget = true
            if (now - lastEventTry >= 150) {
                lastEventTry = now
                tryTap()
            }
        }
    }

    /** סבב סריקה אחד. מחזיר true אם צריך להמשיך. */
    private fun pollOnce(): Boolean {
        if (tapUntil == 0L) return false
        val now = System.currentTimeMillis()
        if (now > tapUntil) {
            timeout()
            return false
        }
        if (tryTap()) return false
        val el = now - tapStart
        if (!dumpedMid && el >= 4000) {
            dumpedMid = true
            dump("אחרי 4 שניות")
        }
        if (tapScroll && el >= 3000 && now - lastScrollAt >= 1500 && scrolls < 12) {
            lastScrollAt = now
            tryScroll()
        }
        return true
    }

    /** שורשי כל החלונות של האפליקציה שמחכים לה (כולל חלונות שאינם הפעילים). */
    private fun targetRoots(pkg: String): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                val r = w.root ?: continue
                if (r.packageName?.toString() == pkg) out.add(r)
            }
        } catch (e: Exception) {
        }
        try {
            val r = rootInActiveWindow
            if (r != null && r.packageName?.toString() == pkg && out.none { it == r }) out.add(r)
        } catch (e: Exception) {
        }
        if (out.isNotEmpty()) {
            sawTarget = true
            seenAt[pkg] = System.currentTimeMillis()
        }
        return out
    }

    private class Hit(val node: AccessibilityNodeInfo, val score: Int, val order: Int, val label: String)

    private fun walk(n: AccessibilityNodeInfo?, depth: Int, count: IntArray, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null || depth > 50 || count[0] > 3000) return
        count[0]++
        f(n)
        for (k in 0 until n.childCount) walk(n.getChild(k), depth + 1, count, f)
    }

    /** מוצא ולוחץ. true = לחץ. */
    private fun tryTap(): Boolean {
        val pkg = tapPkg ?: return false
        if (!tapPending()) return false
        val roots = targetRoots(pkg)
        if (roots.isEmpty()) return false
        val hits = ArrayList<Hit>()
        for (r in roots) for (id in tapIds) {
            try {
                r.findAccessibilityNodeInfosByViewId(id)?.forEach { hits.add(Hit(it, 100, 0, id)) }
            } catch (e: Exception) {
            }
        }
        val targets = tapWords.mapIndexed { i, w -> Triple(i, norm(w), w.trim().lowercase()) }.filter { it.third.isNotEmpty() }
        val contains = tapContains
        for (r in roots) walk(r, 0, IntArray(1)) { n ->
            for (cs in listOf(n.text, n.contentDescription)) {
                val raw = cs?.toString() ?: continue
                if (raw.isBlank()) continue
                val nn = norm(raw)
                val rl = raw.trim().lowercase()
                for ((i, nw, rw) in targets) {
                    val s = when {
                        nw.isNotEmpty() && nn == nw -> 3
                        nw.isEmpty() && rl == rw -> 3
                        !contains -> 0
                        nw.isNotEmpty() && nn.contains(nw) -> 2
                        nw.isEmpty() && rl.contains(rw) -> 2
                        nw.contains(' ') && nn.split(' ').toSet().containsAll(nw.split(' ')) -> 1
                        else -> 0
                    }
                    if (s > 0) hits.add(Hit(n, s * 2 + if (n.isVisibleToUser) 1 else 0, i, raw))
                }
            }
        }
        hits.sortWith(compareBy({ -it.score }, { it.order }))
        for (h in hits) {
            if (click(h.node)) {
                tapUntil = 0
                DLog.i("👆 לחצתי על „${h.label.take(40)}“ ב-$pkg")
                val cb = onTapped
                onTapped = null
                onTapFail = null
                cb?.let { f -> handler.post { f() } }
                if (tapGoHome) handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 1500)
                return true
            }
        }
        return false
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        var node: AccessibilityNodeInfo? = n
        while (node != null && !node.isClickable) node = node.parent
        if (node != null && node.isEnabled && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        return node == null && n.isEnabled && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /** גלילה ברשימה (אולי השער שמחפשים נמצא למטה). */
    private fun tryScroll() {
        val pkg = tapPkg ?: return
        var sc: AccessibilityNodeInfo? = null
        for (r in targetRoots(pkg)) {
            walk(r, 0, IntArray(1)) { n -> if (sc == null && n.isScrollable) sc = n }
            if (sc != null) break
        }
        val node = sc ?: return
        scrolls++
        val act = if (scrollBack) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        if (!node.performAction(act)) scrollBack = !scrollBack
    }

    /** רושם ביומן מה כן מופיע במסך (כדי לדעת מה לחפש). */
    private fun dump(stage: String): List<String> {
        val pkg = tapPkg ?: return emptyList()
        val texts = ArrayList<String>()
        for (r in targetRoots(pkg)) walk(r, 0, IntArray(1)) { n ->
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (!t.isNullOrEmpty() && t.length < 60 && texts.size < 60) texts.add(t)
        }
        val wins = try {
            windows.mapNotNull { it.root?.packageName?.toString() }
        } catch (e: Exception) {
            emptyList()
        }
        val active = try {
            rootInActiveWindow?.packageName?.toString()
        } catch (e: Exception) {
            null
        }
        val list = texts.distinct()
        DLog.i(
            "👆 [$stage] מחפשת ${tapWords.take(3)} ב-$pkg; חלונות: ${wins.distinct()} (פעיל: ${active ?: "-"}); " +
                "במסך: ${if (list.isEmpty()) "(ריק)" else list.take(40).joinToString(" | ")}"
        )
        return list
    }

    private fun timeout() {
        val texts = dump("נגמר הזמן")
        val seen = sawTarget
        tapUntil = 0
        val f = onTapFail
        onTapFail = null
        onTapped = null
        if (!seen) DLog.i("👆 שום חלון של $tapPkg לא נראה – אולי לא נפתחה, או שהיא בפרופיל שאין לי גישה אליו")
        f?.let { cb -> handler.post { cb(seen, texts) } }
    }

    override fun onInterrupt() {}
}

data class GateDef(
    val id: String,
    val name: String,
    val lat: Double,
    val lng: Double,
    val radius: Float,
    val tap: String,
    val auto: Boolean,
    /** אפליקציה לשער הזה (ריק = אפליקציית השער הכללית מההגדרות). */
    val pkg: String = "",
    /** המספר הסידורי של הפרופיל (-1 = הפרופיל הראשי / הנוכחי). */
    val user: Long = -1L
)

/** כמה שערים / חניונים: לכל אחד מיקום משלו, והשם שעליו לוחצים בפלגייט. */
object Gates {
    fun all(): List<GateDef> {
        val arr = try {
            org.json.JSONArray(Prefs.gates)
        } catch (e: Exception) {
            org.json.JSONArray()
        }
        val list = (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            GateDef(
                o.optString("id"), o.optString("name"), o.optDouble("lat", 0.0), o.optDouble("lng", 0.0),
                o.optDouble("radius", 150.0).toFloat(), o.optString("tap"), o.optBoolean("auto", true),
                o.optString("pkg", ""), o.optLong("user", -1L)
            )
        }
        // מעבר מגרסה עם שער יחיד
        if (list.isEmpty() && Prefs.gateLat.isNotBlank()) {
            val g = GateDef(
                "g1", "הבית", Prefs.gateLat.toDoubleOrNull() ?: 0.0, Prefs.gateLng.toDoubleOrNull() ?: 0.0,
                Prefs.gateRadius, "", true
            )
            save(listOf(g))
            return listOf(g)
        }
        return list
    }

    fun save(list: List<GateDef>) {
        val arr = org.json.JSONArray()
        list.forEach {
            arr.put(
                org.json.JSONObject().put("id", it.id).put("name", it.name).put("lat", it.lat).put("lng", it.lng)
                    .put("radius", it.radius.toDouble()).put("tap", it.tap).put("auto", it.auto)
                    .also { o -> if (it.pkg.isNotBlank()) o.put("pkg", it.pkg).put("user", it.user) }
            )
        }
        Prefs.gates = arr.toString()
    }

    fun add(name: String, lat: Double, lng: Double): GateDef {
        val g = GateDef("g" + System.currentTimeMillis(), name, lat, lng, 150f, name, true)
        save(all() + g)
        return g
    }

    fun update(id: String, fn: (GateDef) -> GateDef) = save(all().map { if (it.id == id) fn(it) else it })
    fun remove(id: String) = save(all().filter { it.id != id })

    fun byName(q: String): GateDef? {
        val n = Intents.norm(q).replace(Regex("^(של|ה)"), "").trim()
        if (n.isEmpty()) return null
        return all().firstOrNull { g ->
            val gn = Intents.norm(g.name)
            gn.isNotEmpty() && (n.contains(gn) || gn.contains(n))
        }
    }

    fun nearest(lat: Double, lng: Double): GateDef? {
        if (lat == 0.0 && lng == 0.0) return null
        return all().filter { it.lat != 0.0 }.minByOrNull { g ->
            val r = FloatArray(1)
            android.location.Location.distanceBetween(lat, lng, g.lat, g.lng, r)
            r[0]
        }
    }
}

object Gate {
    private val h = Handler(Looper.getMainLooper())

    /** איזו אפליקציה ובאיזה פרופיל פותחים לשער הזה (או ברירת המחדל מההגדרות). */
    fun appFor(g: GateDef?): Pair<String, Long> =
        if (g != null && g.pkg.isNotBlank()) g.pkg to g.user
        else Prefs.gatePkg to (Prefs.gateUser.toLongOrNull() ?: -1L)

    /** פותח שער מסוים (או הקרוב / היחיד אם לא נאמר איזה). */
    fun open(c: Context, which: GateDef? = null): String {
        val gates = Gates.all()
        val g = which ?: gates.singleOrNull() ?: Gates.nearest(Store.lastLat, Store.lastLng)
        val (pkg, user) = appFor(g)
        if (pkg.isBlank()) return "צריך לבחור את אפליקציית השער בהגדרות"
        if (!GateService.isEnabled(c)) return "צריך להפעיל את נוגה בהגדרות הנגישות כדי לפתוח את השער"
        val prof = try {
            Profiles.label(c, user)
        } catch (e: Exception) {
            "ראשי"
        }
        DLog.i("🚧 פותחת שער: ${g?.name ?: "ברירת מחדל"} · $pkg (פרופיל: $prof)")
        val steps = (g?.tap?.ifBlank { g.name } ?: "").split(">").map { it.trim() }.filter { it.isNotEmpty() }
        val t0 = System.currentTimeMillis()
        if (g != null && steps.isNotEmpty()) {
            armSteps(pkg, steps)
        } else {
            val words = Prefs.list(Prefs.gateButtonText)
            GateService.armTap(
                pkg, words, 20, goHome = true, contains = true, scroll = true,
                done = { Out.say("השער נפתח") }, fail = failFor(words.firstOrNull() ?: "פתח")
            )
        }
        val r = try {
            Profiles.launch(c, pkg, user)
        } catch (e: Exception) {
            DLog.i("🚧 פתיחה נכשלה: ${e.javaClass.simpleName}: ${e.message}")
            Profiles.Launch("לא הצלחתי לפתוח את אפליקציית השער", false)
        }
        if (r.error != null) {
            GateService.cancelTap()
            DLog.i("🚧 ${r.error}")
            return r.error
        }
        if (r.otherProfile) {
            // אפליקציה בפרופיל אחר (עבודה / תיקייה מאובטחת): ייתכן ששירות הנגישות לא רואה אותה בכלל
            h.postDelayed({
                if (GateService.tapPending() && GateService.tapPkg == pkg && !GateService.seenSince(pkg, t0)) {
                    GateService.cancelTap()
                    val msg = "אפליקציית השער נפתחה בפרופיל $prof, אבל אין לי גישה לראות אותה שם, אז לא אוכל ללחוץ בשבילך. " +
                        "כדאי להתקין אותה גם בפרופיל הראשי ולבחור את העותק הראשי בהגדרות השער"
                    DLog.i("🚧 $msg")
                    Out.say(msg)
                }
            }, 6000)
        }
        return if (g != null && gates.size > 1) "פותחת את ${g.name}" else "פותחת את השער"
    }

    /** הודעה קולית כשלא נמצא מה ללחוץ – כדי שלא ייכשל בשקט. */
    private fun failFor(step: String): (Boolean, List<String>) -> Unit = { seen, texts ->
        val msg = if (!seen) "לא ראיתי את אפליקציית השער על המסך, אז לא לחצתי על „$step“. אולי היא לא נפתחה, או שהיא בפרופיל שאין לי גישה אליו"
        else "לא מצאתי באפליקציית השער את „$step“. כדאי לבדוק בהגדרות השער שהשם כתוב כמו שהוא מופיע באפליקציה"
        DLog.i("🚧 $msg; במסך: ${texts.take(15).joinToString(" | ")}")
        Out.say(msg)
    }

    /** לחיצות ברצף, למשל: "חניון העבודה > פתח". */
    private fun armSteps(pkg: String, steps: List<String>) {
        val first = steps.first()
        val rest = steps.drop(1)
        GateService.armTap(
            pkg, listOf(first), 20, goHome = rest.isEmpty(),
            done = {
                if (rest.isNotEmpty()) armSteps(pkg, rest) else Out.say("השער נפתח")
            },
            contains = true, scroll = true, fail = failFor(first)
        )
    }
}
