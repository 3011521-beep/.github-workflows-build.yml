package com.kolbaderech.app

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** פותח את אפליקציית השער (PalGate) ולוחץ בשבילך על כפתור הפתיחה. */
class GateService : AccessibilityService() {
    companion object {
        @Volatile var armedUntil = 0L

        // לחיצה אוטומטית כללית (למשל: "נגן" על התוצאה הראשונה ביוטיוב מיוזיק)
        @Volatile var tapPkg: String? = null
        @Volatile var tapWords: List<String> = emptyList()
        @Volatile var tapUntil = 0L
        @Volatile var tapGoHome = false
        @Volatile var tapIds: List<String> = emptyList()
        @Volatile var tapContains = false
        var onTapped: (() -> Unit)? = null

        fun armTap(
            pkg: String, words: List<String>, seconds: Int, goHome: Boolean,
            done: (() -> Unit)? = null, ids: List<String> = emptyList(), contains: Boolean = false
        ) {
            tapPkg = pkg; tapWords = words; tapGoHome = goHome; onTapped = done; tapIds = ids; tapContains = contains
            tapUntil = System.currentTimeMillis() + seconds * 1000L
        }

        fun isEnabled(c: Context): Boolean {
            val list = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val me = ComponentName(c, GateService::class.java).flattenToString()
            return list.split(':').any { it.equals(me, ignoreCase = true) }
        }
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val evPkg = event?.packageName?.toString() ?: return
        if (System.currentTimeMillis() <= tapUntil && evPkg == tapPkg) {
            val root = rootInActiveWindow ?: return
            val candidates = ArrayList<AccessibilityNodeInfo>()
            for (id in tapIds) root.findAccessibilityNodeInfosByViewId(id)?.let { candidates.addAll(it) }
            for (w in tapWords) {
                root.findAccessibilityNodeInfosByText(w)?.filter { n ->
                    tapContains ||
                        n.contentDescription?.toString()?.equals(w, ignoreCase = true) == true ||
                        n.text?.toString()?.equals(w, ignoreCase = true) == true
                }?.let { candidates.addAll(it) }
            }
            for (cand in candidates) {
                var node: AccessibilityNodeInfo? = cand
                while (node != null && !node.isClickable) node = node.parent
                if (node != null && node.isEnabled && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    tapUntil = 0
                    val cb = onTapped
                    onTapped = null
                    cb?.let { f -> handler.post { f() } }
                    if (tapGoHome) handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 1500)
                    return
                }
            }
            return
        }
        if (System.currentTimeMillis() > armedUntil) return
        val pkg = evPkg
        if (pkg != Prefs.gatePkg) return
        val root = rootInActiveWindow ?: return
        val words = Prefs.list(Prefs.gateButtonText)
        var node: AccessibilityNodeInfo? = null
        for (w in words) {
            node = root.findAccessibilityNodeInfosByText(w)?.firstOrNull()
            if (node != null) break
        }
        var target = node
        while (target != null && !target.isClickable) target = target.parent
        if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            armedUntil = 0
            Out.say("השער נפתח")
            handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 2500)
        }
    }

    override fun onInterrupt() {}
}

data class GateDef(
    val id: String,
    val name: String,
    val lat: Double,
    val lng: Double,
    val radius: Float,
    val tap: String,
    val auto: Boolean
)

/** כמה שערים / חניונים: לכל אחד מיקום משלו, והשם שעליו לוחצים בפלגייט. */
object Gates {
    fun all(): List<GateDef> {
        val arr = try {
            org.json.JSONArray(Prefs.gates)
        } catch (e: Exception) {
            org.json.JSONArray()
        }
        val list = (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            GateDef(
                o.optString("id"), o.optString("name"), o.optDouble("lat", 0.0), o.optDouble("lng", 0.0),
                o.optDouble("radius", 150.0).toFloat(), o.optString("tap"), o.optBoolean("auto", true)
            )
        }
        // מעבר מגרסה עם שער יחיד
        if (list.isEmpty() && Prefs.gateLat.isNotBlank()) {
            val g = GateDef(
                "g1", "הבית", Prefs.gateLat.toDoubleOrNull() ?: 0.0, Prefs.gateLng.toDoubleOrNull() ?: 0.0,
                Prefs.gateRadius, "", true
            )
            save(listOf(g))
            return listOf(g)
        }
        return list
    }

    fun save(list: List<GateDef>) {
        val arr = org.json.JSONArray()
        list.forEach {
            arr.put(
                org.json.JSONObject().put("id", it.id).put("name", it.name).put("lat", it.lat).put("lng", it.lng)
                    .put("radius", it.radius.toDouble()).put("tap", it.tap).put("auto", it.auto)
            )
        }
        Prefs.gates = arr.toString()
    }

    fun add(name: String, lat: Double, lng: Double): GateDef {
        val g = GateDef("g" + System.currentTimeMillis(), name, lat, lng, 150f, name, true)
        save(all() + g)
        return g
    }

    fun update(id: String, fn: (GateDef) -> GateDef) = save(all().map { if (it.id == id) fn(it) else it })
    fun remove(id: String) = save(all().filter { it.id != id })

    fun byName(q: String): GateDef? {
        val n = Intents.norm(q).replace(Regex("^(של|ה)"), "").trim()
        if (n.isEmpty()) return null
        return all().firstOrNull { g ->
            val gn = Intents.norm(g.name)
            gn.isNotEmpty() && (n.contains(gn) || gn.contains(n))
        }
    }

    fun nearest(lat: Double, lng: Double): GateDef? {
        if (lat == 0.0 && lng == 0.0) return null
        return all().filter { it.lat != 0.0 }.minByOrNull { g ->
            val r = FloatArray(1)
            android.location.Location.distanceBetween(lat, lng, g.lat, g.lng, r)
            r[0]
        }
    }
}

object Gate {
    /** פותח שער מסוים (או הקרוב / היחיד אם לא נאמר איזה). */
    fun open(c: Context, which: GateDef? = null): String {
        val pkg = Prefs.gatePkg
        if (pkg.isBlank()) return "צריך לבחור את אפליקציית השער בהגדרות"
        if (!GateService.isEnabled(c)) return "צריך להפעיל את נוגה בהגדרות הנגישות כדי לפתוח את השער"
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return "אפליקציית השער לא מותקנת"
        val gates = Gates.all()
        val g = which ?: gates.singleOrNull() ?: Gates.nearest(Store.lastLat, Store.lastLng)
        val steps = (g?.tap?.ifBlank { g.name } ?: "").split(">").map { it.trim() }.filter { it.isNotEmpty() }
        if (g != null && steps.isNotEmpty()) {
            armSteps(pkg, steps)
        } else {
            GateService.armedUntil = System.currentTimeMillis() + 20_000
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            c.startActivity(i)
            if (g != null && gates.size > 1) "פותחת את ${g.name}" else "פותחת את השער"
        } catch (e: Exception) {
            "לא הצלחתי לפתוח את אפליקציית השער"
        }
    }

    /** לחיצות ברצף, למשל: "חניון העבודה > פתח". */
    private fun armSteps(pkg: String, steps: List<String>) {
        val first = steps.first()
        val rest = steps.drop(1)
        GateService.armTap(
            pkg, listOf(first), if (rest.isEmpty()) 20 else 20, goHome = rest.isEmpty(),
            done = {
                if (rest.isNotEmpty()) armSteps(pkg, rest) else Out.say("השער נפתח")
            },
            contains = true
        )
    }
}
