package com.kolbaderech.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kolbaderech.app.ui.BigButton
import com.kolbaderech.app.ui.C
import com.kolbaderech.app.ui.CardBox
import com.kolbaderech.app.ui.PrefChoice
import com.kolbaderech.app.ui.PrefSlider
import com.kolbaderech.app.ui.PrefText
import com.kolbaderech.app.ui.PrefToggle
import com.kolbaderech.app.ui.SectionTitle
import com.kolbaderech.app.ui.ToggleRow
import com.kolbaderech.app.ui.AppIcon

@Composable
fun BackHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(48.dp).clip(CircleShape).background(C.Surface)
                .border(1.dp, C.Border, CircleShape).clickable { onBack() },
            contentAlignment = Alignment.Center
        ) {
            Icon(painterResource(R.drawable.ic_back), contentDescription = "חזרה", tint = C.Text, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** עורך שערים / חניונים: כל אחד עם מיקום, ומה ללחוץ עליו בפלגייט. */
@Composable
private fun GatesEditor() {
    val ctx = LocalContext.current
    var ver by remember { mutableStateOf(0) }
    @Suppress("UNUSED_VARIABLE") val r = ver
    val gates = Gates.all()
    var newName by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }

    Text(
        "לכל חניון: עמוד לידו, תן לו שם ולחץ „הוסף כאן“. בשדה „מה ללחוץ בפלגייט“ כתוב את השם כפי שהוא מופיע בפלגייט. " +
            "אם צריך שתי לחיצות, הפרד ב-> (למשל: חניון העבודה > פתח).",
        color = C.Muted, fontSize = 13.sp, lineHeight = 19.sp
    )
    gates.forEach { g ->
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.Bg)
                .border(1.dp, C.Border, RoundedCornerShape(16.dp)).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            androidx.compose.runtime.key(g.id) {
                PrefText("שם", "למשל: הבית", { g.name }, { v -> Gates.update(g.id) { it.copy(name = v) } })
                PrefText("מה ללחוץ בפלגייט", "השם בפלגייט", { g.tap }, { v -> Gates.update(g.id) { it.copy(tap = v) } })
                PrefSlider("מרחק פתיחה", 50f..400f, { g.radius }, { v -> Gates.update(g.id) { it.copy(radius = v) } }) { "${it.toInt()} מ׳" }
                PrefToggle("פתיחה אוטומטית כשמתקרבים", null, { g.auto }) { v -> Gates.update(g.id) { it.copy(auto = v) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("פתח עכשיו", color = C.Teal, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                    Announcer.notice(Gate.open(ctx, g))
                }.padding(vertical = 6.dp))
                Text("עדכן מיקום לכאן", color = C.Amber, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                    val l = Perms.currentLocation(ctx)
                    if (l != null) {
                        Gates.update(g.id) { it.copy(lat = l.latitude, lng = l.longitude) }
                        msg = "המיקום של ${g.name} עודכן"; ver++
                    } else msg = "אין מיקום כרגע. בדוק שה-GPS דלוק"
                }.padding(vertical = 6.dp))
                Text("איפוס מיקום", color = C.Muted, modifier = Modifier.clickable {
                    Gates.update(g.id) { it.copy(lat = 0.0, lng = 0.0) }
                    msg = "המיקום של ${g.name} אופס"; ver++
                }.padding(vertical = 6.dp))
                Text("מחק", color = C.Muted, modifier = Modifier.clickable { Gates.remove(g.id); ver++ }.padding(vertical = 6.dp))
            }
            Text(if (g.lat != 0.0) "מיקום שמור ✓" else "אין מיקום – לא ייפתח אוטומטית", color = C.Muted, fontSize = 12.sp)
        }
    }
    PrefText("שם לחניון חדש", "למשל: חניון העבודה", { newName }, { newName = it })
    BigButton("הוסף כאן (המיקום הנוכחי)", null, C.Surface, C.Text, Modifier.fillMaxWidth(), outlined = true) {
        val l = Perms.currentLocation(ctx)
        val name = newName.trim().ifBlank { "חניון ${gates.size + 1}" }
        Gates.add(name, l?.latitude ?: 0.0, l?.longitude ?: 0.0)
        msg = if (l != null) "נוסף: $name" else "נוסף: $name (בלי מיקום – עדכן כשתהיה שם)"
        newName = ""; ver++
    }
    if (msg.isNotEmpty()) Text(msg, color = C.Teal, fontSize = 14.sp)
}

/** פס התקדמות יפה להורדת עדכון: אחוזים, מגה-בייט, מהירות וזמן שנותר. */
@Composable
fun UpdateProgressView() {
    val p by Updater.progress.collectAsState()
    val prog = p ?: return
    val mb = { b: Long -> "%.1f".format(b / 1_048_576.0) }
    val secs = maxOf(0.5, (System.currentTimeMillis() - prog.startedAt) / 1000.0)
    val speed = prog.done / secs
    val fraction = if (prog.total > 0) (prog.done.toFloat() / prog.total).coerceIn(0f, 1f) else 0f
    val eta = if (prog.total > 0 && speed > 1) ((prog.total - prog.done) / speed).toInt() else -1
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.TealBg).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("מורידה עדכון", color = C.Teal, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(if (prog.total > 0) "${(fraction * 100).toInt()}%" else "…", color = C.Teal, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        }
        if (prog.total > 0) {
            androidx.compose.material3.LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                color = C.Teal, trackColor = C.Bg
            )
        } else {
            androidx.compose.material3.LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                color = C.Teal, trackColor = C.Bg
            )
        }
        Row {
            Text(
                if (prog.total > 0) "${mb(prog.done)} מתוך ${mb(prog.total)} MB" else "${mb(prog.done)} MB",
                color = C.Soft, fontSize = 13.sp, modifier = Modifier.weight(1f)
            )
            Text(
                "${mb(speed.toLong())} MB/s" + if (eta >= 0) " · נותרו ${if (eta >= 60) "${eta / 60} דק׳ " else ""}${eta % 60} שנ׳" else "",
                color = C.Soft, fontSize = 13.sp
            )
        }
    }
}

@Composable
fun UpdatesCard() {
    val ctx = LocalContext.current
    val st by Updater.status.collectAsState()
    val avail by Updater.available.collectAsState()
    var advanced by remember { mutableStateOf(false) }
    CardBox(padding = 16.dp) {
        Text("גרסה נוכחית: ${Updater.currentBuild(ctx)}", fontSize = 16.sp, fontWeight = FontWeight.Medium)
        UpdateProgressView()
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton("בדוק עדכון", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) {
                Updater.check(ctx, manual = true)
            }
            if (avail != null) {
                BigButton("עדכן עכשיו", null, C.Teal, C.OnTeal, Modifier.weight(1f)) { Updater.downloadAndInstall(ctx) }
            }
        }
        if (st.isNotEmpty()) Text(st, color = if (avail != null) C.Teal else C.Muted, fontSize = 14.sp)
        val confirm by Updater.needsConfirm.collectAsState()
        if (confirm) {
            BigButton("הורד בכל זאת (בגלישה)", null, C.Surface, C.Amber, Modifier.fillMaxWidth(), outlined = true) {
                Updater.downloadAndInstall(ctx, force = true)
            }
        }
        PrefToggle("הורדת עדכונים רק ב-Wi-Fi", "כדי לא לבזבז חבילת גלישה", { Prefs.updWifiOnly }) { Prefs.updWifiOnly = it }
        Text("האפליקציה בודקת עדכונים לבד פעם ביום. בדיקה לא צורכת כמעט כלום – רק ההורדה.", color = C.Muted, fontSize = 12.sp)
        // למפתחים בלבד: לחיצה ארוכה פותחת הגדרות מתקדמות
        Text(
            if (advanced) "הסתר הגדרות מתקדמות" else "הגדרות מתקדמות", color = C.Border, fontSize = 12.sp,
            modifier = Modifier.clickable { advanced = !advanced }.padding(vertical = 4.dp)
        )
        if (advanced) {
            PrefText("מאגר (ריק = מובנה)", "username/repo", { Prefs.updRepo }, { Prefs.updRepo = it.trim() }, ltr = true)
            PrefText("מפתח (ריק = מובנה)", "github_pat_…", { Prefs.updToken }, { Prefs.updToken = it }, secret = true)
        }
    }
}

@Composable
fun LogCard() {
    val ctx = LocalContext.current
    var ver by remember { mutableStateOf(0) }
    @Suppress("UNUSED_VARIABLE") val r = ver
    CardBox(padding = 16.dp) {
        Text("כשמשהו לא עובד: נסה שוב, ואז לחץ „שתף יומן“ ושלח למפתח.", color = C.Muted, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton("שתף יומן", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) {
                try {
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, DLog.text().takeLast(60_000))
                    ctx.startActivity(Intent.createChooser(i, "יומן נוגה").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                }
            }
            BigButton("נקה", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { DLog.clear(); ver++ }
        }
    }
}

@Composable
private fun AppRow(pkg: String, label: String, content: @Composable () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        AppIcon(pkg, 36.dp, label)
        Spacer(Modifier.width(12.dp))
        Box(Modifier.weight(1f)) { content() }
    }
}

@Composable
fun PermRow(title: String, sub: String, ok: Boolean, onFix: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = !ok) { onFix() }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = C.Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.width(10.dp))
        if (ok) {
            Icon(painterResource(R.drawable.ic_check), contentDescription = "מאושר", tint = C.Teal, modifier = Modifier.size(24.dp))
        } else {
            Text(
                "אשר", color = C.OnAmber, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(C.Amber)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
private fun PermissionsCard(key: Int, onRequest: (Array<String>) -> Unit, showAccessibility: Boolean) {
    val ctx = LocalContext.current
    val runtimeOk = remember(key) { Perms.runtimeOk(ctx) }
    val listenerOk = remember(key) { Perms.listenerOk(ctx) }
    val overlayOk = remember(key) { Perms.overlayOk(ctx) }
    val batteryOk = remember(key) { Perms.batteryOk(ctx) }
    val bgLocOk = remember(key) { Perms.backgroundLocOk(ctx) }
    val a11yOk = remember(key) { GateService.isEnabled(ctx) }
    val filesOk = remember(key) { VoiceNotes.canRead(ctx) }
    CardBox(padding = 16.dp) {
        PermRow("גישה להתראות", "כדי לקרוא הודעות ולשלוט במוזיקה", listenerOk) {
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        PermRow("מיקרופון, מיקום, אנשי קשר, טלפון, SMS ויומן", "לפקודות קוליות ולכל הפיצ׳רים", runtimeOk) {
            onRequest(Perms.runtimeList())
        }
        PermRow("מיקום גם ברקע", "בחר „לאפשר כל הזמן“ – בשביל השער, החניה והתראות מהירות", bgLocOk) {
            onRequest(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
        }
        PermRow("הצגה מעל אפליקציות אחרות", "כדי שמסך ההקראה יקפוץ בזמן נהיגה", overlayOk) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
        }
        PermRow("ללא הגבלת סוללה", "כדי שאנדרואיד לא ירדים את האפליקציה", batteryOk) {
            @SuppressLint("BatteryLife")
            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
            try { ctx.startActivity(i) } catch (e: Exception) { }
        }
        if (showAccessibility) {
            PermRow("גישה לכל הקבצים", "כדי להשמיע הודעות קוליות מוואטסאפ", filesOk) {
                try {
                    if (android.os.Build.VERSION.SDK_INT >= 30) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
                        )
                    } else {
                        onRequest(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE))
                    }
                } catch (e: Exception) {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            }
            PermRow("נגישות (לשער ולהפעלת שירים)", "Settings → נגישות → נוגה → הפעל", a11yOk) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }
}

// ------------------------------------------------------------------
// הגדרות בטלפון (כאן מגדירים הכל, ומסך הרכב מקבל אוטומטית)
// ------------------------------------------------------------------
@Composable
fun SettingsScreen(onBack: () -> Unit, onRole: () -> Unit) {
    val ctx = LocalContext.current
    val tick by UiBus.tick.collectAsState()
    val linked by Link.connected.collectAsState()
    var localTick by remember { mutableStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { localTick++ }
    val key = tick + localTick
    val devices = remember(key) { Perms.bondedDevices(ctx) }
    var cars by remember { mutableStateOf(Prefs.cars) }
    var pickGate by remember { mutableStateOf(false) }
    var gatePkg by remember { mutableStateOf(Prefs.gatePkg) }
    val seen = remember(key) { Store.seenPackages }
    var extra by remember { mutableStateOf(Prefs.extraApps) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        BackHeader("הגדרות", onBack)

        SectionTitle("הרשאות")
        PermissionsCard(key, { launcher.launch(it) }, showAccessibility = true)

        SectionTitle("מסך הרכב")
        CardBox(padding = 16.dp) {
            Text(if (linked) "מחובר למסך הרכב ✓" else "מסך הרכב לא מחובר כרגע", fontSize = 17.sp, fontWeight = FontWeight.Bold,
                color = if (linked) C.Teal else C.Text)
            Text(
                "1. חבר את מסך הרכב לנקודה החמה של הטלפון.\n2. התקן גם עליו את אותו קובץ ובחר „זה מסך הרכב“.\n3. ההגדרות כאן עוברות אליו אוטומטית.",
                color = C.Muted, fontSize = 14.sp, lineHeight = 21.sp
            )
            PrefChoice(
                "אפליקציית המוזיקה לשירים", listOf("yt" to "יוטיוב מיוזיק", "spotify" to "ספוטיפיי"),
                { Prefs.musicApp }, { Prefs.musicApp = it }
            )
            PrefChoice(
                "מאיפה מתנגנת המוזיקה?", listOf("phone" to "מהטלפון (בלוטוס)", "car" to "ממסך הרכב"),
                { Prefs.musicSource }, { Prefs.musicSource = it }
            )
        }

        SectionTitle("רכבים בבלוטוס (גיבוי, כשאין מסך מחובר)")
        CardBox(padding = 16.dp) {
            if (devices.isEmpty()) Text("אשר קודם את הרשאות הבלוטוס.", color = C.Muted, fontSize = 15.sp)
            devices.forEach { (name, addr) ->
                ToggleRow(name, null, addr in cars) { on ->
                    cars = if (on) cars + addr else cars - addr
                    Prefs.cars = cars
                    if (on) Prefs.carName = name
                }
            }
        }

        SectionTitle("אפליקציות להקראה")
        CardBox(padding = 16.dp) {
            SupportedApps.all.forEach { def ->
                AppRow(def.pkg, def.label) {
                    PrefToggle(def.label, def.sub, { Prefs.appEnabled(def) }) { Prefs.setAppEnabled(def, it) }
                }
            }
            val others = (seen + extra).filter { SupportedApps.find(it) == null }.distinct()
                .sortedBy { Perms.appLabel(ctx, it) }
            Text(
                if (others.isEmpty()) "אפליקציות אחרות (כמו מערכת משימות) יופיעו כאן אחרי שישלחו התראה ראשונה."
                else "כל שאר האפליקציות ששלחו התראות – הדלק את מה שתרצה לשמוע:",
                color = C.Muted, fontSize = 13.sp
            )
            others.forEach { pkg ->
                val label = Perms.appLabel(ctx, pkg)
                AppRow(pkg, label) {
                    ToggleRow(label, null, pkg in extra) { on ->
                        extra = if (on) extra + pkg else extra - pkg
                        Prefs.extraApps = extra
                    }
                }
            }
        }

        SectionTitle("אנשים חשובים וקבוצות")
        CardBox(padding = 16.dp) {
            PrefText("אנשים חשובים", "למשל: אמא, אשתי, הבוס", { Prefs.vipNames }, { Prefs.vipNames = it })
            PrefToggle("רק אנשים חשובים", "השאר יגיעו בסיכום כל 10 דקות", { Prefs.vipOnly }) { Prefs.vipOnly = it }
            PrefChoice(
                "קבוצות בוואטסאפ",
                listOf("all" to "הכל", "summary" to "רק סיכום", "mentions" to "רק כשמתייגים אותי", "none" to "בלי"),
                { Prefs.groupMode }, { Prefs.groupMode = it }
            )
            PrefText("השם שלי (לזיהוי תיוג)", "למשל: יוסי", { Prefs.myName }, { Prefs.myName = it })
        }

        SectionTitle("הקראה חכמה")
        CardBox(padding = 16.dp) {
            PrefToggle("איחוד הודעות", "„3 הודעות מדני“ במקום שלוש הקראות", { Prefs.groupMessages }) { Prefs.groupMessages = it }
            PrefToggle("מיילים מקוצרים", "רק שולח ונושא", { Prefs.shortEmails }) { Prefs.shortEmails = it }
            PrefToggle("שקט בזמן שיחה", "ההודעות יחכו לסוף השיחה ויסוכמו", { Prefs.silentInCalls }) { Prefs.silentInCalls = it }
            PrefToggle("הנמכה במקום עצירה", "המוזיקה ממשיכה בשקט ברקע", { Prefs.duck }) { Prefs.duck = it }
            PrefToggle("צליל לכל אפליקציה", "לדעת ממה ההודעה עוד לפני ההקראה", { Prefs.appSounds }) { Prefs.appSounds = it }
            PrefToggle("ניקוד לפני הקראה", "מבטאת נכון יותר (הניקוד לא מוצג). דורש אינטרנט", { Prefs.nikud }) { Prefs.nikud = it }
            PrefToggle("השמעת הודעות קוליות", "„הודעה קולית מדני, 12 שניות“ ואז משמיעה אותה", { Prefs.voiceNotes }) { Prefs.voiceNotes = it }
            PrefToggle("תרגום לעברית", "הודעות באנגלית, רוסית, ערבית ועוד", { Prefs.translate }) { Prefs.translate = it }
            PrefToggle("סיכום הודעות ארוכות", "דרך Gemini, אם הוגדר מפתח", { Prefs.summarizeLong }) { Prefs.summarizeLong = it }
            PrefToggle("קודי אימות ספרה-ספרה", "קודים מוקראים לאט", { Prefs.otp }) { Prefs.otp = it }
            PrefToggle("סינון ספאם", "פרסומות לא יוקראו", { Prefs.spamFilter }) { Prefs.spamFilter = it }
            PrefText("מילים של ספאם", "מבצע, הנחה…", { Prefs.spamWords }, { Prefs.spamWords = it })
            PrefToggle("סיכום בכניסה לרכב", "„מחכות לך 3 הודעות בוואטסאפ“", { Prefs.startSummary }) { Prefs.startSummary = it }
            PrefToggle("הכרזה בכניסה לרכב", "„מצב נהיגה פעיל“", { Prefs.announceStart }) { Prefs.announceStart = it }
        }

        SectionTitle("תגובות")
        CardBox(padding = 16.dp) {
            PrefToggle("תגובה קולית", "אחרי הקראה אפשר לומר „תעני לו…“", { Prefs.voiceReply }) { Prefs.voiceReply = it }
            PrefChoice(
                "הודעה חדשה לאדם („תשלחי לדני…“) נשלחת ב:", listOf("whatsapp" to "וואטסאפ", "sms" to "SMS"),
                { Prefs.msgChannel }, { Prefs.msgChannel = it }
            )
            PrefChoice(
                "מאיזה וואטסאפ לשלוח (כשיש שניים):",
                listOf("ask" to "לשאול כל פעם", "com.whatsapp" to "רגיל", "com.whatsapp.w4b" to "עסקי"),
                { Prefs.waChoice }, { Prefs.waChoice = it }
            )
            Text("אפשר גם לומר: „תשלחי מהעסקי לדני ש…“. הודעות מהתיקייה המאובטחת או מפרופיל העבודה מוקראות עם ציון המקום, ואפשר לענות עליהן. שליחת הודעה חדשה אפשרית רק מהוואטסאפים הרגילים.",
                color = C.Muted, fontSize = 12.sp)
            PrefToggle("שליחה אוטומטית", "נשלחת אלא אם אמרת „בטל“", { Prefs.autoSend }) { Prefs.autoSend = it }
            PrefToggle("הקראת התגובה לפני שליחה", "כדי לוודא שהיא שמעה נכון", { Prefs.readBack }) { Prefs.readBack = it }
            PrefText("תגובות מהירות (כפתורים במסך)", "מופרדות בפסיק", { Prefs.quickReplies }, { Prefs.quickReplies = it })
            PrefToggle("מענה אוטומטי „אני נוהג“", "פעם אחת לכל אדם בנסיעה", { Prefs.autoReplyDriving }) { Prefs.autoReplyDriving = it }
            PrefToggle("SMS אוטומטי לשיחה שלא נענתה", "שולח את אותו נוסח", { Prefs.missedCallSms }) { Prefs.missedCallSms = it }
            PrefText("נוסח המענה האוטומטי", "", { Prefs.autoReplyText }, { Prefs.autoReplyText = it })
        }

        SectionTitle("שער ובית")
        CardBox(padding = 16.dp) {
            PrefToggle("פתיחת שער אוטומטית", "כשמתקרבים הביתה", { Prefs.gateEnabled }) { Prefs.gateEnabled = it }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (gatePkg.isNotBlank()) {
                    AppIcon(gatePkg, 36.dp)
                    Spacer(Modifier.width(12.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text("אפליקציית השער", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text(if (gatePkg.isBlank()) "לא נבחרה" else Perms.appLabel(ctx, gatePkg), color = C.Muted, fontSize = 13.sp)
                }
                Text("בחר", color = C.Amber, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { pickGate = true }.padding(8.dp))
            }
            GatesEditor()
            PrefToggle("הודעת הגעה", "„אני מגיע בעוד כמה דקות“ כשמתקרבים הביתה", { Prefs.arrivalEnabled }) { Prefs.arrivalEnabled = it }
            PrefText("למי לשלוח הודעת הגעה", "למשל: אשתי", { Prefs.arrivalContact }, { Prefs.arrivalContact = it })
        }

        SectionTitle("נהיגה ובטיחות")
        CardBox(padding = 16.dp) {
            PrefToggle("תזכורת הפסקה", "אחרי שעתיים נהיגה רצופה", { Prefs.breakReminder }) { Prefs.breakReminder = it }
            PrefToggle("בדיקת מושב אחורי", "כשמכבים את הרכב", { Prefs.backSeat }) { Prefs.backSeat = it }
            PrefToggle("התראת מהירות", null, { Prefs.speedAlert }) { Prefs.speedAlert = it }
            PrefSlider("מהירות להתראה", 50f..140f, { Prefs.speedLimit }, { Prefs.speedLimit = it }) { "${it.toInt()} קמ״ש" }
            PrefToggle("ווליום לפי מהירות", "המוזיקה מתחזקת בכביש מהיר", { Prefs.volumeBySpeed }) { Prefs.volumeBySpeed = it }
            PrefToggle("בוקר טוב", "מזג אוויר ופגישה ראשונה בנסיעה הראשונה ביום", { Prefs.morningBrief }) { Prefs.morningBrief = it }
            PrefToggle("אזהרת גשם", "בכניסה לרכב", { Prefs.rainAlert }) { Prefs.rainAlert = it }
            PrefToggle("המשך מוזיקה אוטומטי", "בכניסה לרכב", { Prefs.autoResumeMusic }) { Prefs.autoResumeMusic = it }
            PrefText("אנשי קשר לחירום", "למשל: אשתי, אבא", { Prefs.emergencyContacts }, { Prefs.emergencyContacts = it })
            PrefText("תאריך טסט", "dd/MM/yyyy", { Prefs.testDate }, { Prefs.testDate = it })
            PrefText("תאריך חידוש ביטוח", "dd/MM/yyyy", { Prefs.insuranceDate }, { Prefs.insuranceDate = it })
            PrefText("תאריך טיפול הבא", "dd/MM/yyyy", { Prefs.serviceDate }, { Prefs.serviceDate = it })
        }

        SectionTitle("בלי ידיים")
        CardBox(padding = 16.dp) {
            PrefToggle("מילת הפעלה", "מאזינה כל הזמן במסך הרכב, בלי לעצור מוזיקה ובלי אינטרנט", { Prefs.wakeEnabled }) { Prefs.wakeEnabled = it }
            PrefText("איך קוראים לעוזרת", "נוגה", { Prefs.assistantName }, { Prefs.assistantName = it })
            val tickWake by UiBus.tick.collectAsState()
            androidx.compose.runtime.key(tickWake) {
                PrefText("איך המיקרופון שומע את השם (באנגלית)", "hey noga, no go", { Prefs.wakePhrase }, { Prefs.wakePhrase = it })
            }
            Text(
                "הכי קל: במסך הרכב, בהגדרות, לחץ „כיול מילת הפעלה“, אמור „היי נוגה“ 3–4 פעמים ולחץ „השתמש בזה“. זה יתעדכן כאן לבד. " +
                    "אפשר כמה אפשרויות מופרדות בפסיק. בפעם הראשונה מסך הרכב מוריד מודל זיהוי של כ-40MB.",
                color = C.Muted, fontSize = 13.sp, lineHeight = 19.sp
            )
            PrefChoice(
                "קוד שפה לזיהוי דיבור", listOf("he-IL" to "he-IL", "iw-IL" to "iw-IL (מכשירים ישנים)"),
                { Prefs.sttLang }, { Prefs.sttLang = it }
            )
            PrefToggle("נקודה חמה אוטומטית (ניסיוני)", "בכניסה לרכב לוחצת לך על „נקודה חמה“. עדיף: שגרה של סמסונג", { Prefs.autoHotspot }) { Prefs.autoHotspot = it }
            PrefToggle("שאלה בתחילת נסיעה", "„להקריא לך הודעות בנסיעה הזאת?“", { Prefs.askAtStart }) { Prefs.askAtStart = it }
            PrefToggle("שיחה רציפה", "אחרי תשובה ממשיכה להקשיב לפקודה הבאה", { Prefs.followUp }) { Prefs.followUp = it }
            PrefToggle("מענה לשיחות בקול", "„דני מתקשר“ → „תעני“ / „תדחי“", { Prefs.voiceCalls }) { Prefs.voiceCalls = it }
            PrefToggle("טלפון שקט בנסיעה", "בלי צלילי התראות – הרכב מקריא ממילא", { Prefs.muteNotifications }) { Prefs.muteNotifications = it }
            PrefToggle("וייז נפתח לבד", "בבוקר לעבודה, אחר הצהריים הביתה", { Prefs.autoWaze }) { Prefs.autoWaze = it }
        }

        SectionTitle("ספר רכב ונסיעות")
        CardBox(padding = 16.dp) {
            var odoText by remember { mutableStateOf(CarBook.odometer()?.toLong()?.toString() ?: "") }
            Text(CarBook.status(), fontSize = 15.sp, fontWeight = FontWeight.Medium)
            PrefText("קילומטראז׳ נוכחי (מהשעון ברכב)", "למשל 85000", { odoText }, { v ->
                odoText = v
                v.filter { it.isDigit() }.toDoubleOrNull()?.let { CarBook.setOdometer(it) }
            })
            PrefText("טיפול כל (ק״מ)", "15000", { Prefs.serviceInterval }, { Prefs.serviceInterval = it.filter { c -> c.isDigit() } })
            PrefText("קילומטראז׳ בטיפול האחרון", "למשל 75000", { Prefs.lastServiceOdo.toDoubleOrNull()?.toLong()?.toString() ?: "" }, {
                Prefs.lastServiceOdo = it.filter { c -> c.isDigit() }
            })
            var workSaved by remember { mutableStateOf(Prefs.workLat.isNotBlank()) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("מקום העבודה", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text(
                        if (workSaved) "נשמר ✓ – נסיעות שמתחילות או נגמרות שם יסומנו „עסקי“" else "עמוד בעבודה ולחץ „שמור“",
                        color = C.Muted, fontSize = 13.sp
                    )
                }
                Text("שמור", color = C.Amber, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                    val l = Perms.currentLocation(ctx)
                    if (l != null) {
                        Prefs.workLat = l.latitude.toString(); Prefs.workLng = l.longitude.toString(); workSaved = true
                    }
                }.padding(8.dp))
            }
            Text("בנסיעה אפשר גם לומר „הנסיעה הזאת עסקית“ או „פרטית“, „עשיתי טיפול“, „כמה נשאר לטיפול?“",
                color = C.Muted, fontSize = 13.sp)
        }

        SectionTitle("קול ועוזר")
        CardBox(padding = 16.dp) {
            PrefSlider("מהירות הקראה", 0.6f..1.6f, { Prefs.speechRate }, { Prefs.speechRate = it }) {
                when {
                    it < 0.85f -> "איטית"
                    it > 1.2f -> "מהירה"
                    else -> "רגילה"
                }
            }
                        PrefText("כינויים", "אהובה=רונית כהן (שורה לכל כינוי)", { Prefs.nicknames }, { Prefs.nicknames = it }, multiline = true)
            PrefText("תיקון הגייה", "Gmail=ג׳ימייל (שורה לכל מילה)", { Prefs.pronunciation }, { Prefs.pronunciation = it }, multiline = true)
            var radioVer by remember { mutableStateOf(0) }
            var radioMsg by remember { mutableStateOf("") }
            Text("${Radio.stations().size} תחנות ברשימה", fontSize = 15.sp, fontWeight = FontWeight.Medium)
            BigButton("טען את כל תחנות הרדיו בישראל", null, C.Surface, C.Text, Modifier.fillMaxWidth(), outlined = true) {
                radioMsg = "טוענת…"
                Radio.loadAllIsraeli { n ->
                    radioMsg = if (n > 0) "נטענו $n תחנות ✓" else "לא הצלחתי לטעון (אין אינטרנט?)"
                    if (n > 0) Prefs.radioLoaded = true
                    radioVer++
                }
            }
            if (radioMsg.isNotEmpty()) Text(radioMsg, color = C.Teal, fontSize = 14.sp)
            @Suppress("UNUSED_VARIABLE") val rv = radioVer
        }

        SectionTitle("Gemini – הבנה חופשית ושאלות (חינמי)")
        CardBox(padding = 16.dp) {
            Text("מפתח חינמי מקבלים ב-aistudio.google.com. בלי מפתח, כל הפקודות הרגילות עובדות.", color = C.Muted, fontSize = 13.sp)
            PrefText("מפתח API", "הדבק כאן", { Prefs.geminiKey }, { Prefs.geminiKey = it }, secret = true)
            PrefText("מודל (נבחר לבד אם השם לא קיים)", "gemini-flash-latest", { Prefs.geminiModel }, { Prefs.geminiModel = it.trim() }, ltr = true)
            var geminiResult by remember { mutableStateOf("") }
            var geminiOk by remember { mutableStateOf(false) }
            BigButton("בדיקת המפתח", null, C.Surface, C.Text, Modifier.fillMaxWidth(), outlined = true) {
                geminiResult = "בודקת…"
                Gemini.test { (ok, msg) -> geminiOk = ok; geminiResult = msg }
            }
            if (geminiResult.isNotEmpty()) {
                Text(geminiResult, color = if (geminiOk) C.Teal else C.Amber, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }

        SectionTitle("עדכונים")
        UpdatesCard()

        SectionTitle("יומן פעולות (לאבחון)")
        LogCard()

        SectionTitle("צריכת אינטרנט")
        CardBox(padding = 16.dp) {
            var dv by remember { mutableStateOf(0) }
            @Suppress("UNUSED_VARIABLE") val d0 = dv
            Text("נוגה במכשיר הזה: %.1f MB".format(DataUsage.totalMb(ctx)), fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text("רדיו צורך כ-60MB לשעה. מסך הרכב צורך דרך הנקודה החמה, ומופיע אצלו בנפרד.", color = C.Muted, fontSize = 12.sp)
            Text("אפס מונה", color = C.Amber, modifier = Modifier.clickable { DataUsage.reset(ctx); dv++ }.padding(vertical = 6.dp))
        }

        SectionTitle("מה היא למדה")
        CardBox(padding = 16.dp) {
            var learned by remember(key) { mutableStateOf(Learn.all()) }
            if (learned.isEmpty()) {
                Text("עוד לא למדה כלום. כשהיא לא מבינה, פשוט תגיד את זה אחרת, או „לא, התכוונתי ל…“, והיא תזכור.",
                    color = C.Muted, fontSize = 14.sp)
            }
            learned.forEach { (k, v) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("„$k“", fontSize = 15.sp)
                        Text("← $v", color = C.Muted, fontSize = 13.sp)
                    }
                    Text("✕", color = C.Muted, modifier = Modifier.clickable { Learn.remove(k); learned = Learn.all() }.padding(8.dp))
                }
            }
        }

        SectionTitle("בדיקות")
        CardBox(padding = 16.dp) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton("בדיקת קול", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { Announcer.testVoice() }
                BigButton("הודעת בדיקה", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { Announcer.testMessage() }
            }
            BigButton("בדיקת שיר ביוטיוב מיוזיק", null, C.Surface, C.Text, Modifier.fillMaxWidth(), outlined = true) {
                Media.playSearch(ctx, "עומר אדם תל אביב", Media.YT_MUSIC)
            }
            Text("אחרי הבדיקה, ב„יומן פעולות“ יופיעו שורות עם 🎵 שמראות מה קרה בכל שלב.", color = C.Muted, fontSize = 12.sp)
            Text("החלף תפקיד מכשיר", color = C.Amber, fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { onRole() }.padding(vertical = 8.dp))
        }

        Text("נוגה · גרסה ${BuildInfo.version(ctx)}", color = C.Muted, fontSize = 13.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
    }

    if (pickGate) {
        val apps = remember { Perms.launcherApps(ctx) }
        AlertDialog(
            onDismissRequest = { pickGate = false },
            containerColor = C.Surface,
            title = { Text("בחר את אפליקציית השער") },
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(apps) { (label, pkg) ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                Prefs.gatePkg = pkg; Prefs.gateLabel = label; gatePkg = pkg; pickGate = false
                            }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(pkg, 32.dp, label)
                            Spacer(Modifier.width(12.dp))
                            Text(label, fontSize = 17.sp)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickGate = false }) { Text("סגור", color = C.Amber) } }
        )
    }
}

// ------------------------------------------------------------------
// הגדרות במסך הרכב
// ------------------------------------------------------------------
@Composable
fun CarSettingsScreen(onBack: () -> Unit, onRole: () -> Unit) {
    val ctx = LocalContext.current
    val tick by UiBus.tick.collectAsState()
    val status by Link.status.collectAsState()
    val linked by Link.connected.collectAsState()
    var localTick by remember { mutableStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { localTick++ }
    val key = tick + localTick

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        BackHeader("הגדרות מסך הרכב", onBack)
        CardBox(padding = 16.dp) {
            Text(if (linked) "מחובר לטלפון ✓" else status, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                color = if (linked) C.Teal else C.Amber)
            Text(
                "חבר את המסך לנקודה החמה של הטלפון, ופתח את „נוגה“ בטלפון. כל ההגדרות נעשות בטלפון ועוברות לכאן אוטומטית.",
                color = C.Muted, fontSize = 14.sp, lineHeight = 21.sp
            )
            PrefText("כתובת הטלפון (רק אם החיבור לא מצליח)", "ריק = אוטומטי", { Prefs.linkIp }, { Prefs.linkIp = it })
            val wakeStatus by Wake.status.collectAsState()
            Text("מילת הפעלה: $wakeStatus", color = C.Muted, fontSize = 14.sp)
        }
        SectionTitle("כיול מילת הפעלה")
        CardBox(padding = 16.dp) {
            val heard by Wake.calibHeard.collectAsState()
            val results by Wake.calibResults.collectAsState()
            var calibrating by remember { mutableStateOf(false) }
            Text(
                "לחץ „התחל“, אמור את שם העוזרת (למשל „היי נוגה“) 3–4 פעמים, ולחץ „השתמש בזה“.",
                color = C.Muted, fontSize = 14.sp
            )
            Text(if (heard.isBlank()) "…" else "שומע: $heard", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (results.isNotEmpty()) Text("נשמע: " + results.joinToString(" · "), color = C.Muted, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton(if (calibrating) "עצור" else "התחל", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) {
                    if (calibrating) {
                        Wake.stopCalibration(); calibrating = false
                    } else {
                        Wake.startCalibration(ctx); calibrating = true
                    }
                }
                BigButton("השתמש בזה", null, C.Teal, C.OnTeal, Modifier.weight(1f)) {
                    val best = Wake.bestCalibration()
                    if (best != null) {
                        Prefs.wakePhrase = best
                        Link.send(Link.obj("setpref", "k" to "wakePhrase", "v" to best))
                        Wake.stopCalibration(); calibrating = false
                        Announcer.notice("מעכשיו אגיב ל-$best")
                    }
                }
            }
        }
        SectionTitle("הרשאות")
        PermissionsCard(key, { launcher.launch(it) }, showAccessibility = true)
        SectionTitle("עדכונים")
        UpdatesCard()
        SectionTitle("יומן פעולות (לאבחון)")
        LogCard()
        CardBox(padding = 16.dp) {
            Text("נוגה במסך הרכב: %.1f MB (כולל רדיו ומודל הזיהוי)".format(DataUsage.totalMb(ctx)), fontSize = 15.sp)
        }
        SectionTitle("בדיקות")
        CardBox(padding = 16.dp) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton("בדיקת קול", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { Announcer.testVoice() }
                BigButton("הודעת בדיקה", null, C.Surface, C.Text, Modifier.weight(1f), outlined = true) { Announcer.testMessage() }
            }
            Text("החלף תפקיד מכשיר", color = C.Amber, fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { onRole() }.padding(vertical = 8.dp))
        }
        Text("גרסה ${BuildInfo.version(ctx)}", color = C.Muted, fontSize = 13.sp)
    }
}

object BuildInfo {
    fun version(c: android.content.Context): String = try {
        c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }
}

@Suppress("unused")
private val unusedColor = Color.Transparent
