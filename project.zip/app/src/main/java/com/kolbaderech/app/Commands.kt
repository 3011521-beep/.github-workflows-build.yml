package com.kolbaderech.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** הבנת פקודות בעברית לפי מילות מפתח. עובד בלי אינטרנט ובחינם. */
object Commands {
    const val UNKNOWN = "__unknown__"
    const val UNKNOWN_SAY = "לא הבנתי. אפשר לומר למשל: השיר הבא, תדליקי עומר אדם, נווטי הביתה או תפתחי את השער"

    private fun clean(s: String) =
        s.replace(Regex("[\"״'׳?!.,:]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }
    private fun word(t: String, vararg w: String): Boolean {
        val words = t.split(" ")
        return w.any { it in words }
    }

    private fun startsAny(t: String, prefixes: List<String>): String? =
        prefixes.sortedByDescending { it.length }.firstOrNull { t.startsWith(it) }

    // ================= תגובות =================
    private val replyPrefixes = listOf(
        "תעני לו", "תעני לה", "תעני להם", "תעני", "עני לו", "עני לה",
        "תגיבי לו", "תגיבי לה", "תגיבי", "תכתבי לו", "תכתבי לה", "תכתבי",
        "תשיבי לו", "תשיבי לה", "תגידי לו", "תגידי לה", "תשלחי לו", "תשלחי לה"
    )

    private val afterShin = listOf(
        "אני", "את", "אתה", "הוא", "היא", "אנחנו", "זה", "אין", "יש", "כן", "לא",
        "אגיע", "אחזור", "אתקשר", "נדבר", "נתראה", "אהיה", "הכל", "אבוא", "מגיע", "בדרך", "תודה"
    )

    private fun stripShin(r: String): String {
        if (r.startsWith("ש") && r.length > 1) {
            val rest = r.substring(1)
            if (afterShin.any { rest.startsWith(it) }) return rest
        }
        return r
    }

    fun extractReply(heard: String): String? {
        val t = clean(heard)
        val p = startsAny(t, replyPrefixes) ?: return null
        return stripShin(t.removePrefix(p).trim()).ifBlank { null }
    }

    fun replyFromAnything(heard: String): String? {
        val t = clean(heard)
        if (isCancel(t) || isStop(t)) return null
        return extractReply(t) ?: stripShin(t).ifBlank { null }
    }

    fun changeTo(heard: String): String? {
        val t = clean(heard)
        val p = startsAny(t, listOf("תשני ל", "תשני את זה ל", "תחליפי ל", "במקום זה", "לא תכתבי", "תכתבי במקום")) ?: return null
        return stripShin(t.removePrefix(p).trim()).ifBlank { null }
    }

    fun isCancel(heard: String): Boolean {
        val t = clean(heard)
        return t.split(" ").size <= 3 && word(t, "בטל", "בטלי", "תבטלי", "ביטול", "לא", "אל")
    }

    fun isYes(heard: String) = word(clean(heard), "כן", "שלחי", "תשלחי", "שלח", "בטח", "יאללה")
    fun isStop(heard: String) = word(clean(heard), "עצרי", "תעצרי", "עצור", "תפסיקי", "הפסיקי", "די", "תשתקי")
    fun isDone(heard: String): Boolean {
        val t = clean(heard)
        return t.split(" ").size <= 3 && (word(t, "זהו", "תודה", "לא", "סיימתי", "כלום", "ביי") || has(t, "זה הכל", "זה הכול"))
    }

    fun isAnswer(heard: String) = has(clean(heard), "תעני", "ענה", "תענה", "עני", "כן", "קבלי", "תקבלי")
    fun isReject(heard: String) = has(clean(heard), "תדחי", "דחה", "תדחה", "תנתקי", "לא עכשיו", "אחר כך") || word(clean(heard), "לא")

    /** תשובה לשאלה "להקריא הודעות בנסיעה הזאת?" */
    fun isNoReading(heard: String): Boolean {
        val t = clean(heard)
        if (word(t, "כן", "בטח", "יאללה", "אוקיי", "תקריאי", "בסדר")) return false
        return word(t, "לא", "אל", "בלי", "תשתקי", "שקט", "תסתמי", "סתמי", "שתקי") || has(t, "אין צורך", "לא צריך", "לא רוצה")
    }

    /** "תעני לדני שאני בדרך" → (דני, אני בדרך). "תעני לו" → ("", null). */
    fun replyTarget(heard: String): Pair<String, String?>? {
        val t = clean(heard)
        val p = startsAny(t, listOf("תעני ל", "תגיבי ל", "תשיבי ל", "עני ל", "תענה ל", "תגיב ל", "תעני", "תגיבי", "תשיבי")) ?: return null
        val rest = t.removePrefix(p).trim()
        if (rest.isEmpty()) return "" to null
        val words = rest.split(" ")
        if (words[0] == "לו" || words[0] == "לה" || words[0] == "ו" || words[0] == "ה") {
            val txt = stripShin(words.drop(1).joinToString(" ").trim())
            return "" to txt.ifBlank { null }
        }
        val k = words.indexOfFirst { it.startsWith("ש") && words.indexOf(it) > 0 }
        return if (k > 0) {
            words.take(k).joinToString(" ") to stripShin(words.drop(k).joinToString(" ")).ifBlank { null }
        } else {
            words.take(3).joinToString(" ") to null
        }
    }

    fun isLater(heard: String) = has(clean(heard), "לאחר כך", "אחר כך", "כשאני חונה", "תשמרי")

    // ================= ניתוב בין מסך הרכב לטלפון =================
    /** במסך הרכב: פקודות שצריכות את הטלפון נשלחות אליו. */
    private fun forwardToPhone(text: String): Boolean {
        if (Prefs.isCar && Link.connected.value) {
            Link.send(Link.obj("cmd", "text" to text))
            return true
        }
        return false
    }

    private fun mediaRemote() = Prefs.isCar && Link.connected.value && Prefs.musicSource == "phone"

    private fun mediaOp(ctx: Context, op: String) {
        if (mediaRemote()) Link.send(Link.obj("media", "op" to op)) else Media.op(ctx, op)
    }

    // ================= זמנים =================
    private fun parseMinutes(t: String): Pair<Int, String>? {
        val words = mapOf("חצי שעה" to 30, "רבע שעה" to 15, "שעתיים" to 120, "דקה" to 1, "שעה" to 60)
        val m = Regex("בעוד (\\d+) ?(דקות|דקה|שעות|שעה)").find(t)
        if (m != null) {
            val n = m.groupValues[1].toInt()
            val mins = if (m.groupValues[2].startsWith("שע")) n * 60 else n
            return mins to t.replace(m.value, " ")
        }
        for ((w, mins) in words) {
            val phrase = "בעוד $w"
            if (t.contains(phrase)) return mins to t.replace(phrase, " ")
        }
        return null
    }

    private fun parseDayHour(t: String): Long? {
        val cal = Calendar.getInstance()
        when {
            t.contains("מחרתיים") -> cal.add(Calendar.DAY_OF_YEAR, 2)
            t.contains("מחר") -> cal.add(Calendar.DAY_OF_YEAR, 1)
            else -> {
                val days = listOf("ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת")
                val idx = days.indexOfFirst { t.contains("ביום $it") || t.contains("יום $it") }
                if (idx >= 0) {
                    val target = idx + 1 // Calendar.SUNDAY = 1
                    var diff = target - cal.get(Calendar.DAY_OF_WEEK)
                    if (diff <= 0) diff += 7
                    cal.add(Calendar.DAY_OF_YEAR, diff)
                }
            }
        }
        val m = Regex("ב[- ]?(\\d{1,2})(?:[:.](\\d{2}))?").find(t) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].toIntOrNull() ?: 0
        if (h in 1..7 && (t.contains("אחר הצהריים") || t.contains("בערב"))) h += 12
        if (h > 23) return null
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, min)
        cal.set(Calendar.SECOND, 0)
        return cal.timeInMillis
    }

    // ================= למידה ותיקונים =================
    /** האם המשפט מובן (בלי לבצע אותו). */
    fun understands(ctx: Context, heard: String): Boolean =
        Learn.lookup(heard) != null || replyTarget(heard) != null || correction(heard) != null ||
            Intents.classify(ctx, heard) != null

    /** "לא, התכוונתי ל…" → מחזיר את מה שהתכוונת. */
    fun correction(heard: String): String? {
        val t = clean(heard)
        val p = startsAny(
            t, listOf(
                "לא התכוונתי ל", "לא התכוונתי ש", "לא התכוונתי", "לא אמרתי", "התכוונתי ל", "התכוונתי ש",
                "התכוונתי", "טעית התכוונתי", "טעית", "לא נכון", "לא זה", "לא לא"
            )
        ) ?: return null
        return t.removePrefix(p).trim().ifBlank { null }
    }

    private val PHONE_ONLY = setOf(
        "gate", "call", "callback", "sos", "send_msg", "send_location", "arrival", "reminder", "place_reminder",
        "cal_add", "cal_query", "note_add", "note_read", "shop", "parking_where", "parking_note", "fuel_log",
        "fuel_sum", "stats", "trip_type", "service_done", "service_left", "odometer"
    )

    // ================= הפקודות =================
    /**
     * מבצע את הפקודה. מחזיר משפט להקראה, null אם אין מה להגיד,
     * או UNKNOWN אם לא הבין.
     */
    fun handle(ctx: Context, heard: String, depth: Int = 0): String? {
        val t = clean(heard)
        if (t.isEmpty()) return UNKNOWN

        // משפט שלמדתי בעבר
        if (depth == 0) Learn.lookup(heard)?.let { return handle(ctx, it, 1) }
        if (has(t, "תשכחי", "תמחקי") && has(t, "למדת")) {
            Learn.clear(); return "שכחתי את כל מה שלמדתי"
        }

        // "מה דני כתב?"
        Regex("מה (.+?) (כתב|כתבה|שלח|שלחה)$").find(t)?.let { m ->
            val name = m.groupValues[1].removePrefix("ש").trim()
            if (name in listOf("הוא", "היא", "הם", "רשמתי", "כתבתי")) {
                return if (Announcer.repeatLast()) null else "אין הודעה להקריא שוב"
            }
            val h = Announcer.history.value.firstOrNull { it.sender.contains(name) }
            return if (h != null) "${h.sender} כתב: ${h.text}" else "לא קיבלתי הודעות מ-$name בנסיעה הזאת"
        }
        // המרת מטבע
        Regex("כמה זה (\\d+(?:\\.\\d+)?) ?(דולר|יורו|פאונד|שקל|שקלים)").find(t)?.let { m ->
            val amount = m.groupValues[1].toDouble()
            val from = when {
                m.groupValues[2].startsWith("דולר") -> "USD"
                m.groupValues[2].startsWith("יורו") -> "EUR"
                m.groupValues[2].startsWith("פאונד") -> "GBP"
                else -> "ILS"
            }
            val to = if (from != "ILS") "ILS" else if (t.contains("ביורו")) "EUR" else "USD"
            val toName = mapOf("ILS" to "שקלים", "USD" to "דולר", "EUR" to "יורו")[to] ?: to
            Net.async({ Net.convert(amount, from, to) }) { r ->
                Announcer.notice(if (r == null) "לא הצלחתי לבדוק שער כרגע" else "זה בערך ${"%.0f".format(r)} $toName")
            }
            return null
        }
        // מחשבון
        Regex("(\\d+(?:\\.\\d+)?) ?(כפול|ועוד|פלוס|פחות|מינוס|חלקי|לחלק ל) ?(\\d+(?:\\.\\d+)?)").find(t)?.let { m ->
            val a = m.groupValues[1].toDouble()
            val b = m.groupValues[3].toDouble()
            val r = when (m.groupValues[2]) {
                "כפול" -> a * b
                "ועוד", "פלוס" -> a + b
                "פחות", "מינוס" -> a - b
                else -> if (b == 0.0) return "אי אפשר לחלק באפס" else a / b
            }
            val s = if (r == Math.floor(r)) r.toLong().toString() else "%.2f".format(r)
            return "זה $s"
        }

        val r = Intents.classify(ctx, heard) ?: return UNKNOWN
        if (r.id in PHONE_ONLY && forwardToPhone(heard)) return null
        val slot = r.slot.trim()

        return when (r.id) {
            "sos" -> sos(ctx)
            "gate" -> {
                Announcer.iconHint = Prefs.gatePkg.ifBlank { null }
                Gate.open(ctx)
            }
            "trip_type" -> {
                val business = has(t, "עסק", "עבודה", "לחברה")
                Prefs.pendingTripType = if (business) "business" else "private"
                if (business) "רשמתי שהנסיעה הזאת עסקית" else "רשמתי שהנסיעה הזאת פרטית"
            }
            "service_done" -> CarBook.serviceDone(t)
            "service_left" -> CarBook.status()
            "odometer" -> {
                val m = Regex("(\\d+(?:[.,]\\d+)?)\\s*(אלף)?").find(t) ?: return "כמה קילומטר מראה הרכב?"
                var km = m.groupValues[1].replace(",", "").toDouble()
                if (m.groupValues[2].isNotEmpty()) km *= 1000
                CarBook.setOdometer(km)
                "רשמתי: ${km.toInt()} קילומטר. מעכשיו אעדכן לבד לפי הנסיעות"
            }
            "address" -> {
                Announcer.iconHint = "com.waze"
                Nav.to(ctx, t.removePrefix("כתובת").trim()); null
            }
            "mute_msgs" -> {
                Announcer.muteNow()
                "בסדר, לא אקריא הודעות עד סוף הנסיעה"
            }
            "unmute_msgs" -> {
                Announcer.muted = false
                "חזרתי להקריא הודעות"
            }
            "radio_off" -> {
                Radio.stop(ctx); null
            }
            "radio_on" -> {
                val st = Radio.find(t) ?: Radio.stations().firstOrNull() ?: return "אין תחנות רדיו בהגדרות"
                Radio.play(ctx, st)
            }
            "nav_home" -> {
                Announcer.iconHint = "com.waze"
                Nav.home(ctx); "מנווטת הביתה"
            }
            "nav_work" -> {
                Announcer.iconHint = "com.waze"
                Nav.work(ctx); "מנווטת לעבודה"
            }
            "repeat" -> if (Announcer.repeatLast()) null else "אין הודעה להקריא שוב"
            "parking_where" -> parkingWhere(ctx)
            "fuel_log" -> {
                val n = Regex("(\\d+)").find(t)?.value ?: return "בכמה תדלקת?"
                Store.add(Store.FUEL, JSONObject().put("amount", n.toInt()).put("time", System.currentTimeMillis()))
                "רשמתי תדלוק ב-$n שקל"
            }
            "fuel_sum" -> {
                val monthStart = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                }.timeInMillis
                val sum = Store.list(Store.FUEL).filter { it.optLong("time") >= monthStart }.sumOf { it.optInt("amount") }
                "החודש הוצאת $sum שקל על דלק"
            }
            "stats" -> Stats.monthSummary()
            "time" -> "השעה " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(System.currentTimeMillis())
            "what_song" -> whatSong(ctx)
            "vol_down" -> {
                Media.volume(ctx, false); null
            }
            "vol_up" -> {
                Media.volume(ctx, true); null
            }
            "media_prev" -> {
                mediaOp(ctx, "prev"); null
            }
            "media_next" -> {
                mediaOp(ctx, "next"); null
            }
            "mood" -> {
                val q = when {
                    has(t, "שקט", "רגוע") -> "מוזיקה שקטה ורגועה"
                    has(t, "קצבי", "מסיבה") -> "שירים קצביים"
                    has(t, "שמח") -> "שירים שמחים"
                    has(t, "מזרחי") -> "להיטים מזרחיים"
                    has(t, "ישראלי") -> "להיטים ישראליים"
                    else -> "להיטים"
                }
                if (mediaRemote()) {
                    forwardToPhone("תדליקי $q ביוטיוב מיוזיק")
                } else {
                    Media.playSearch(ctx, q, Media.YT_MUSIC)
                }
                null
            }
            "pause" -> {
                mediaOp(ctx, "pause"); null
            }
            "resume" -> {
                mediaOp(ctx, "play"); null
            }
            "weather" -> {
                Net.async({ Net.weather(Store.lastLat, Store.lastLng) }) { w ->
                    Announcer.notice(w ?: "לא הצלחתי לבדוק מזג אוויר כרגע")
                }
                null
            }
            "news" -> {
                Net.async({ Net.news() }) { n -> Announcer.notice(n ?: "לא הצלחתי להביא חדשות כרגע") }
                null
            }
            "nav_poi" -> {
                Announcer.iconHint = "com.waze"
                Nav.to(ctx, poi(t) ?: slot); null
            }
            "nav_to" -> {
                Announcer.iconHint = "com.waze"
                val q = slot.removePrefix("ל").trim()
                if (q.isEmpty()) {
                    Nav.openWaze(ctx); "פותחת את וייז"
                } else {
                    Nav.to(ctx, poi(t) ?: q); "מנווטת ל$q"
                }
            }
            "place_reminder" -> {
                val what = t.replace(Regex(".*?(כשאני מגיע הביתה|כשאגיע הביתה|כשאני מגיע|כשאגיע|כשאני בבית)"), "")
                    .replace("תזכירי לי", "").replace("תזכיר לי", "").trim().ifBlank { "תזכורת" }
                Store.add(Store.PLACE_REM, Store.text(what))
                "בסדר, אזכיר לך כשתגיע הביתה: $what"
            }
            "play" -> play(ctx, t, heard, slot)
            "send_location" -> {
                val name = slot.replace(Regex("איפה|אני|נמצא|המיקום|מיקום|שלי|עם"), " ").trim().removePrefix("ל").trim()
                val link = Contacts.locationLink() ?: return "המיקום עוד לא ידוע"
                if (name.isEmpty()) return "למי לשלוח את המיקום?"
                Contacts.message(ctx, name, "אני כאן: $link")
            }
            "arrival" -> {
                val name = t.substringBefore(" כש").split(" ").drop(1).joinToString(" ").removePrefix("את ").removePrefix("ל").trim()
                if (name.isEmpty()) return "למי להודיע?"
                Features.sessionArrivalContact = name
                "בסדר, אודיע ל-$name כשנתקרב הביתה"
            }
            "reminder" -> reminder(ctx, t)
            "callback" -> {
                val c = Contacts.lastCaller(ctx) ?: return "לא מצאתי שיחה אחרונה. צריך לאשר גישה ליומן השיחות"
                if (t.contains("מי התקשר")) "השיחה האחרונה הייתה מ-${c.first}"
                else if (Contacts.call(ctx, c.second)) null else "לא הצלחתי להתקשר"
            }
            "call" -> {
                if (slot.isEmpty()) return "למי להתקשר?"
                val c = Contacts.find(ctx, slot) ?: Contacts.find(ctx, slot.removePrefix("ל"))
                    ?: return "לא מצאתי את ${slot.removePrefix("ל")} באנשי הקשר"
                if (Contacts.call(ctx, c.second)) null else "לא הצלחתי להתקשר"
            }
            "send_msg" -> sendMessage(ctx, t)
            "cal_add" -> {
                val time = parseDayHour(t) ?: return "באיזו שעה? אפשר לומר למשל: קבעי פגישה מחר ב-10 עם יוסי"
                val title = t.replace(Regex("^(תקבעי|קבעי|תכניסי ליומן|תוסיפי ליומן|תרשמי ביומן|תשימי ביומן)"), "")
                    .replace(Regex("מחרתיים|מחר|היום|ביום \\S+|ב[- ]?\\d{1,2}(?:[:.]\\d{2})?|בערב|אחר הצהריים|ליומן|ביומן"), " ")
                    .replace(Regex("\\s+"), " ").trim().ifBlank { "פגישה" }
                CalendarHelper.add(ctx, title, time)
            }
            "cal_query" -> CalendarHelper.describe(ctx, if (t.contains("מחר")) 1 else 0)
            "note_read" -> {
                val notes = Store.list(Store.NOTES).takeLast(5)
                if (notes.isEmpty()) "אין פתקים" else "הפתקים האחרונים: " + notes.joinToString(". ") { it.optString("text") }
            }
            "note_add" -> {
                val what = t.replace(Regex("^(תרשמי לי|תרשמי פתק|תרשמי|רשמי לי|רשמי|תכתבי פתק|פתק|תזכרי)"), "")
                    .trim().removePrefix("ש").trim()
                if (what.isEmpty()) return "מה לרשום?"
                Store.add(Store.NOTES, Store.text(what))
                "רשמתי"
            }
            "shop" -> shop(t)
            "parking_note" -> {
                val note = t.replace(Regex("^(פתק חניה|חניתי|חנינו)"), "").trim()
                Store.pendingParkingNote = note
                Store.parking?.let { Store.parking = it.put("note", note) }
                "שמרתי: $note"
            }
            "open_app" -> {
                if (slot.isEmpty()) return "איזו אפליקציה לפתוח?"
                val opened = AppFinder.open(ctx, slot)
                when {
                    opened != null -> {
                        Announcer.iconHint = opened.second
                        "פותחת את ${opened.first}"
                    }
                    Prefs.isCar && Link.connected.value -> {
                        Link.send(Link.obj("cmd", "text" to heard)); null
                    }
                    else -> "לא מצאתי אפליקציה בשם $slot. אם תגיד „התכוונתי ל…“ אלמד לפעם הבאה"
                }
            }
            else -> UNKNOWN
        }
    }

    private fun poi(t: String): String? = when {
        has(t, "דלק") -> "תחנת דלק"
        has(t, "כספומט") -> "כספומט"
        has(t, "חניון") -> "חניון"
        has(t, "בית מרקחת") -> "בית מרקחת"
        has(t, "בית קפה") -> "בית קפה"
        else -> null
    }

    private fun whatSong(ctx: Context): String {
        if (mediaRemote()) {
            val m = Link.phoneMedia
            val title = m?.optString("title").orEmpty()
            val artist = m?.optString("artist").orEmpty()
            return when {
                title.isBlank() -> "לא מתנגן כרגע שום שיר"
                artist.isBlank() -> "מתנגן עכשיו: $title"
                else -> "מתנגן עכשיו: $title, של $artist"
            }
        }
        return Media.nowPlaying(ctx) ?: "לא מתנגן כרגע שום שיר"
    }

    private fun play(ctx: Context, t: String, heard: String, slot: String): String? {
        val pkg = when {
            has(t, "יוטיוב") -> Media.YT_MUSIC
            has(t, "ספוטיפי") -> Media.SPOTIFY
            else -> null
        }
        if (mediaRemote()) {
            if (slot.isEmpty()) mediaOp(ctx, "play") else forwardToPhone(heard)
            return null
        }
        Announcer.iconHint = pkg
        if (slot.isEmpty()) {
            if (pkg != null) Media.openApp(ctx, pkg) else Media.play(ctx)
        } else {
            Media.playSearch(ctx, slot, pkg)
        }
        return null
    }

    private fun parkingWhere(ctx: Context): String {
        val p = Store.parking ?: return "עוד לא שמרתי מיקום חניה"
        val lat = p.optDouble("lat")
        val lng = p.optDouble("lng")
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lng?q=$lat,$lng(החניה שלי)"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
        }
        val note = p.optString("note")
        return if (note.isNotBlank()) "פתחתי במפה. רשמת: $note" else "פתחתי את מיקום החניה במפה"
    }

    private fun sos(ctx: Context): String {
        val link = Contacts.locationLink() ?: "המיקום לא ידוע"
        val names = Prefs.list(Prefs.emergencyContacts)
        if (names.isEmpty()) return "לא הוגדרו אנשי קשר לחירום. אפשר להגדיר אותם בהגדרות"
        val sent = names.mapNotNull { n ->
            val c = Contacts.find(ctx, n) ?: return@mapNotNull null
            if (Contacts.sms(ctx, c.second, "חירום! אני צריך עזרה. המיקום שלי: $link")) c.first else null
        }
        return if (sent.isEmpty()) "לא הצלחתי לשלוח. בדוק את הרשאת ה-SMS" else "שלחתי את המיקום שלך ל: ${sent.joinToString(", ")}"
    }

    private fun reminder(ctx: Context, t: String): String {
        val pm = parseMinutes(t) ?: return "בעוד כמה זמן להזכיר? אפשר לומר למשל: תזכירי לי בעוד 20 דקות להתקשר לבנק"
        val (mins, rest) = pm
        val what = rest.replace(Regex("תזכירי לי|תזכיר לי|הזכירי לי|תזכורת|טיימר|ל?עוד"), " ")
            .replace(Regex("\\s+"), " ").trim().removePrefix("ל").trim().ifBlank { "תזכורת" }
        Reminders.inMinutes(ctx, mins, what)
        return "בסדר, אזכיר לך בעוד ${if (mins >= 60 && mins % 60 == 0) "${mins / 60} שעות" else "$mins דקות"}"
    }

    private fun sendMessage(ctx: Context, t: String): String {
        val p = startsAny(t, listOf("תשלחי הודעה ל", "תשלחי ל", "שלחי ל", "תשלח ל", "תכתבי ל", "כתבי ל", "תגידי ל", "תודיעי ל", "תעדכני את", "הודעה ל"))
            ?: return "למי לשלוח?"
        val rest = t.removePrefix(p).trim()
        val words = rest.split(" ")
        for (k in minOf(3, words.size - 1) downTo 1) {
            val name = words.take(k).joinToString(" ")
            val msg = stripShin(words.drop(k).joinToString(" ").trim())
            if (msg.isBlank()) continue
            val known = Relay.recentFor(Contacts.resolveNickname(name)) != null || Contacts.find(ctx, name) != null
            if (known) return Contacts.message(ctx, name, msg)
        }
        return "לא הבנתי למי לשלוח"
    }

    private fun shop(t: String): String {
        if (has(t, "מה ב", "תקריאי", "מה יש ב", "מה צריך")) {
            val items = Store.list(Store.SHOP)
            return if (items.isEmpty()) "רשימת הקניות ריקה" else "ברשימה: " + items.joinToString(", ") { it.optString("text") }
        }
        if (has(t, "תנקי", "תמחקי", "נקי", "מחקי")) {
            Store.clear(Store.SHOP); return "ניקיתי את רשימת הקניות"
        }
        val item = t.replace(Regex("^(תוסיפי|הוסיפי|תכניסי|תשימי|תרשמי)"), "")
            .replace(Regex("(ל|ב)?רשימת (ה)?קניות|לרשימה|ברשימה|לקניות|הרשימה|רשימה"), "").trim()
        if (item.isEmpty()) return "מה להוסיף לרשימה?"
        item.split(" ו").map { it.trim() }.filter { it.isNotEmpty() }.forEach { Store.add(Store.SHOP, Store.text(it)) }
        return "הוספתי $item לרשימה"
    }
}

object Stats {
    fun monthSummary(): String {
        val monthStart = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        }.timeInMillis
        val trips = Store.list(Store.TRIPS).filter { it.optLong("start") >= monthStart }
        val km = trips.sumOf { it.optDouble("km") }
        val minutes = trips.sumOf { (it.optLong("end") - it.optLong("start")) / 60_000 }
        val h = minutes / 60
        val m = minutes % 60
        return "החודש נסעת ${trips.size} נסיעות, כ-${km.toInt()} קילומטר, ${h} שעות ו-$m דקות"
    }
}
