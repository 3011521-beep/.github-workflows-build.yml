package com.kolbaderech.app

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

/** תרגום הודעות בשפה זרה לעברית, על המכשיר ובחינם (ML Kit). */
object Translate {
    fun needs(t: String): Boolean {
        if (t.any { it in '\u0590'..'\u05FF' }) return false
        return t.count { it.isLetter() } >= 6
    }

    fun run(text: String, cb: (String?) -> Unit) {
        try {
            val id = LanguageIdentification.getClient()
            id.identifyLanguage(text)
                .addOnSuccessListener { lang ->
                    try { id.close() } catch (e: Exception) { }
                    val src = TranslateLanguage.fromLanguageTag(lang)
                    if (lang == "und" || src == null || src == TranslateLanguage.HEBREW) {
                        cb(null)
                        return@addOnSuccessListener
                    }
                    val tr = Translation.getClient(
                        TranslatorOptions.Builder()
                            .setSourceLanguage(src)
                            .setTargetLanguage(TranslateLanguage.HEBREW)
                            .build()
                    )
                    tr.downloadModelIfNeeded(DownloadConditions.Builder().requireWifi().build())
                        .addOnSuccessListener {
                            tr.translate(text)
                                .addOnSuccessListener { out -> cb(out); tr.close() }
                                .addOnFailureListener { cb(null); tr.close() }
                        }
                        .addOnFailureListener { cb(null); tr.close() }
                }
                .addOnFailureListener { try { id.close() } catch (e: Exception) { }; cb(null) }
        } catch (e: Exception) {
            cb(null)
        }
    }
}
