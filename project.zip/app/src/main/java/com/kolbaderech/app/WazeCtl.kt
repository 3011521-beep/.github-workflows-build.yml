package com.kolbaderech.app

import android.content.Context
import android.content.Intent

/** עצירת ניווט בוייז: קודם דרך כפתור בהתראה של וייז, ואם אין – לחיצה בתוך וייז דרך הנגישות. */
object WazeCtl {
    private const val WAZE = "com.waze"
    // "כיבוי" בהתראה של וייז = יציאה מלאה מוייז (עוצר גם את הניווט)
    private val stopWords = listOf(
        "כיבוי", "כבה", "turn off", "shut down", "quit", "יציאה", "exit",
        "עצור", "עצירה", "stop", "סיום", "סיים", "end", "ביטול", "cancel", "הפסק"
    )

    fun stop(ctx: Context): String {
        // 1) פעולה בהתראה הקבועה של וייז
        try {
            val l = NotifListener.instance
            val sbn = l?.activeNotifications?.firstOrNull { it.packageName == WAZE }
            val acts = sbn?.notification?.actions
            DLog.i("🗺️ כפתורים בהתראה של וייז: ${acts?.joinToString { it.title.toString() } ?: "אין התראה / אין גישה"}")
            val a = acts?.firstOrNull { act ->
                val t = act.title?.toString()?.lowercase() ?: ""
                stopWords.any { t.contains(it) }
            }
            if (a != null) {
                a.actionIntent.send()
                DLog.i("🗺️ נלחץ: ${a.title}")
                return "כיביתי את וייז"
            }
        } catch (e: Throwable) {
            DLog.e("waze notif", e)
        }
        // 2) בתוך וייז: פותחים ולוחצים "עצור" (לפעמים צריך קודם ללחוץ על פס זמן ההגעה)
        if (GateService.instance == null) return "כדי לעצור ניווט, צריך להפעיל לנוגה את הרשאת הנגישות"
        val i = ctx.packageManager.getLaunchIntentForPackage(WAZE) ?: return "וייז לא מותקן"
        val stopBtn = listOf("עצור", "Stop", "עצירה", "סיום הנסיעה", "End drive", "הפסק ניווט")
        val done: () -> Unit = { Out.say("עצרתי את הניווט") }
        GateService.armTap(WAZE, stopBtn, 5, goHome = false, done = done, contains = true)
        // אם הכפתור לא גלוי – לוחצים קודם על פס זמן ההגעה, ואז על "עצור"
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (GateService.tapPending()) {
                GateService.armTap(WAZE, listOf("הגעה", "ETA", "דק׳", "min", "ק\"מ", "km"), 5, goHome = false, contains = true, done = {
                    GateService.armTap(WAZE, stopBtn, 6, goHome = false, done = done, contains = true)
                })
            }
        }, 3000)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            "מנסה לעצור את הניווט"
        } catch (e: Throwable) {
            "לא הצלחתי לפתוח את וייז"
        }
    }
}
