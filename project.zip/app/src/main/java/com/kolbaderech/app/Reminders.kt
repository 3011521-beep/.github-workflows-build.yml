package com.kolbaderech.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

object Reminders {
    fun inMinutes(c: Context, minutes: Int, text: String) {
        val am = c.getSystemService(AlarmManager::class.java)
        val id = (System.currentTimeMillis() % 100000).toInt()
        val pi = PendingIntent.getBroadcast(
            c, id,
            Intent(c, ReminderReceiver::class.java).putExtra("text", text).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + minutes * 60_000L, pi)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra("text") ?: return
        val id = intent.getIntExtra("id", 7)
        Notify.alert(context, 1000 + id, "תזכורת", text)
        Out.say("תזכורת: $text")
    }
}
