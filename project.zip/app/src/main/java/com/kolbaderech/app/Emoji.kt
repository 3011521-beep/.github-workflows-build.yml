package com.kolbaderech.app

object Emoji {
    private val map = linkedMapOf(
        "❤️" to " לב ", "❤" to " לב ", "😂" to " צוחק ", "🤣" to " צוחק ", "👍" to " לייק ",
        "🙏" to " תודה ", "😊" to " חיוך ", "😍" to " מאוהב ", "😢" to " עצוב ", "😭" to " בוכה ",
        "🔥" to " אש ", "🎉" to " מזל טוב ", "😘" to " נשיקה ", "👌" to " סבבה ", "😅" to " מבוכה "
    )

    fun toWords(text: String): String {
        var t = text
        map.forEach { (k, v) -> t = t.replace(k, v) }
        return t.replace(Regex("\\s+"), " ").trim()
    }
}
