package com.kolbaderech.app

import android.content.Context
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat

/**
 * הדלקת נקודה חמה כשנכנסים לרכב (ניסיוני). אנדרואיד לא מרשה לאפליקציות להדליק אותה ישירות,
 * אז נוגה פותחת את ההגדרות המהירות ולוחצת על "נקודה חמה" דרך שירות הנגישות.
 */
object Hotspot {
    private val handler = Handler(Looper.getMainLooper())

    /** true / false, או null אם לא ידוע. */
    fun isOn(c: Context): Boolean? = try {
        val i = ContextCompat.registerReceiver(
            c, null, IntentFilter("android.net.wifi.WIFI_AP_STATE_CHANGED"), ContextCompat.RECEIVER_EXPORTED
        )
        when (i?.getIntExtra("wifi_state", -1)) {
            12, 13 -> true
            10, 11 -> false
            else -> null
        }
    } catch (e: Throwable) {
        null
    }

    fun ensureOn(c: Context) {
        if (!Prefs.autoHotspot || Prefs.isCar) return
        val app = c.applicationContext
        handler.postDelayed({
            if (Link.connected.value) return@postDelayed
            val on = isOn(app)
            DLog.i("📶 נקודה חמה: ${on ?: "לא ידוע"}")
            if (on != false) return@postDelayed // דלוקה, או שלא ידוע (לא לכבות בטעות)
            if (!GateService.isEnabled(app)) return@postDelayed
            GateService.tapQuickSetting(listOf("נקודה חמה", "Hotspot", "נקודה חמה ניידת", "Mobile Hotspot"))
            handler.postDelayed({
                val after = isOn(app)
                DLog.i("📶 אחרי הלחיצה: ${after ?: "לא ידוע"}")
                if (after == false) Notify.alert(app, 701, "נקודה חמה", "לא הצלחתי להדליק את הנקודה החמה. אפשר להגדיר זאת ב„מצבים ושגרות“ של סמסונג")
            }, 7000)
        }, 3000)
    }
}
