package com.kolbaderech.app

/**
 * זוכר מה כבר הוקרא, כדי לא להקריא שוב:
 * אותה הודעה שקפצה שוב, אותה פגישה מהיומן שלך ומהיומן של אשתך,
 * אותו מייל בשני חשבונות, או הזמנה במייל לפגישה שכבר הוקראה מהיומן.
 */
object Seen {
    private const val H = 60 * 60_000L

    @Synchronized
    fun alreadyRead(kind: String, pkg: String, title: String, text: String, body: String, stamp: String = ""): Boolean {
        val now = System.currentTimeMillis()
        val marks = Store.readMarks()
        // ניקוי ישנים
        val iter = marks.keys()
        val old = ArrayList<String>()
        while (iter.hasNext()) {
            val k = iter.next()
            if (now - marks.optLong(k) > 12 * H) old.add(k)
        }
        old.forEach { marks.remove(it) }

        val nt = Intents.norm(title)
        val nx = Intents.norm(text)
        val nb = Intents.norm(body)
        val keys = ArrayList<Pair<String, Long>>()
        when (kind) {
            "msg" -> keys.add(
                if (stamp.isNotEmpty()) "m|$pkg|$nt|$nx|$stamp" to 12 * H else "m|$pkg|$nt|$nx" to 30 * 60_000L
            )
            "email" -> {
                keys.add("e|$nt|$nx" to 6 * H)
                if (nx.length >= 8) keys.add("s|$nx" to 2 * H)
            }
            else -> {
                keys.add("c|$nt|$nx" to 6 * H)
                if (nt.length >= 6) keys.add("t|$nt" to H)
            }
        }
        // הזמנה במייל / התראה אחרת על אירוע שכבר הוקרא מהיומן
        if (kind != "msg") {
            val all = "$nt $nx $nb"
            val ev = marks.keys().asSequence().filter { k -> k.startsWith("ev|") }.map { k -> k.removePrefix("ev|") }
                .firstOrNull { e -> e.length >= 6 && all.contains(e) && now - marks.optLong("ev|$e") < 3 * H }
            if (ev != null) {
                Store.saveReadMarks(marks)
                return true
            }
        }

        val hit = keys.any { (k, win) -> now - marks.optLong(k, 0) < win }
        keys.forEach { (k, _) -> marks.put(k, now) }
        if (kind == "event" && nt.length >= 6) marks.put("ev|$nt", now)
        Store.saveReadMarks(marks)
        return hit
    }
}
