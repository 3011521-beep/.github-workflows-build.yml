package com.kolbaderech.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object C {
    val Bg = Color(0xFF0E1116)
    val Surface = Color(0xFF171B22)
    val Border = Color(0xFF2A303A)
    val Text = Color(0xFFF2F4F7)
    val Soft = Color(0xFFD5DAE1)
    val Muted = Color(0xFFA3ACB9)
    val Amber = Color(0xFFF5A524)
    val OnAmber = Color(0xFF1A1205)
    val Teal = Color(0xFF4FD1C5)
    val TealBg = Color(0xFF143A37)
    val OnTeal = Color(0xFF0B2624)
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Amber, onPrimary = C.OnAmber,
            background = C.Bg, onBackground = C.Text,
            surface = C.Surface, onSurface = C.Text
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(color = C.Bg, contentColor = C.Text) { content() }
        }
    }
}

@Composable
fun CardBox(modifier: Modifier = Modifier, padding: Dp = 20.dp, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(C.Surface)
            .border(1.dp, C.Border, shape)
            .padding(padding),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = C.Muted, fontSize = 14.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp))
}

@Composable
fun ToggleRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = C.Text, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = C.Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = C.Amber, checkedThumbColor = C.OnAmber,
                uncheckedTrackColor = C.Border, uncheckedThumbColor = C.Muted,
                uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

@Composable
fun BigButton(
    text: String,
    icon: Int?,
    bg: Color,
    fg: Color,
    modifier: Modifier = Modifier,
    outlined: Boolean = false,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier
            .height(64.dp)
            .clip(shape)
            .background(bg)
            .then(if (outlined) Modifier.border(1.dp, C.Border, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(painterResource(icon), contentDescription = null, tint = fg, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = fg, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Avatar(name: String, size: Dp, ring: Boolean = false) {
    val letter = name.trim().firstOrNull()?.toString() ?: "?"
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(C.Border)
            .then(if (ring) Modifier.border(3.dp, C.Amber, CircleShape) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text(letter, color = C.Text, fontSize = (size.value * 0.42f).sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun Chip(text: String) {
    val shape = RoundedCornerShape(16.dp)
    Text(
        text, color = C.Muted, fontSize = 15.sp,
        modifier = Modifier.clip(shape).background(C.Surface).border(1.dp, C.Border, shape)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    )
}

@Composable
fun Dot(color: Color) {
    Box(Modifier.size(10.dp).clip(CircleShape).background(color))
}
